# AcxiomCRM

A role-based CRM web application covering the complete customer–sales lifecycle —
lead capture → qualification → conversion → opportunity pipeline → follow-ups and
activities — with secure authentication, role-based authorization, audit logging,
client-side **and** server-side validation, secured REST APIs and reporting.

Built with **ASP.NET Core 8 MVC + ASP.NET Core Identity + Entity Framework Core (SQLite)**,
Bootstrap 5, jQuery Unobtrusive Validation and Chart.js — exactly the stack the
project specification asks for.

---

## Quick start

**You need:** [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (free).

```bash
cd src/AcxiomCRM
dotnet run
```

Then open **http://localhost:5000** (the exact port is printed in the console).
The SQLite database file (`acxiomcrm.db`) is created automatically on first run,
together with roles, demo users and sample CRM data.

### Demo accounts

| Role            | Email                 | Password    |
|-----------------|-----------------------|-------------|
| Admin           | admin@acxiomcrm.com   | Admin@123   |
| Manager         | manager@acxiomcrm.com | Manager@123 |
| Sales Executive | sales@acxiomcrm.com   | Sales@123   |
| Sales Executive | priya@acxiomcrm.com   | Sales@123   |

> Change these passwords after first sign-in (Admin → Users → Reset password).

---

## What's inside

| Area | Implementation |
|------|----------------|
| **Authentication** | ASP.NET Core Identity — PBKDF2 password hashing, no plain-text passwords anywhere, secure auth cookie (HttpOnly, SameSite=Lax) |
| **Password policy** | Min 8 chars, upper + lower + digit + symbol (configurable in `Program.cs`) |
| **Lockout** | 5 failed attempts → 15-minute lockout; failed count resets on success; admins can unlock |
| **Authorization** | Admin / Manager / SalesExecutive roles; **record-level scoping enforced on the server** (`Services/ScopeService.cs`) — sales users only ever see their own assigned records |
| **Validation** | Client-side (jQuery Unobtrusive from data annotations, incl. custom "date not in past" adapter) **and** server-side (data annotations + `IValidatableObject` + service checks: uniqueness, FK integrity, lead workflow transitions, ownership) |
| **Business rules** | Opportunity amount > 0 · probability 0–100 · close date not in past for active deals · follow-up date not before today · lead status workflow (New → Contacted → Qualified → Converted/Lost) · customer email/phone uniqueness & duplicate prevention |
| **Audit log** | Append-only: logins, failed logins, lockouts, creates/updates/deletes, conversions, role changes, password resets — with user, timestamp, action, module, record id, old/new values and IP. Admins see everything; managers see business events only |
| **REST API** | `/api/auth/*`, `/api/customers`, `/api/leads` (+ `/convert`), `/api/opportunities`, `/api/followups` (+ `/complete`), `/api/reports/pipeline` — DTOs only (never entities), validated payloads, proper status codes (200/201/400/401/403/404/409), rate-limited login |
| **Reports** | Customer, Lead, Follow-Up, Opportunity, Pipeline (stage/owner-wise, weighted), Conversion, User Activity, Audit — all with filters, sorting, pagination and CSV export |
| **Dashboard** | Role-based KPI cards (customers, leads, open leads, opportunities, won/lost, pipeline value, follow-ups), Chart.js charts (lead status, pipeline by stage, monthly sales), date filters (Today / Week / Month / Custom), upcoming follow-ups & recent activities |
| **UI** | Responsive Bootstrap 5, role-filtered navigation, inline validation, toast notifications, confirmation dialogs, search/filter/sort/pagination everywhere, accessible labels |

### Module map

`Controllers/` — `Account`, `Dashboard`, `Customers`, `Leads`, `Opportunities`,
`FollowUps`, `Activities`, `Users` (Admin; Manager read-only), `Roles` (Admin),
`AuditLogs` (Admin full / Manager limited), `Reports`, plus `Controllers/Api/`
for the REST layer.

`Models/` — entities, `CrmConstants` (single source of truth for statuses,
stages and workflow transitions), DTOs, ViewModels, custom validation attributes.

`Data/` — `ApplicationDbContext` (relationships, unique constraints, indexes)
and `DbSeeder` (roles, users, sample data).

`Services/` — `AuditService`, `ScopeService` (server-side authorization),
`LoginRateLimitingMiddleware`.

---

## API quick tour

```bash
# sign in (sets the auth cookie; rate-limited)
curl -c cookies.txt -X POST http://localhost:5000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@acxiomcrm.com","password":"Admin@123"}'

# list customers (paged, searchable)
curl -b cookies.txt "http://localhost:5000/api/customers?q=acme&page=1"

# create a lead -> 201
curl -b cookies.txt -X POST http://localhost:5000/api/leads \
  -H 'Content-Type: application/json' \
  -d '{"leadName":"Asha Kumar","email":"asha@example.com","phone":"9123456789","expectedValue":75000}'

# pipeline report (Admin/Manager)
curl -b cookies.txt http://localhost:5000/api/reports/pipeline
```

Error responses are consistent JSON: `{ "message": "...", "errors": { "field": ["..."] }, "traceId": "..." }`
— never stack traces, never password hashes.

---

## Configuration

- Connection string: `ConnectionStrings:DefaultConnection` in `appsettings.json`
  (default: local `acxiomcrm.db`). DB credentials must never be hard-coded —
  use environment variables / user secrets in real deployments.
- Password policy, lockout threshold/duration: `Program.cs` → `AddIdentity(...)`.
- Cookie `SecurePolicy` is `SameAsRequest` for local development; set it to
  `Always` and serve **HTTPS** in production (see Security checklist below).

## Production security checklist (from the spec)

- [x] Password hashing enabled (Identity PBKDF2)
- [x] Password policy enabled
- [x] Account lockout enabled
- [x] Role-based authorization enabled (server-side)
- [x] Server-side validation enabled
- [x] Anti-forgery tokens on all state-changing MVC forms
- [x] Sensitive information excluded from logs
- [ ] **HTTPS in production** — terminate TLS and set cookie `SecurePolicy = Always`
- [x] API authorization + input validation enabled
- [x] Audit logging enabled for security-sensitive actions
- [x] Least-privilege access applied to roles
- [x] No secrets hard-coded (connection string in configuration, not code)

---

## Project structure

```
AcxiomCRM/
├── AcxiomCRM.sln
├── README.md
└── src/AcxiomCRM/
    ├── Controllers/          # MVC controllers (web UI)
    │   └── Api/              # REST API controllers
    ├── Models/               # Entities, DTOs, ViewModels, validation
    ├── Data/                 # DbContext + seeder
    ├── Services/             # Audit, scoping, rate limiting
    ├── Views/                # Razor views (Bootstrap 5 UI)
    ├── wwwroot/              # Vendored Bootstrap/jQuery/Chart.js + site assets
    ├── Program.cs
    └── appsettings.json
```

All third-party front-end libraries are vendored under `wwwroot/lib`, so the app
runs fully offline.

---

*Built with care for the AcxiomCRM project specification — every module,
validation rule, workflow, API endpoint and report from the document is
implemented and covered by the acceptance test in `docs/`.*
