#!/usr/bin/env bash
# AcxiomCRM one-command start (Linux/macOS). Requires .NET 8 SDK.
set -e
cd "$(dirname "$0")/src/AcxiomCRM"
echo "Starting AcxiomCRM…"
dotnet run
