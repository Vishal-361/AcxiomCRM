# AcxiomCRM — Requirements Traceability

Every line of the project specification, mapped to where it lives in the code.
(`§` = spec section.)

## Modules (§2, §4, §17.2)

| Spec module | Implementation |
|---|---|
| 1. AcxiomCRM shell | `Views/Shared/_Layout.cshtml` — responsive nav, header, user menu, footer; menu items filtered by role |
| 2. Authentication & Authorization | `Controllers/AccountController.cs`, `Controllers/Api/AuthApiController.cs`, `Program.cs` (Identity) |
| 3. Dashboard | `Controllers/DashboardController.cs`, `Views/Dashboard/Index.cshtml` |
| 4. Customer Management | `Controllers/CustomersController.cs`, `Views/Customers/` |
| 5. Lead Management | `Controllers/LeadsController.cs`, `Views/Leads/` (incl. Convert) |
| 6. Follow-Up Management | `Controllers/FollowUpsController.cs`, `Views/FollowUps/` |
| 7. User & Role Management | `Controllers/UsersController.cs` (incl. Delete with self/last-admin/owns-records guards), `Controllers/RolesController.cs`, `Views/Users/`, `Views/Roles/` |
| 8. Opportunity | `Controllers/OpportunitiesController.cs`, `Views/Opportunities/` (pipeline board) |
| 9. Audit Log | `Services/IAuditService.cs`, `Controllers/AuditLogsController.cs`, `Views/AuditLogs/` |
| 10. REST API | `Controllers/Api/` — Auth, Customers, Leads, Opportunities, FollowUps, Reports |
| 11. Reports | `Controllers/ReportsController.cs`, `Views/Reports/` (8 reports + hub) |
| Activity Management (§17.2) | `Controllers/ActivitiesController.cs`, `Views/Activities/` |

## Architecture (§3)

| Layer | Implementation |
|---|---|
| Presentation | Razor Views + tag helpers, Bootstrap 5, client-side validation |
| Application | MVC/API controllers, DTOs (`Models/Dtos/`), ViewModels |
| Domain/Business | Entities (`Models/`), `CrmConstants` (status sets + workflow transitions), `IValidatableObject` rules |
| Data Access | `Data/ApplicationDbContext.cs` (repositories via `DbSet`, FK constraints, unique indexes) |
| Database | SQLite (`acxiomcrm.db`), normalized, indexed |
| Security | Identity (hashing, lockout, cookies), `ScopeService`, anti-forgery, rate limiting |
| Cross-cutting | `AuditService`, exception handling, configuration |

## Validation (§5, §17.5, §17.6, §17.7, §17.8)

| Requirement | Client-side | Server-side |
|---|---|---|
| Required fields | `data-val-required` (unobtrusive) | `[Required]` + ModelState |
| Email format | `data-val-email` | `[EmailAddress]` |
| Phone format (10-digit, 6–9…) | `data-val-regex` | `[RegularExpression]` |
| Length limits | `data-val-length` / maxlength | `[StringLength]` |
| Date validity | `data-val-date` | `[DataType(DataType.Date)]` + binding |
| Numeric / range | `data-val-range` / number | `[Range]` |
| Follow-up date ≥ today | custom `data-val-notinpast` adapter (`wwwroot/js/site.js`) | `NotInPastAttribute` + controller check |
| Expected close date not in past (active opp) | same adapter on edit forms | `Opportunity.Validate()` |
| Opportunity amount > 0 | `data-val-range` | `[Range(0.01, …)]` "Opportunity Amount must be greater than 0." |
| Probability 0–100 | `data-val-range` | `[Range(0,100)]` "Probability must be between 0 and 100." |
| Email uniqueness | — | service check + unique DB index → friendly message / HTTP 409 |
| Phone uniqueness | — | service check + unique DB index → friendly message / HTTP 409 |
| Duplicate customer | — | name+company duplicate check |
| Lead status from valid set + workflow | dropdown limited to valid next statuses | `CrmConstants.LeadStatuses.CanTransition` |
| FK integrity | dropdowns of visible records | server re-checks every FK against scoped queries |
| Ownership tampering | — | `ScopeService.CanAccessRecord` / scoped queries; 403/404 |

## Authentication & Security (§6, §17.4, §17.9)

| Requirement | Implementation |
|---|---|
| Login / Logout / Register | `AccountController`, audited |
| No custom password table — ASP.NET Core Identity | `ApplicationUser : IdentityUser`, `AddIdentity` in `Program.cs` |
| Framework-managed hashes only | Identity PBKDF2; hashes never in views/DTOs/API/logs |
| Password policy (8+, complexity) | `Program.cs` Identity options; friendly error translation |
| Lockout (5 attempts, 15 min) | Identity lockout; audited; admin unlock |
| Role-based, server-side authorization | `[Authorize(Roles=…)]` + `ScopeService` on every query |
| Audit of auth events (no secrets) | `AuditService` — Login/FailedLogin/Logout/Register/Lockout |
| Secure cookie | HttpOnly, SameSite=Lax, 8h sliding expiry (Secure=Always in prod) |
| Anti-forgery on MVC POSTs | `@Html.AntiForgeryToken()` + `[ValidateAntiForgeryToken]` |
| No SQL concatenation | EF Core parameterized queries only |
| Rate limiting on login | `LoginRateLimitingMiddleware` (10/min/IP → 429) |
| HTTPS in production | HSTS enabled; documented (`README`) |

## Roles (§7, §17.10)

Enforced in `ScopeService` (data) and `[Authorize]` (pages/endpoints):

| Module | Admin | Manager | SalesExecutive |
|---|---|---|---|
| Dashboard | Full | Team | Own/Assigned |
| Customers/Leads/Follow-Ups/Opportunities/Activities | Full | Team | Own/Assigned |
| Users | Full | View only | No |
| Roles | Full | No | No |
| Audit Log | Full | Limited (business events) | No |
| Reports | All | Team reports | Own/assigned |
| Pipeline API | Yes | Yes | 403 |

## Workflows (§8)

- **Lead → Customer**: `Leads/Convert` (GET confirm → POST creates Customer + Qualification Opportunity, marks lead Converted, audits everything). API: `POST /api/leads/{id}/convert`.
- **Opportunity**: create → amount/probability/close date → move through Qualification/Proposal/Negotiation → Won/Lost; weighted value = Amount × Probability / 100.
- **Follow-Up**: schedule → complete/missed/reschedule (reschedule audited).
- **User admin**: create → assign role → active/inactive → password policy + lockout → audited.

## Entities (§9, §17.3)

`Models/` — `ApplicationUser` (Identity), `Customer` (CustomerCode auto-generated),
`Lead` (LeadCode auto-generated), `Opportunity` (weighted value derived),
`FollowUp`, `Activity`, `AuditLog` (UserId, Action, EntityName, RecordId,
OldValue, NewValue, Result, CreatedDate, IpAddress). All required fields present;
relationships + indexes in `ApplicationDbContext`.

## REST API (§10, §17.14)

| Method | Endpoint | Status |
|---|---|---|
| POST | `/api/auth/login` | 200 / 401 / 423 / 429 |
| POST | `/api/auth/logout` | 200 / 401 |
| GET/POST | `/api/customers` | 200 / 201 / 400 / 401 / 409 |
| GET/PUT/DELETE | `/api/customers/{id}` | 200 / 400 / 401 / 403 / 404 / 409 |
| GET/POST | `/api/leads` | 200 / 201 / 400 / 401 |
| GET/PUT/DELETE | `/api/leads/{id}` | 200 / 400 / 401 / 403 / 404 |
| POST | `/api/leads/{id}/convert` | 200 / 400 / 401 / 403 / 404 |
| GET/POST | `/api/opportunities` | 200 / 201 / 400 / 401 |
| GET/PUT/DELETE | `/api/opportunities/{id}` | 200 / 400 / 401 / 403 / 404 |
| GET/POST | `/api/followups` | 200 / 201 / 400 / 401 |
| GET/PUT/DELETE | `/api/followups/{id}` | 200 / 400 / 401 / 403 / 404 |
| POST | `/api/followups/{id}/complete` | 200 / 401 / 403 / 404 |
| GET | `/api/reports/pipeline` | 200 / 401 / 403 (Admin/Manager) |

DTOs throughout; consistent JSON error objects; no stack traces; no secrets.

## Reporting (§11)

All in `ReportsController` + `Views/Reports/`: Customer, Lead, Follow-Up,
Opportunity, Pipeline (stage-wise + owner-wise + weighted), Conversion,
User Activity, Audit — each with filters, sorting, pagination and CSV export,
all role-scoped.

## UI/UX (§12)

Responsive Bootstrap layout · consistent nav · inline validation messages ·
toast notifications · confirmation dialogs for destructive actions ·
search/filter/sort/pagination on all lists · accessible labels · friendly
(non-technical) error messages.

## Testing & acceptance (§13, §17.17, §17.19)

All 14 acceptance scenarios verified against a running instance
(see test script output): anonymous blocked, login → dashboard, client
validation present, crafted requests rejected, opportunity/follow-up rules,
role scoping (sales/manager/admin), audit entries, API status codes,
dashboard KPIs + Chart.js.

## Security checklist (§14)

Implemented per `README.md` — the only deployment-time item is HTTPS
(cookie `SecurePolicy = Always` + TLS termination), documented for production.
