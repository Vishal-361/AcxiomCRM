# AcxiomCRM — Detailed Evaluation Demo Guide (§17.20)

**Goal:** prove, live, that this is not "just a database CRUD app" — it has
workflows, both kinds of validation, business rules, secure auth, role-based
authorization, dashboard analytics, audit logging, a REST API and a layered
architecture.

**Setup (do this 10 minutes before):**
1. Open a terminal in `src/AcxiomCRM` and run `dotnet run`. Wait for
   `Now listening on: http://localhost:5000` (your port may differ — use the
   one printed).
2. Open the URL in Chrome/Edge. Keep a second terminal tab ready for the
   API demo (step 9).
3. Sign in as **admin@acxiomcrm.com / Admin@123**.
4. Create a throwaway user for the lockout demo: Users → **+ New user** →
   email `locktest@example.com`, password `Lock@1234`, role Sales Executive.
   (You will lock *this* account, never your admin one.)

---

## 1. CRM workflows — the lead lifecycle (2 min)

**What it proves:** records move through a real business process, not just
CRUD.

1. Go to **Leads** → **+ New lead**. Fill: Lead name `Demo Prospect`,
   Email `demo@example.com`, Phone `9811111111`, Company `Demo Corp`,
   Source `Website`, Priority `High`, Expected value `250000` → Save.
2. Open the lead. The **Status** dropdown only offers the *next legal*
   statuses. Change `New` → `Contacted` → Save. Then `Contacted` →
   `Qualified` → Save. (Try picking an illegal jump — the option isn't
   even offered; the server also rejects it.)
3. Click **Convert to Customer** → read the confirmation screen ("this will
   create a customer and a qualification opportunity") → Confirm.
4. Go to **Customers** → the new customer is there (code auto-generated,
   e.g. `CUS-0007`). Go to **Opportunities** → a new opportunity exists in
   the **Qualification** column of the pipeline board.
5. Move the opportunity: open it → change Stage to `Proposal` → Save →
   `Negotiation` → Save → `Won` → Save. Note the **Weighted value**
   (Amount × Probability ÷ 100) shown on the board.

**Say:** *"A lead is captured, qualified through a guarded workflow, then
converted — the system creates the customer and the opening opportunity
itself, and the deal travels the pipeline to Won."*

---

## 2. Client-side validation (1 min)

**What it proves:** instant feedback, no server round trip.

1. **Customers** → **+ New customer** → click **Save customer** with the
   form empty. Inline messages appear next to every required field —
   the page does **not** reload.
2. Type `not-an-email` in Email → *"Enter a valid email address."* appears
   as you tab away. Type `123` in Phone → *"Enter a valid phone number
   (10 digits starting with 6–9)."* Clear them, fill the form correctly,
   save → details page.

**Say:** *"Every rule from the data annotations runs in the browser via
jQuery unobtrusive validation — including a custom adapter I wrote for
'date cannot be in the past'."*

## 3. Server-side validation (1 min)

**What it proves:** the browser is never trusted.

1. In your second terminal, sign the API session in and post garbage
   directly, bypassing all browser validation:
   ```bash
   curl -c c.txt -X POST http://localhost:5000/api/auth/login \
     -H 'Content-Type: application/json' \
     -d '{"email":"admin@acxiomcrm.com","password":"Admin@123"}'
   curl -b c.txt -X POST http://localhost:5000/api/customers \
     -H 'Content-Type: application/json' \
     -d '{"customerName":"X","email":"not-an-email","phone":"123"}'
   ```
2. Show the response: **HTTP 400** with a JSON body naming each bad field.
3. Repeat with an email that already exists → **HTTP 409** *"Email is
   already registered."*

**Say:** *"Client validation is convenience. The server re-validates every
field, every uniqueness rule and every foreign key — crafted requests fail
exactly like bad forms."*

## 4. Business rules (1.5 min)

**What it proves:** domain rules, not just field formats.

1. **Opportunities** → **+ New opportunity** → Amount `0` → save →
   *"Opportunity Amount must be greater than 0."*
2. Probability `101` → *"Probability must be between 0 and 100."*
3. Expected Close Date → yesterday's date → rejected for an active deal
   (*"Expected Close Date cannot be in the past for an active opportunity."*)
   Pick a future date, save → works.
4. **Follow-Ups** → **+ New follow-up** → date = yesterday → rejected
   (*"Follow-up date cannot be in the past."*) Pick tomorrow, save, then
   **Mark complete**.
5. **Leads** → open any lead → Status dropdown: only the legal next
   transitions are offered.

**Say:** *"These live in the domain model — `CrmConstants` for the
workflows, validators on the entities — so the web UI and the API enforce
identical rules."*

## 5. Secure authentication (1.5 min)

**What it proves:** real security, not a demo login.

1. **Register** a new user with password `pass` → policy error (minimum 8
   characters, upper + lower + digit + symbol). Register properly →
   signed in.
2. Sign out → sign in as `locktest@example.com` → enter a wrong password
   5 times → *"This account has been locked out"* for 15 minutes.
3. Sign back in as admin → Users → open the locked user → **Unlock**.

**Say:** *"Passwords are hashed by ASP.NET Core Identity — PBKDF2, never
plain text, and hashes never appear in any page, API response or log.
Five failures lock the account; every attempt is audited. Cookies are
HttpOnly + SameSite, and every form carries an anti-forgery token."*

## 6. Role-based authorization (1.5 min)

**What it proves:** scoping is enforced on the server, not by hiding menus.

1. Sign in as **sales@acxiomcrm.com / Sales@123** → Customers list shows
   **only assigned** records. Manually open `/Users` → **Access denied**.
2. Open the browser dev tools → try `GET /api/reports/pipeline` with the
   sales session → **403**.
3. Sign in as **manager@acxiomcrm.com / Manager@123** → Pipeline report
   opens (team data); try `/Roles` → denied.
4. Back as admin → everything available.

**Say:** *"Every query passes through `ScopeService` on the server —
ownership and role are checked per record, so tampering with a URL or
calling the API directly can't escape your scope."*

## 7. Dashboard analytics (1 min)

**What it proves:** the dashboard is analytics, not decoration.

1. Open **Dashboard**. Walk across the KPI cards: total customers, total
   leads, open leads, opportunities, won/lost counts, total pipeline value,
   pending follow-ups.
2. Point at the three charts: **Leads by status** (doughnut), **Pipeline by
   stage** (bar), **Monthly sales** (line).
3. Change the date filter: Today → This week → Custom range → Apply.
   Numbers and charts update.
4. Sign in as sales → dashboard shows **only their** numbers.

**Say:** *"All figures are computed live from the database and respect the
signed-in user's role scope."*

## 8. Audit logging (1 min)

**What it proves:** a tamper-evident trail of everything.

1. As admin, create or edit any record (or do the lead conversion again).
2. Open **Audit Log** → the newest entries show: timestamp, user, action
   (Created/Updated/Converted/Login…), module, record id, **old and new
   values**, IP address.
3. Sign in as manager → Audit Log shows only business events (no security
   internals). As sales → the menu item isn't there at all.

**Say:** *"The log is append-only — there is no edit or delete path in the
code — and it never records passwords or secrets."*

## 9. REST API functionality (1.5 min)

**What it proves:** a real, secured API, not just web pages.

In the terminal (reuse the `c.txt` cookie from step 3, or log in again):
```bash
# list (paged JSON of DTOs — no entities, no hashes)
curl -b c.txt "http://localhost:5000/api/customers?q=demo&page=1"
# create -> 201 with Location header
curl -b c.txt -X POST http://localhost:5000/api/customers \
  -H 'Content-Type: application/json' \
  -d '{"customerName":"API Corp","email":"api@example.com","phone":"9123456780"}'
# no session -> 401 JSON
curl -X POST http://localhost:5000/api/customers \
  -H 'Content-Type: application/json' -d '{}'
# pipeline report (admin/manager only)
curl -b c.txt http://localhost:5000/api/reports/pipeline
```

**Say:** *"Cookie auth shared with the UI, DTOs in and out, consistent
error JSON, and the full status-code vocabulary — 200, 201, 400, 401, 403,
404, 409. Full reference is in `docs/API.md`."*

## 10. Structured application architecture (1 min)

**What it proves:** layered design, not a single-folder script.

Show the folder tree (`src/AcxiomCRM`) and narrate top-down:

```
Controllers/        UI web layer (one controller per module)
Controllers/Api/    REST layer (DTOs, status codes)
Models/             entities, DTOs, ViewModels, validators
Data/               DbContext (relationships/indexes) + DbSeeder
Services/           AuditService, ScopeService, rate limiting  <- cross-cutting
Views/              Razor pages (Bootstrap UI)
wwwroot/            vendored Bootstrap/jQuery/Chart.js (works offline)
```

**Say:** *"Layered architecture: presentation → application (controllers,
DTOs) → domain (entities, `CrmConstants` workflows, validation) → data
access (EF Core) → SQLite. Cross-cutting concerns — auditing, authorization
scoping, login rate limiting — live in `Services` so they apply to the UI
and the API identically."*

---

## Likely viva questions (short answers)

- **Why ASP.NET Core Identity instead of your own users table?**
  "The spec forbids custom password tables — Identity gives framework-managed
  PBKDF2 hashing, lockout and cookie security I don't have to hand-roll."
- **What happens if I disable JavaScript and submit a bad form?**
  "Client validation is skipped, but the server rejects it — I verified this
  with crafted requests: 400/409 responses."
- **How do you stop a sales user from editing another's record by URL?**
  "Every controller query goes through `ScopeService` — ownership is checked
  server-side; tampered IDs return 403/404."
- **Why is the audit log append-only?**
  "It has no edit or delete path in the code — only Admin can read it, so the
  history is tamper-evident."
- **Customer delete — hard or soft?**
  "Soft: status flips to Inactive so history is preserved. Leads, follow-ups
  and activities hard-delete, but an audit snapshot is kept first."
- **Where is the single source of truth for statuses and workflows?**
  "`Models/CrmConstants.cs` — every dropdown, validator and transition check
  reads from it, so the UI and API can never disagree."
