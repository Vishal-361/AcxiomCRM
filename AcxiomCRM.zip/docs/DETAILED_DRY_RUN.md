# AcxiomCRM — Detailed Dry-Run Walkthrough (§17.20)

Companion to `DEMO_SCRIPT.md`. This version spells out **every click, exact
button/menu text, what to type, and what you should see** — verified against
the source code. Read it once, then run through it once before the evaluation.

**Total run time: ~12–14 minutes.** Items 1–10 follow the §17.20 list in order.

---

## Pre-flight (10 minutes before the evaluation)

1. Open a terminal in `src/AcxiomCRM` and run:
   `dotnet run --urls http://localhost:5000`
   Wait for `Now listening on: http://localhost:5000`.
2. Open **http://localhost:5000** in Chrome/Edge. You land on the **login
   page** (the app always starts at login — it never opens the dashboard
   directly).
3. Sign in as **admin@acxiomcrm.com** / **Admin@123** → you land on the
   **Dashboard**.
4. Open a second terminal tab in the same folder — you need it for the API
   demo (items 3 and 9).
5. Create a throwaway user for the lockout demo (item 5): click **Admin** in
   the top nav → **Users** → **+ New user** → email `locktest@example.com`,
   password `Lock@1234`, role **Sales Executive** → save. You will lock
   **this** account, never your admin one.
6. Keep this document open on a second screen or printed.

---

## 1. CRM workflows — the lead lifecycle (2 min)

**Proves:** records move through a real business process, not just CRUD.

1. Click **Leads** in the top nav → click **+ New lead**.
2. Fill in: Lead name `Demo Prospect`, Email `demo@example.com`, Phone
   `9811111111`, Company `Demo Corp`, Source `Website`, Priority `High`,
   Expected value `250000` → click **Save lead**.
3. You land on the lead details page. Click **Edit** (or the edit button).
   The **Status** dropdown offers only the legal next statuses from
   `New`: `Contacted`, `Qualified`, `Unqualified`, `Lost`. Pick
   **Contacted** → save. Edit again → the dropdown now offers only
   `Qualified`, `Unqualified`, `Lost`. Pick **Qualified** → save.
   *(Point out: an illegal jump is not even offered — and the server
   rejects it too if forced.)*
4. On the lead details page, click the green **Convert to customer** button.
   Read the confirmation screen, then click **Convert now** (click **Not yet**
   only to cancel).
5. Click **Customers** → the new customer is listed (auto-generated code
   like `CUS-0007`). Click **Opportunities** → a new opportunity sits in the
   **Qualification** column of the pipeline board.
6. Open that opportunity → **Edit** → Stage `Proposal` → save → **Edit** →
   Stage `Negotiation` → save → **Edit** → Stage `Won` → save. Point at the
   **weighted value** shown on the board (Amount × Probability ÷ 100).

**Say:** *"A lead is captured, qualified through a guarded workflow, then
converted — the system creates the customer and the opening opportunity
itself, and the deal travels the pipeline to Won."*

---

## 2. Client-side validation (1 min)

**Proves:** instant feedback, no server round trip.

1. Click **Customers** → **+ New customer** → immediately click
   **Save customer** with the form empty. Inline messages appear beside every
   required field — **the page does not reload**.
2. Type `not-an-email` in **Email** and tab away → *"Enter a valid email
   address."* appears. Type `123` in **Phone** and tab away → *"Enter a valid
   phone number (10 digits starting with 6–9)."*
3. Fill the fields correctly → **Save customer** → details page.

**Say:** *"Every rule runs in the browser via jQuery unobtrusive validation —
including a custom adapter I wrote for 'date cannot be in the past'."*

---

## 3. Server-side validation (1 min)

**Proves:** the browser is never trusted.

1. In the second terminal, log the API session in and POST garbage directly,
   bypassing all browser validation:
   ```bash
   curl -c c.txt -X POST http://localhost:5000/api/auth/login \
     -H 'Content-Type: application/json' \
     -d '{"email":"admin@acxiomcrm.com","password":"Admin@123"}'
   curl -b c.txt -X POST http://localhost:5000/api/customers \
     -H 'Content-Type: application/json' \
     -d '{"customerName":"X","email":"not-an-email","phone":"123"}'
   ```
2. Show the response: **HTTP 400** with a JSON body naming each bad field.
3. Repeat with an email that already exists → **HTTP 409** with
   *"Email is already registered."*

**Say:** *"Client validation is convenience. The server re-validates every
field, every uniqueness rule and every foreign key — crafted requests fail
exactly like bad forms."*

---

## 4. Business rules (1.5 min)

**Proves:** domain rules, not just field formats.

1. **Opportunities** → **+ New opportunity** → set **Amount** to `0` → save →
   *"Opportunity Amount must be greater than 0."*
2. Set **Probability** to `101` → save →
   *"Probability must be between 0 and 100."*
3. Set **Expected Close Date** to yesterday → save → rejected for an active
   deal: *"Expected Close Date cannot be in the past for an active
   opportunity."* Pick a future date → saves fine.
4. **Follow-Ups** → **+ Schedule follow-up** → date = yesterday → rejected:
   *"Follow-up date cannot be in the past."* Pick tomorrow → save → click
   **Complete** on the new row.
5. **Leads** → open any lead → **Edit** → **Status** dropdown shows only the
   legal next transitions.

**Say:** *"These live in the domain model — `CrmConstants` for the workflows,
validators on the entities — so the web UI and the API enforce identical
rules."*

---

## 5. Secure authentication (1.5 min)

**Proves:** real security, not a demo login.

1. Click your avatar (top right) → **Sign out**. On the login page click
   **Register** → try password `pass` → policy error (minimum 8 characters,
   upper + lower + digit + symbol). Register properly → you are signed in.
2. **Sign out** → sign in as **locktest@example.com** → enter a wrong
   password **5 times** → *"We've locked this account — it's how we keep
   intruders out. Please wait about 15 minutes…"*
3. Sign back in as admin → **Admin** → **Users** → open
   `locktest@example.com` → **Unlock**.

**Say:** *"Passwords are hashed by ASP.NET Core Identity — PBKDF2, never plain
text, and hashes never appear in any page, API response or log. Five failures
lock the account; every attempt is audited. Cookies are HttpOnly + SameSite,
and every form carries an anti-forgery token."*

---

## 6. Role-based authorization (1.5 min)

**Proves:** scoping is enforced on the server, not by hiding menus.

1. **Sign out** → sign in as **sales@acxiomcrm.com** / **Sales@123** →
   **Customers** shows **only assigned** records. Manually open
   `http://localhost:5000/Users` → **Access denied** page.
2. Open browser dev tools → run
   `fetch('/api/reports/pipeline').then(r=>alert(r.status))` → **403**.
3. **Sign out** → sign in as **manager@acxiomcrm.com** / **Manager@123** →
   **Reports** → **Pipeline report** opens (team data); try opening
   `http://localhost:5000/Roles` → denied.
4. Back in as admin → **Admin** menu shows **Users** and
   **Roles & Permissions**; everything opens.

**Say:** *"Every query passes through `ScopeService` on the server —
ownership and role are checked per record, so tampering with a URL or calling
the API directly can't escape your scope."*

---

## 7. Dashboard analytics (1 min)

**Proves:** the dashboard is analytics, not decoration.

1. Open **Dashboard**. Walk across the KPI cards: **Customers** (in your
   scope), **Leads** (open right now), **Opportunities** (open),
   **Won / Lost**, **Pipeline value** (₹), **Follow-ups**.
2. Point at the three charts: **Leads by status** (doughnut),
   **Pipeline by stage** (bar), **Monthly sales (won)** (line).
3. Change the date filter: **Today** → **Week** → **Month** → **Custom**
   (pick a range) → **Apply**. Numbers and charts update.
4. **Sign out** → sign in as sales → the dashboard shows **only their**
   numbers.

**Say:** *"All figures are computed live from the database and respect the
signed-in user's role scope."*

---

## 8. Audit logging (1 min)

**Proves:** a tamper-evident trail of everything.

1. As admin, create or edit any record (or redo the lead conversion).
2. Click **Audit Log** → the newest entries show: timestamp, user, action
   (Created / Updated / Converted / Login / Lockout / Role change…), module,
   record id, **old and new values**, IP address.
3. **Sign out** → sign in as manager → **Audit Log** shows business events
   only (no security internals). As sales → the menu item isn't there at all.

**Say:** *"The log is append-only — there is no edit or delete path in the
code — and it never records passwords or secrets."*

---

## 9. REST API functionality (1.5 min)

**Proves:** a real, secured API, not just web pages.

In the second terminal (reuse the `c.txt` cookie from item 3, or log in again):

```bash
# list (paged JSON of DTOs — no entities, no hashes)
curl -b c.txt "http://localhost:5000/api/customers?q=demo&page=1"
# create -> 201 with Location header
curl -b c.txt -X POST http://localhost:5000/api/customers \
  -H 'Content-Type: application/json' \
  -d '{"customerName":"API Corp","email":"api@example.com","phone":"9123456780"}'
# no session -> 401 JSON
curl -X POST http://localhost:5000/api/customers \
  -H 'Content-Type: application/json' -d '{}'
# pipeline report (admin/manager only)
curl -b c.txt http://localhost:5000/api/reports/pipeline
```

**Say:** *"Cookie auth shared with the UI, DTOs in and out, consistent error
JSON, and the full status-code vocabulary — 200, 201, 400, 401, 403, 404, 409.
Full reference is in `docs/API.md`."*

---

## 10. Structured application architecture (1 min)

**Proves:** layered design, not a single-folder script.

Show the folder tree of `src/AcxiomCRM` and narrate top-down:

```
Controllers/        UI web layer (one controller per module)
Controllers/Api/    REST layer (DTOs, status codes)
Models/             entities, DTOs, ViewModels, validators
Data/               DbContext (relationships/indexes) + DbSeeder
Services/           AuditService, ScopeService, rate limiting  <- cross-cutting
Views/              Razor pages (Bootstrap UI)
wwwroot/            vendored Bootstrap/jQuery/Chart.js (works offline)
```

**Say:** *"Layered architecture: presentation → application (controllers,
DTOs) → domain (entities, `CrmConstants` workflows, validation) → data access
(EF Core) → SQLite. Cross-cutting concerns — auditing, authorization scoping,
login rate limiting — live in `Services` so they apply to the UI and the API
identically."*

---

## If something goes wrong mid-demo

- **Port already in use:** kill the old process or run
  `dotnet run --urls http://localhost:5001` and use that port everywhere.
- **Forgot which account you're in:** the avatar (top right) shows the signed-in email.
- **Locked yourself out of admin:** stop the app, delete the SQLite file
  (the app re-seeds demo accounts on next start), start again.
- **An evaluator asks something off-script:** say *"Let me show you"* and
  open `docs/TRACEABILITY.md` — it maps every spec line to the exact file.

## Viva questions — one-line answers

Short answers to the likely questions live in `DEMO_SCRIPT.md` (Identity vs
custom tables, JS-disabled forms, URL tampering, append-only audit, soft
delete, `CrmConstants` as single source of truth). Read those two pages
before the evaluation.
