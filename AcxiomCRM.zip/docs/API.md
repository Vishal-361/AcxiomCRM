# AcxiomCRM REST API Reference

Base URL: `http://localhost:5000` (development)

## Authentication

The API uses the same cookie authentication as the web UI (ASP.NET Core
Identity). Sign in first; the auth cookie is sent with every request.

```
POST /api/auth/login      — public, rate-limited (10/min per IP)
POST /api/auth/logout     — authenticated
```

**Login request**

```json
{ "email": "admin@acxiomcrm.com", "password": "Admin@123" }
```

**Login response — 200**

```json
{ "userId": "…", "fullName": "Aarav Sharma", "email": "admin@acxiomcrm.com", "roles": ["Admin"] }
```

Failures: `401` invalid credentials · `423` account locked · `429` too many attempts.

## Conventions

- DTOs in, DTOs out — EF entities, password hashes and internal fields are never exposed.
- Every payload is validated; business rules (uniqueness, date rules, lead workflow, ownership) are enforced.
- Consistent error body: `{ "message": "…", "errors": { "field": ["…"] }, "traceId": "…" }`.
- Status codes: `200` OK · `201` Created (with `Location`) · `400` validation/business rule ·
  `401` not authenticated · `403` not authorized for this record/endpoint ·
  `404` not found · `409` duplicate (email/phone) · `429` rate-limited.

## Endpoints

### Customers — `/api/customers`

| Method | Path | Notes |
|---|---|---|
| GET | `/api/customers?q=&status=&page=1&pageSize=10` | paged, searchable (name/email/phone/company) |
| GET | `/api/customers/{id}` | |
| POST | `/api/customers` | → 201; 409 on duplicate email/phone |
| PUT | `/api/customers/{id}` | → 403 when outside your scope |
| DELETE | `/api/customers/{id}` | deactivates (history preserved) |

**Create body**

```json
{
  "customerName": "Acme Industries",
  "email": "contact@acme.in",
  "phone": "9876543210",
  "companyName": "Acme Industries Pvt Ltd",
  "address": "…", "city": "Bengaluru", "state": "Karnataka",
  "notes": "…", "ownerId": "…"
}
```

### Leads — `/api/leads`

| Method | Path | Notes |
|---|---|---|
| GET | `/api/leads?q=&status=&page=1&pageSize=10` | paged, searchable |
| GET | `/api/leads/{id}` | |
| POST | `/api/leads` | always starts at `New`; → 201 |
| PUT | `/api/leads/{id}` | status must follow the workflow, else 400 |
| DELETE | `/api/leads/{id}` | |
| POST | `/api/leads/{id}/convert?createOpportunity=true` | Qualified → Customer + Opportunity; → 200 `{ customerId, opportunityId }` |

**Create body**

```json
{
  "leadName": "Karan Malhotra", "email": "karan@x.in", "phone": "9811111111",
  "companyName": "Northwind", "source": "Website", "priority": "High",
  "expectedValue": 250000, "notes": "…", "assignedTo": "…"
}
```

### Opportunities — `/api/opportunities`

| Method | Path | Notes |
|---|---|---|
| GET | `/api/opportunities?q=&stage=&page=1&pageSize=10` | paged, searchable |
| GET | `/api/opportunities/{id}` | includes `weightedValue` |
| POST | `/api/opportunities` | amount > 0, probability 0–100, close date ≥ today for active stages |
| PUT | `/api/opportunities/{id}` | same rules |
| DELETE | `/api/opportunities/{id}` | |

**Create body**

```json
{
  "opportunityName": "Acme — Annual contract", "customerId": 1,
  "amount": 480000, "probability": 75, "expectedCloseDate": "2026-11-15",
  "stage": "Negotiation", "source": "Referral", "notes": "…", "assignedTo": "…"
}
```

### Follow-ups — `/api/followups`

| Method | Path | Notes |
|---|---|---|
| GET | `/api/followups?status=&overdue=&page=1&pageSize=10` | `overdue=true` filters overdue planned items |
| GET | `/api/followups/{id}` | |
| POST | `/api/followups` | date ≥ today; attach to customer or lead |
| PUT | `/api/followups/{id}` | |
| DELETE | `/api/followups/{id}` | |
| POST | `/api/followups/{id}/complete` | marks completed |

**Create body**

```json
{
  "relatedType": "Customer", "customerId": 1,
  "followUpDate": "2026-10-20", "subject": "Share proposal",
  "followUpType": "Call", "remarks": "…", "assignedTo": "…"
}
```

### Reports — `/api/reports`

| Method | Path | Access |
|---|---|---|
| GET | `/api/reports/pipeline` | Admin, Manager — stage-wise + owner-wise amounts, weighted values, totals |

## Authorization notes

- Every protected endpoint requires authentication (`401` otherwise).
- Sales executives operate strictly inside their assigned scope: records outside
  it return `403` (or `404` where the record doesn't exist).
- `/api/reports/pipeline` is restricted to Admin/Manager (`403` for Sales).
- Login is rate-limited; repeated failures also trigger the account lockout
  (5 attempts → 15 minutes), exactly like the web UI.
