using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ---- Database (SQLite file; connection string lives in appsettings, not in code) ----
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? "Data Source=acxiomcrm.db";
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(connectionString));

// ---- ASP.NET Core Identity: users, PBKDF2 password hashing, roles, lockout, cookies ----
// Policy values are configurable via appsettings (AcxiomCRM section).
var security = builder.Configuration.GetSection("AcxiomCRM");
var passwordMinLength = security.GetValue("PasswordMinLength", 8);
var lockoutAttempts = security.GetValue("LockoutMaxFailedAttempts", 5);
var lockoutMinutes = security.GetValue("LockoutMinutes", 15);

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        // Password policy (6.2)
        options.Password.RequiredLength = passwordMinLength;
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireNonAlphanumeric = true;
        options.Password.RequiredUniqueChars = 1;

        // Lockout (6.3)
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(lockoutMinutes);
        options.Lockout.MaxFailedAccessAttempts = lockoutAttempts;
        options.Lockout.AllowedForNewUsers = true;

        options.User.RequireUniqueEmail = true;
        options.SignIn.RequireConfirmedEmail = false;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

// ---- Secure cookie configuration ----
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.LogoutPath = "/Account/Logout";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromHours(8);
    options.SlidingExpiration = true;
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    // NOTE: set to Always in production behind HTTPS (see README / Security Checklist).
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    options.Cookie.Name = "AcxiomCRM.Auth";

    // APIs speak JSON, not redirects: return 401/403 for /api callers.
    options.Events.OnRedirectToLogin = context =>
    {
        if (context.Request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            context.Response.ContentType = "application/json";
            return context.Response.WriteAsync(
                """{"message":"Authentication is required.","traceId":""}""");
        }
        context.Response.Redirect(context.RedirectUri);
        return Task.CompletedTask;
    };
    options.Events.OnRedirectToAccessDenied = context =>
    {
        var isApi = context.Request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase);
        if (isApi)
        {
            context.Response.StatusCode = StatusCodes.Status403Forbidden;
            context.Response.ContentType = "application/json";
            return context.Response.WriteAsync(
                """{"message":"You do not have permission to access this resource."}""");
        }
        context.Response.Redirect(context.RedirectUri);
        return Task.CompletedTask;
    };
});

// ---- MVC + API ----
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

// ---- Cross-cutting services ----
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IScopeService, ScopeService>();

var app = builder.Build();

// ---- Seed roles, users and demo data ----
await DbSeeder.SeedAsync(app.Services);

// ---- HTTP pipeline ----
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts(); // production hardening; HTTPS required in deployment
}

app.UseStaticFiles();
app.UseRouting();

// Brute-force protection for login endpoints (before auth so it applies to anonymous hits too)
app.UseMiddleware<LoginRateLimitingMiddleware>();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Dashboard}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
