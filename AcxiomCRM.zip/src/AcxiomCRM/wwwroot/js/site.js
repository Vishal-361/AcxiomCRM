/* AcxiomCRM shared behaviours: validation adapters, toasts, confirm dialogs. */
(function () {
    "use strict";

    // Friendly auto-dismiss for notification banners (they've said their piece).
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll(".alert-dismissible").forEach(function (el) {
            setTimeout(function () {
                var close = el.querySelector(".btn-close");
                if (close) close.click();
            }, 7000);
        });

        // Human confirmation for destructive actions: data-confirm on the form.
        document.querySelectorAll("form[data-confirm]").forEach(function (form) {
            form.addEventListener("submit", function (e) {
                if (!form.dataset.confirmed && !window.confirm(form.dataset.confirm)) {
                    e.preventDefault();
                } else {
                    form.dataset.confirmed = "1";
                }
            });
        });
    });

    // ---- Custom unobtrusive validators (mirror the server-side attributes) ----
    function wireUnobtrusive() {
        if (!window.jQuery || !jQuery.validator || !jQuery.validator.unobtrusive) return;

        // data-val-notinpast: the date may not be in the past (calendar-day comparison).
        jQuery.validator.addMethod("notinpast", function (value, element) {
            if (!value) return true; // [required] handles emptiness
            var entered = new Date(value + "T00:00:00");
            if (isNaN(entered.getTime())) return true; // let other rules complain
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            return entered >= today;
        });
        jQuery.validator.unobtrusive.adapters.addBool("notinpast");

        // Tweak a couple of default messages to sound like a person, not a compiler.
        jQuery.extend(jQuery.validator.messages, {
            required: "This field is required.",
            email: "Enter a valid email address.",
            number: "Please enter a number.",
            date: "Please enter a valid date."
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", wireUnobtrusive);
    } else {
        wireUnobtrusive();
    }
})();
