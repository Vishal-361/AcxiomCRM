using System.ComponentModel.DataAnnotations;
using AcxiomCRM.Models.Validation;

namespace AcxiomCRM.Models.Dtos;

/// <summary>
/// API contracts. DTOs are deliberately separate from EF entities:
/// the API never leaks password hashes, tokens or internal DB fields.
/// </summary>

#region Shared
public class ErrorResponse
{
    public string Message { get; set; } = string.Empty;
    public Dictionary<string, string[]>? Errors { get; set; }
    public string TraceId { get; set; } = string.Empty;
}

public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
}
#endregion

#region Auth
public class LoginRequest
{
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
}

public class LoginResponse
{
    public string UserId { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public List<string> Roles { get; set; } = new();
}
#endregion

#region Customers
public class CustomerDto
{
    public int CustomerId { get; set; }
    public string CustomerCode { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? CompanyName { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? OwnerName { get; set; }
    public DateTime CreatedDate { get; set; }
}

public class CustomerCreateDto
{
    [Required(ErrorMessage = "Customer name is required.")]
    [StringLength(100, ErrorMessage = "Customer name cannot exceed 100 characters.")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone is required.")]
    [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid phone number.")]
    public string Phone { get; set; } = string.Empty;

    [StringLength(150)] public string? CompanyName { get; set; }
    [StringLength(250)] public string? Address { get; set; }
    [StringLength(80)] public string? City { get; set; }
    [StringLength(80)] public string? State { get; set; }
    [StringLength(1000)] public string? Notes { get; set; }
    public string? OwnerId { get; set; }
}

public class CustomerUpdateDto : CustomerCreateDto
{
    [Required] public string Status { get; set; } = "Active";
}
#endregion

#region Leads
public class LeadDto
{
    public int LeadId { get; set; }
    public string LeadCode { get; set; } = string.Empty;
    public string LeadName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? CompanyName { get; set; }
    public string? Source { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;
    public decimal ExpectedValue { get; set; }
    public string? AssignedToName { get; set; }
    public DateTime CreatedDate { get; set; }
}

public class LeadCreateDto
{
    [Required(ErrorMessage = "Lead name is required.")]
    [StringLength(100)]
    public string LeadName { get; set; } = string.Empty;

    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150)]
    public string? Email { get; set; }

    [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid phone number.")]
    public string? Phone { get; set; }

    [StringLength(150)] public string? CompanyName { get; set; }
    public string? Source { get; set; }
    public string Priority { get; set; } = "Medium";

    [Range(0, 999999999.99, ErrorMessage = "Expected value must be between 0 and 999,999,999.99.")]
    public decimal ExpectedValue { get; set; }

    [StringLength(1000)] public string? Notes { get; set; }
    public string? AssignedTo { get; set; }
}

public class LeadUpdateDto : LeadCreateDto
{
    [Required(ErrorMessage = "Lead status is required.")]
    public string Status { get; set; } = "New";
}
#endregion

#region Opportunities
public class OpportunityDto
{
    public int OpportunityId { get; set; }
    public string OpportunityName { get; set; } = string.Empty;
    public string? CustomerName { get; set; }
    public string Stage { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public int Probability { get; set; }
    public decimal WeightedValue { get; set; }
    public DateTime ExpectedCloseDate { get; set; }
    public string? OwnerName { get; set; }
    public DateTime CreatedDate { get; set; }
}

public class OpportunityCreateDto
{
    [Required(ErrorMessage = "Opportunity name is required.")]
    [StringLength(150)]
    public string OpportunityName { get; set; } = string.Empty;

    public int? CustomerId { get; set; }
    public int? LeadId { get; set; }

    [Required(ErrorMessage = "Opportunity amount is required.")]
    [Range(0.01, 999999999.99, ErrorMessage = "Opportunity Amount must be greater than 0.")]
    public decimal Amount { get; set; }

    [Required(ErrorMessage = "Probability is required.")]
    [Range(0, 100, ErrorMessage = "Probability must be between 0 and 100.")]
    public int Probability { get; set; }

    [Required(ErrorMessage = "Expected close date is required.")]
    public DateTime ExpectedCloseDate { get; set; }

    public string Stage { get; set; } = "Qualification";
    public string? Source { get; set; }
    [StringLength(1000)] public string? Notes { get; set; }
    public string? AssignedTo { get; set; }
}

public class OpportunityUpdateDto : OpportunityCreateDto { }
#endregion

#region FollowUps
public class FollowUpDto
{
    public int FollowUpId { get; set; }
    public string RelatedType { get; set; } = string.Empty;
    public string? RelatedName { get; set; }
    public DateTime FollowUpDate { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string FollowUpType { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? AssignedToName { get; set; }
    public bool IsOverdue { get; set; }
}

public class FollowUpCreateDto
{
    [Required] public string RelatedType { get; set; } = "Customer";
    public int? CustomerId { get; set; }
    public int? LeadId { get; set; }

    [Required(ErrorMessage = "Follow-up date is required.")]
    [NotInPast("Follow-up date cannot be earlier than today.")]
    public DateTime FollowUpDate { get; set; }

    [Required(ErrorMessage = "Subject is required.")]
    [StringLength(150)]
    public string Subject { get; set; } = string.Empty;

    public string FollowUpType { get; set; } = "Call";

    [StringLength(1000)] public string? Remarks { get; set; }
    public string? AssignedTo { get; set; }
}

public class FollowUpUpdateDto : FollowUpCreateDto
{
    [Required] public string Status { get; set; } = "Planned";
}
#endregion

#region Reports
public class PipelineReportDto
{
    public List<StagePipelineDto> ByStage { get; set; } = new();
    public List<OwnerPipelineDto> ByOwner { get; set; } = new();
    public decimal TotalPipelineValue { get; set; }
    public decimal TotalWeightedValue { get; set; }
}

public class StagePipelineDto
{
    public string Stage { get; set; } = string.Empty;
    public int Count { get; set; }
    public decimal Amount { get; set; }
    public decimal WeightedAmount { get; set; }
}

public class OwnerPipelineDto
{
    public string OwnerName { get; set; } = string.Empty;
    public int Count { get; set; }
    public decimal Amount { get; set; }
    public decimal WeightedAmount { get; set; }
}
#endregion
