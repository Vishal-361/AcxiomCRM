using AcxiomCRM.Models.Validation;
using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class Opportunity : IValidatableObject
{
    public int OpportunityId { get; set; }

    [Required(ErrorMessage = "Opportunity name is required.")]
    [StringLength(150, ErrorMessage = "Opportunity name cannot exceed 150 characters.")]
    [Display(Name = "Opportunity name")]
    public string OpportunityName { get; set; } = string.Empty;

    [Display(Name = "Customer")]
    public int? CustomerId { get; set; }

    public Customer? Customer { get; set; }

    [Display(Name = "Originating lead")]
    public int? LeadId { get; set; }

    [Required(ErrorMessage = "Opportunity amount is required.")]
    [Range(0.01, 999999999.99, ErrorMessage = "Opportunity Amount must be greater than 0.")]
    [DataType(DataType.Currency)]
    public decimal Amount { get; set; }

    [Required(ErrorMessage = "Stage is required.")]
    [StringLength(20)]
    public string Stage { get; set; } = CrmConstants.OpportunityStages.Qualification;

    [Required(ErrorMessage = "Probability is required.")]
    [Range(0, 100, ErrorMessage = "Probability must be between 0 and 100.")]
    [Display(Name = "Probability (%)")]
    public int Probability { get; set; }

    [Required(ErrorMessage = "Expected close date is required.")]
    [DataType(DataType.Date)]
    [Display(Name = "Expected close date")]
    public DateTime ExpectedCloseDate { get; set; } = DateTime.Today.AddDays(30);

    [StringLength(50)] public string? Source { get; set; }

    /// <summary>Derived convenience flag; an opportunity is active unless Won or Lost.</summary>
    [StringLength(20)] public string Status { get; set; } = "Open";

    [Display(Name = "Owner")]
    public string? AssignedTo { get; set; }

    public ApplicationUser? AssignedUser { get; set; }

    [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters.")]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [StringLength(100)] public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    /// <summary>Weighted pipeline value = Amount × Probability / 100.</summary>
    public decimal WeightedValue => Amount * Probability / 100m;

    public bool IsActive => CrmConstants.OpportunityStages.IsActive(Stage);

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!CrmConstants.OpportunityStages.All.Contains(Stage))
        {
            yield return new ValidationResult("Please choose a valid pipeline stage.", new[] { nameof(Stage) });
            yield break;
        }

        // Business rule: expected close date cannot be in the past for an ACTIVE opportunity.
        if (IsActive && ExpectedCloseDate.Date < DateTime.Today)
            yield return new ValidationResult("Expected Close Date cannot be in the past.",
                new[] { nameof(ExpectedCloseDate) });
    }
}
