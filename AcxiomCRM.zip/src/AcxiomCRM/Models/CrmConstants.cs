namespace AcxiomCRM.Models;

/// <summary>
/// Central place for every pick-list, status set and workflow rule in AcxiomCRM.
/// Both the UI and the server read from here, so the rules can never drift apart.
/// </summary>
public static class CrmConstants
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string SalesExecutive = "SalesExecutive";

        public static readonly string[] All = { Admin, Manager, SalesExecutive };
    }

    public static class LeadStatuses
    {
        public const string New = "New";
        public const string Contacted = "Contacted";
        public const string Qualified = "Qualified";
        public const string Unqualified = "Unqualified";
        public const string Converted = "Converted";
        public const string Lost = "Lost";

        public static readonly string[] All = { New, Contacted, Qualified, Unqualified, Converted, Lost };

        /// <summary>Configured lead workflow: which status may follow which.</summary>
        public static readonly Dictionary<string, string[]> AllowedTransitions = new()
        {
            [New] = new[] { Contacted, Qualified, Unqualified, Lost },
            [Contacted] = new[] { Qualified, Unqualified, Lost },
            [Qualified] = new[] { Converted, Lost },
            [Unqualified] = new[] { Lost },
            [Converted] = Array.Empty<string>(),   // terminal
            [Lost] = Array.Empty<string>(),        // terminal
        };

        public static bool IsOpen(string status) =>
            status is New or Contacted or Qualified;

        public static bool CanTransition(string from, string to) =>
            from == to || (AllowedTransitions.TryGetValue(from, out var next) && next.Contains(to));
    }

    public static class OpportunityStages
    {
        public const string Qualification = "Qualification";
        public const string Proposal = "Proposal";
        public const string Negotiation = "Negotiation";
        public const string Won = "Won";
        public const string Lost = "Lost";

        public static readonly string[] All = { Qualification, Proposal, Negotiation, Won, Lost };

        public static bool IsActive(string stage) => stage is not (Won or Lost);
        public static bool IsOpen(string stage) => stage is not (Won or Lost);
    }

    public static class FollowUpStatuses
    {
        public const string Planned = "Planned";
        public const string Completed = "Completed";
        public const string Missed = "Missed";
        public const string Cancelled = "Cancelled";

        public static readonly string[] All = { Planned, Completed, Missed, Cancelled };
    }

    public static class FollowUpTypes
    {
        public const string Call = "Call";
        public const string Meeting = "Meeting";
        public const string Email = "Email";
        public const string Task = "Task";
        public const string Visit = "Visit";

        public static readonly string[] All = { Call, Meeting, Email, Task, Visit };
    }

    public static class ActivityTypes
    {
        public const string Call = "Call";
        public const string Meeting = "Meeting";
        public const string Email = "Email";
        public const string Task = "Task";

        public static readonly string[] All = { Call, Meeting, Email, Task };
    }

    public static class ActivityStatuses
    {
        public const string Planned = "Planned";
        public const string InProgress = "In Progress";
        public const string Completed = "Completed";
        public const string Cancelled = "Cancelled";

        public static readonly string[] All = { Planned, InProgress, Completed, Cancelled };
    }

    public static class CustomerStatuses
    {
        public const string Active = "Active";
        public const string Inactive = "Inactive";
        public const string Prospect = "Prospect";

        public static readonly string[] All = { Active, Inactive, Prospect };
    }

    public static class LeadSources
    {
        public static readonly string[] All =
            { "Website", "Referral", "Cold Call", "Email Campaign", "Social Media", "Walk-in", "Partner", "Other" };
    }

    public static class LeadPriorities
    {
        public static readonly string[] All = { "Low", "Medium", "High", "Urgent" };
    }

    public static class AuditActions
    {
        public const string Login = "Login";
        public const string FailedLogin = "FailedLogin";
        public const string Logout = "Logout";
        public const string Register = "Register";
        public const string Create = "Create";
        public const string Update = "Update";
        public const string Delete = "Delete";
        public const string Convert = "Convert";
        public const string Complete = "Complete";
        public const string Reschedule = "Reschedule";
        public const string RoleChange = "RoleChange";
        public const string PasswordReset = "PasswordReset";
        public const string AccountLocked = "AccountLocked";
        public const string AccountUnlocked = "AccountUnlocked";
        public const string StatusChange = "StatusChange";
    }
}
