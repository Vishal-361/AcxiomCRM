using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models.Validation;

/// <summary>
/// Server-side + client-side rule: the date may not be in the past (compared by calendar day).
/// Used for Expected Close Date on active opportunities and for new/planned follow-ups.
/// </summary>
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public sealed class NotInPastAttribute : ValidationAttribute, IClientModelValidator
{
    public NotInPastAttribute() { }

    public NotInPastAttribute(string errorMessage)
    {
        // NOTE: set via property — the base(string) ctor does not propagate
        // the message on this runtime.
        ErrorMessage = errorMessage;
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        if (value is null) return ValidationResult.Success; // [Required] handles emptiness
        if (value is DateTime dt && dt.Date < DateTime.Today)
            return new ValidationResult(ErrorMessage ?? "The date cannot be in the past.");
        return ValidationResult.Success;
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        context.Attributes.Add("data-val", "true");
        context.Attributes.Add("data-val-notinpast", ErrorMessage ?? "The date cannot be in the past.");
    }
}
