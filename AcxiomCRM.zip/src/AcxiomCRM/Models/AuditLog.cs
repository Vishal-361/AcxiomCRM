using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

/// <summary>
/// Append-only audit record. There is intentionally no edit or delete UI/API
/// for audit entries — history must stay trustworthy.
/// </summary>
public class AuditLog
{
    public int AuditLogId { get; set; }

    [StringLength(100)] public string? UserId { get; set; }

    [StringLength(150)] public string? UserName { get; set; }

    [Required]
    [StringLength(50)]
    public string Action { get; set; } = string.Empty;

    [StringLength(50)] public string? EntityName { get; set; }

    [StringLength(50)] public string? RecordId { get; set; }

    [StringLength(2000)] public string? OldValue { get; set; }

    [StringLength(2000)] public string? NewValue { get; set; }

    [StringLength(20)] public string Result { get; set; } = "Success";

    [StringLength(45)] public string? IpAddress { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
}
