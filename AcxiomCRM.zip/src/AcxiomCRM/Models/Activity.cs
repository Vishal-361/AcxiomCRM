using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class Activity : IValidatableObject
{
    public int ActivityId { get; set; }

    [Required(ErrorMessage = "Activity type is required.")]
    [StringLength(20)]
    [Display(Name = "Activity type")]
    public string ActivityType { get; set; } = CrmConstants.ActivityTypes.Call;

    [Required(ErrorMessage = "Subject is required.")]
    [StringLength(150, ErrorMessage = "Subject cannot exceed 150 characters.")]
    public string Subject { get; set; } = string.Empty;

    [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters.")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Activity date is required.")]
    [DataType(DataType.Date)]
    [Display(Name = "Activity date")]
    public DateTime ActivityDate { get; set; } = DateTime.Today;

    public int? CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public int? LeadId { get; set; }
    public Lead? Lead { get; set; }

    [Display(Name = "Assigned to")]
    public string? AssignedTo { get; set; }

    public ApplicationUser? AssignedUser { get; set; }

    [Required(ErrorMessage = "Status is required.")]
    [StringLength(20)]
    public string Status { get; set; } = CrmConstants.ActivityStatuses.Planned;

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [StringLength(100)] public string? CreatedBy { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!CrmConstants.ActivityTypes.All.Contains(ActivityType))
            yield return new ValidationResult("Please choose a valid activity type.", new[] { nameof(ActivityType) });
        if (!CrmConstants.ActivityStatuses.All.Contains(Status))
            yield return new ValidationResult("Please choose a valid status.", new[] { nameof(Status) });
    }
}
