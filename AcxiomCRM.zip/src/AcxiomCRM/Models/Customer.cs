using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AcxiomCRM.Models;

public class Customer : IValidatableObject
{
    public int CustomerId { get; set; }

    // System-generated on create (see controller); never user input, so no [Required].
    [StringLength(12)]
    [Display(Name = "Customer code")]
    public string CustomerCode { get; set; } = string.Empty;

    [Required(ErrorMessage = "Customer name is required.")]
    [StringLength(100, ErrorMessage = "Customer name cannot exceed 100 characters.")]
    [Display(Name = "Customer name")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150, ErrorMessage = "Email cannot exceed 150 characters.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone is required.")]
    [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid phone number.")]
    [StringLength(10, ErrorMessage = "Phone number must be 10 digits.")]
    [Display(Name = "Phone")]
    public string Phone { get; set; } = string.Empty;

    [StringLength(150, ErrorMessage = "Company name cannot exceed 150 characters.")]
    [Display(Name = "Company")]
    public string? CompanyName { get; set; }

    [StringLength(250, ErrorMessage = "Address cannot exceed 250 characters.")]
    public string? Address { get; set; }

    [StringLength(80)] public string? City { get; set; }

    [StringLength(80)] public string? State { get; set; }

    [Required(ErrorMessage = "Status is required.")]
    [StringLength(20)]
    public string Status { get; set; } = CrmConstants.CustomerStatuses.Active;

    /// <summary>Sales executive who owns this customer (ownership scoping).</summary>
    [Display(Name = "Assigned sales executive")]
    public string? OwnerId { get; set; }

    public ApplicationUser? Owner { get; set; }

    [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters.")]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [StringLength(100)] public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!CrmConstants.CustomerStatuses.All.Contains(Status))
            yield return new ValidationResult("Please choose a valid status.", new[] { nameof(Status) });
    }
}
