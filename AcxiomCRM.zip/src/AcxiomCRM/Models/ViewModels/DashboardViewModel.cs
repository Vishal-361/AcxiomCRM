using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models.ViewModels;

public class DateFilterViewModel
{
    [Display(Name = "Preset")]
    public string Preset { get; set; } = "Month"; // Today | Week | Month | Custom

    [DataType(DataType.Date)]
    [Display(Name = "From")]
    public DateTime? FromDate { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "To")]
    public DateTime? ToDate { get; set; }

    public (DateTime From, DateTime To) ResolveRange()
    {
        var today = DateTime.Today;
        return Preset switch
        {
            "Today" => (today, today.AddDays(1).AddTicks(-1)),
            "Week" => (today.AddDays(-(int)today.DayOfWeek), today.AddDays(1).AddTicks(-1)),
            "Custom" when FromDate.HasValue && ToDate.HasValue =>
                (FromDate.Value.Date, ToDate.Value.Date.AddDays(1).AddTicks(-1)),
            _ => (new DateTime(today.Year, today.Month, 1), today.AddDays(1).AddTicks(-1)),
        };
    }
}

public class DashboardViewModel
{
    public string Greeting { get; set; } = string.Empty;
    public string UserDisplayName { get; set; } = string.Empty;
    public string RoleDisplayName { get; set; } = string.Empty;
    public DateFilterViewModel Filter { get; set; } = new();

    public int TotalCustomers { get; set; }
    public int TotalLeads { get; set; }
    public int OpenLeads { get; set; }
    public int TotalOpportunities { get; set; }
    public int OpenOpportunities { get; set; }
    public int WonOpportunities { get; set; }
    public int LostOpportunities { get; set; }
    public decimal TotalPipelineValue { get; set; }
    public int PendingFollowUps { get; set; }
    public int OverdueFollowUps { get; set; }
    public int TotalUsers { get; set; }
    public int LockedOutUsers { get; set; }

    public Dictionary<string, int> LeadStatusCounts { get; set; } = new();
    public Dictionary<string, decimal> PipelineByStage { get; set; } = new();
    public Dictionary<string, decimal> MonthlySales { get; set; } = new();

    public List<FollowUp> UpcomingFollowUps { get; set; } = new();
    public List<Activity> RecentActivities { get; set; } = new();
}
