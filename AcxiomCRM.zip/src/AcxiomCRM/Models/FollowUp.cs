using AcxiomCRM.Models.Validation;
using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class FollowUp : IValidatableObject
{
    public int FollowUpId { get; set; }

    /// <summary>What this follow-up is attached to: "Customer" or "Lead" (or "Opportunity").</summary>
    [Required]
    [StringLength(20)]
    public string RelatedType { get; set; } = "Customer";

    public int? CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public int? LeadId { get; set; }
    public Lead? Lead { get; set; }

    [Required(ErrorMessage = "Follow-up date is required.")]
    [DataType(DataType.Date)]
    [NotInPast("Follow-up date cannot be earlier than today.")]
    [Display(Name = "Follow-up date")]
    public DateTime FollowUpDate { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "Subject is required.")]
    [StringLength(150, ErrorMessage = "Subject cannot exceed 150 characters.")]
    public string Subject { get; set; } = string.Empty;

    [Required(ErrorMessage = "Type is required.")]
    [StringLength(20)]
    [Display(Name = "Type")]
    public string FollowUpType { get; set; } = CrmConstants.FollowUpTypes.Call;

    [Required(ErrorMessage = "Status is required.")]
    [StringLength(20)]
    public string Status { get; set; } = CrmConstants.FollowUpStatuses.Planned;

    [StringLength(1000, ErrorMessage = "Remarks cannot exceed 1000 characters.")]
    public string? Remarks { get; set; }

    [Display(Name = "Assigned to")]
    public string? AssignedTo { get; set; }

    public ApplicationUser? AssignedUser { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [StringLength(100)] public string? CreatedBy { get; set; }

    public DateTime? CompletedDate { get; set; }

    public bool IsOverdue => Status == CrmConstants.FollowUpStatuses.Planned && FollowUpDate.Date < DateTime.Today;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!CrmConstants.FollowUpStatuses.All.Contains(Status))
            yield return new ValidationResult("Please choose a valid status.", new[] { nameof(Status) });
        if (!CrmConstants.FollowUpTypes.All.Contains(FollowUpType))
            yield return new ValidationResult("Please choose a valid follow-up type.", new[] { nameof(FollowUpType) });
        if (CustomerId is null && LeadId is null)
            yield return new ValidationResult("Please attach this follow-up to a customer or a lead.",
                new[] { nameof(CustomerId) });
    }
}
