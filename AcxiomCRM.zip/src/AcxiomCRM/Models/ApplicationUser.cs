using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

/// <summary>
/// Application user managed by ASP.NET Core Identity.
/// Passwords are stored ONLY as framework-managed hashes (never plain text)
/// and are never exposed in views, DTOs, API responses or logs.
/// </summary>
public class ApplicationUser : IdentityUser
{
    [Required]
    [StringLength(100)]
    [Display(Name = "Full name")]
    public string FullName { get; set; } = string.Empty;

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    public string? CreatedBy { get; set; }
}
