using System.ComponentModel.DataAnnotations;

namespace AcxiomCRM.Models;

public class Lead : IValidatableObject
{
    public int LeadId { get; set; }

    // System-generated on create (see controller); never user input, so no [Required].
    [StringLength(12)]
    [Display(Name = "Lead code")]
    public string LeadCode { get; set; } = string.Empty;

    [Required(ErrorMessage = "Lead name is required.")]
    [StringLength(100, ErrorMessage = "Lead name cannot exceed 100 characters.")]
    [Display(Name = "Lead name")]
    public string LeadName { get; set; } = string.Empty;

    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    [StringLength(150, ErrorMessage = "Email cannot exceed 150 characters.")]
    public string? Email { get; set; }

    [RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid phone number.")]
    [StringLength(10, ErrorMessage = "Phone number must be 10 digits.")]
    public string? Phone { get; set; }

    [StringLength(150, ErrorMessage = "Company name cannot exceed 150 characters.")]
    [Display(Name = "Company")]
    public string? CompanyName { get; set; }

    [StringLength(50)] public string? Source { get; set; }

    [Required(ErrorMessage = "Lead status is required.")]
    [StringLength(20)]
    public string Status { get; set; } = CrmConstants.LeadStatuses.New;

    [StringLength(20)] public string Priority { get; set; } = "Medium";

    [Range(0, 999999999.99, ErrorMessage = "Expected value must be between 0 and 999,999,999.99.")]
    [DataType(DataType.Currency)]
    [Display(Name = "Expected value")]
    public decimal ExpectedValue { get; set; }

    [Display(Name = "Assigned sales executive")]
    public string? AssignedTo { get; set; }

    public ApplicationUser? AssignedUser { get; set; }

    [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters.")]
    public string? Notes { get; set; }

    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

    [StringLength(100)] public string? CreatedBy { get; set; }

    public DateTime? ModifiedDate { get; set; }

    public DateTime? ConvertedDate { get; set; }

    public int? ConvertedCustomerId { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!CrmConstants.LeadStatuses.All.Contains(Status))
            yield return new ValidationResult("Please choose a valid lead status.", new[] { nameof(Status) });
        if (!string.IsNullOrEmpty(Priority) && !CrmConstants.LeadPriorities.All.Contains(Priority))
            yield return new ValidationResult("Please choose a valid priority.", new[] { nameof(Priority) });
        if (!string.IsNullOrEmpty(Source) && !CrmConstants.LeadSources.All.Contains(Source))
            yield return new ValidationResult("Please choose a valid lead source.", new[] { nameof(Source) });
    }
}
