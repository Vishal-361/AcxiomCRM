using AcxiomCRM.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

/// <summary>Role administration (Admin only): roles and the permission matrix.</summary>
[Authorize(Roles = "Admin")]
public class RolesController : Controller
{
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly UserManager<ApplicationUser> _userManager;

    public RolesController(RoleManager<IdentityRole> roleManager, UserManager<ApplicationUser> userManager)
    {
        _roleManager = roleManager;
        _userManager = userManager;
    }

    public async Task<IActionResult> Index()
    {
        var rows = new List<(string Role, int Members)>();
        foreach (var role in _roleManager.Roles.OrderBy(r => r.Name).ToList())
            rows.Add((role.Name!, (await _userManager.GetUsersInRoleAsync(role.Name!)).Count));
        ViewData["Matrix"] = PermissionMatrix.Rows;
        return View(rows);
    }

    /// <summary>The suggested permission matrix from the spec, rendered read-only.</summary>
    public static class PermissionMatrix
    {
        public static readonly (string Module, string Admin, string Manager, string Sales)[] Rows =
        {
            ("Dashboard", "Full", "Team", "Own / Assigned"),
            ("Customers", "Full", "Team / Business scope", "Own / Assigned"),
            ("Leads", "Full", "Team", "Own / Assigned"),
            ("Follow-Ups", "Full", "Team", "Own / Assigned"),
            ("Opportunities", "Full", "Team", "Own / Assigned"),
            ("User Management", "Full", "View / limited", "No"),
            ("Role Management", "Full", "No", "No"),
            ("Audit Log", "Full", "Limited view", "No"),
            ("REST API", "Authorized endpoints", "Authorized endpoints", "Authorized endpoints"),
            ("Reports", "All", "Management / team", "Own / assigned"),
        };
    }
}
