using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>Activity management: calls, meetings, emails and tasks against customers/leads.</summary>
[Authorize]
public class ActivitiesController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public ActivitiesController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /Activities — filter (type, date, status, assigned user), sort, paginate
    public async Task<IActionResult> Index(
        string? type, string? status, string? assignedTo, DateTime? date, int page = 1)
    {
        var query = _scope.ScopeActivities(
            _db.Activities.Include(a => a.Customer).Include(a => a.Lead).Include(a => a.AssignedUser), User);

        if (!string.IsNullOrWhiteSpace(type)) query = query.Where(a => a.ActivityType == type);
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(a => a.Status == status);
        if (!string.IsNullOrWhiteSpace(assignedTo)) query = query.Where(a => a.AssignedTo == assignedTo);
        if (date.HasValue) query = query.Where(a => a.ActivityDate.Date == date.Value.Date);

        query = query.OrderByDescending(a => a.ActivityDate).ThenByDescending(a => a.ActivityId);

        ViewData["Type"] = type; ViewData["Status"] = status;
        ViewData["AssignedTo"] = assignedTo; ViewData["Date"] = date?.ToString("yyyy-MM-dd");
        ViewData["Types"] = new SelectList(CrmConstants.ActivityTypes.All, type);
        ViewData["Statuses"] = new SelectList(CrmConstants.ActivityStatuses.All, status);
        ViewData["Assignees"] = new SelectList(await AssigneeListAsync(), "Id", "Display", assignedTo);
        return View(await PaginatedList<Activity>.CreateAsync(query.AsNoTracking(), page, 10));
    }

    public async Task<IActionResult> Create()
    {
        await LoadLookupsAsync();
        return View(new Activity());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Activity activity)
    {
        if (_scope.IsSalesExecutive(User)) activity.AssignedTo = _scope.UserId(User);
        await ValidateActivityAsync(activity);
        if (!ModelState.IsValid) { await LoadLookupsAsync(activity); return View(activity); }

        activity.CreatedDate = DateTime.UtcNow;
        activity.CreatedBy = User.Identity?.Name;
        _db.Activities.Add(activity);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Activity", activity.ActivityId.ToString(),
            newValue: JsonSerializer.Serialize(new { activity.ActivityType, activity.Subject }));
        TempData["Toast"] = "Activity logged.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var activity = await _scope.ScopeActivities(_db.Activities, User)
            .FirstOrDefaultAsync(a => a.ActivityId == id);
        if (activity is null) return NotFound();
        await LoadLookupsAsync(activity);
        return View(activity);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Activity activity)
    {
        if (id != activity.ActivityId) return BadRequest();
        var existing = await _scope.ScopeActivities(_db.Activities, User)
            .FirstOrDefaultAsync(a => a.ActivityId == id);
        if (existing is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { existing.Subject, existing.Status });
        existing.ActivityType = activity.ActivityType;
        existing.Subject = activity.Subject;
        existing.Description = activity.Description;
        existing.ActivityDate = activity.ActivityDate;
        existing.CustomerId = activity.CustomerId;
        existing.LeadId = activity.LeadId;
        existing.Status = activity.Status;
        if (!_scope.IsSalesExecutive(User)) existing.AssignedTo = activity.AssignedTo;

        await ValidateActivityAsync(existing);
        if (!ModelState.IsValid) { await LoadLookupsAsync(existing); return View(existing); }

        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Update, "Activity", existing.ActivityId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new { existing.Subject, existing.Status }));
        TempData["Toast"] = "Activity updated.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var activity = await _scope.ScopeActivities(
            _db.Activities.Include(a => a.Customer).Include(a => a.Lead), User)
            .FirstOrDefaultAsync(a => a.ActivityId == id);
        return activity is null ? NotFound() : View(activity);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var activity = await _scope.ScopeActivities(_db.Activities, User)
            .FirstOrDefaultAsync(a => a.ActivityId == id);
        if (activity is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { activity.Subject, activity.ActivityType });
        _db.Activities.Remove(activity);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Activity", id.ToString(), oldValue: oldSnapshot);
        TempData["Toast"] = "Activity deleted.";
        return RedirectToAction(nameof(Index));
    }

    #region Helpers
    private async Task ValidateActivityAsync(Activity activity)
    {
        if (activity.CustomerId.HasValue &&
            !await _scope.ScopeCustomers(_db.Customers, User).AnyAsync(c => c.CustomerId == activity.CustomerId.Value))
            ModelState.AddModelError(nameof(activity.CustomerId), "Please choose a valid customer.");
        if (activity.LeadId.HasValue &&
            !await _scope.ScopeLeads(_db.Leads, User).AnyAsync(l => l.LeadId == activity.LeadId.Value))
            ModelState.AddModelError(nameof(activity.LeadId), "Please choose a valid lead.");
    }

    private async Task<List<object>> AssigneeListAsync()
    {
        var sales = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        return sales.Concat(managers).OrderBy(u => u.FullName)
            .Select(u => (object)new { Id = u.Id, Display = $"{u.FullName} ({u.Email})" }).ToList();
    }

    private async Task LoadLookupsAsync(Activity? a = null)
    {
        ViewData["Types"] = new SelectList(CrmConstants.ActivityTypes.All, a?.ActivityType);
        ViewData["Statuses"] = new SelectList(CrmConstants.ActivityStatuses.All, a?.Status);
        ViewData["Customers"] = new SelectList(
            await _scope.ScopeCustomers(_db.Customers, User).OrderBy(c => c.CustomerName)
                .Select(c => new { c.CustomerId, c.CustomerName }).ToListAsync(),
            "CustomerId", "CustomerName", a?.CustomerId);
        ViewData["Leads"] = new SelectList(
            await _scope.ScopeLeads(_db.Leads, User).OrderBy(l => l.LeadName)
                .Select(l => new { l.LeadId, l.LeadName }).ToListAsync(),
            "LeadId", "LeadName", a?.LeadId);
        ViewData["Assignees"] = new SelectList(await AssigneeListAsync(), "Id", "Display", a?.AssignedTo);
    }
    #endregion
}
