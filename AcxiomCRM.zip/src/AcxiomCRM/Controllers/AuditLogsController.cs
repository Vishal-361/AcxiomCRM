using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.ViewModels;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Controllers;

/// <summary>
/// Append-only audit trail. Admin sees everything; Manager gets a limited view
/// (business events only — security events stay restricted). No edit/delete exists.
/// </summary>
[Authorize(Roles = "Admin,Manager")]
public class AuditLogsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;

    private static readonly string[] SecurityActions =
    {
        CrmConstants.AuditActions.Login, CrmConstants.AuditActions.FailedLogin,
        CrmConstants.AuditActions.Logout, CrmConstants.AuditActions.Register,
        CrmConstants.AuditActions.PasswordReset, CrmConstants.AuditActions.AccountLocked,
        CrmConstants.AuditActions.AccountUnlocked,
    };

    public AuditLogsController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope)
    {
        _db = db; _userManager = userManager; _scope = scope;
    }

    public async Task<IActionResult> Index(AuditFilterViewModel filter, int page = 1)
    {
        filter ??= new AuditFilterViewModel();
        var query = _db.AuditLogs.AsQueryable();

        // Manager: limited view — security-sensitive events are restricted.
        if (_scope.IsManager(User) && !_scope.IsAdmin(User))
            query = query.Where(a => !SecurityActions.Contains(a.Action));

        if (!string.IsNullOrWhiteSpace(filter.UserId)) query = query.Where(a => a.UserId == filter.UserId);
        if (!string.IsNullOrWhiteSpace(filter.EntityName)) query = query.Where(a => a.EntityName == filter.EntityName);
        if (!string.IsNullOrWhiteSpace(filter.Action)) query = query.Where(a => a.Action == filter.Action);
        if (filter.FromDate.HasValue) query = query.Where(a => a.CreatedDate >= filter.FromDate.Value.Date);
        if (filter.ToDate.HasValue)
            query = query.Where(a => a.CreatedDate < filter.ToDate.Value.Date.AddDays(1));

        query = query.OrderByDescending(a => a.CreatedDate);

        ViewData["Filter"] = filter;
        ViewData["Users"] = new SelectList(
            await _userManager.Users.OrderBy(u => u.FullName)
                .Select(u => new { u.Id, u.FullName }).ToListAsync(), "Id", "FullName", filter.UserId);
        ViewData["Modules"] = new SelectList(
            await _db.AuditLogs.Select(a => a.EntityName).Distinct().ToListAsync(), filter.EntityName);
        ViewData["Actions"] = new SelectList(
            await _db.AuditLogs.Select(a => a.Action).Distinct().OrderBy(a => a).ToListAsync(), filter.Action);
        ViewData["LimitedView"] = _scope.IsManager(User) && !_scope.IsAdmin(User);

        return View(await PaginatedList<AuditLog>.CreateAsync(query.AsNoTracking(), page, 15));
    }
}
