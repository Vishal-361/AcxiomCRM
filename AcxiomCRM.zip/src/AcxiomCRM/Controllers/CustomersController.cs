using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>Customer master data: create, view, edit, search, deactivate, history.</summary>
[Authorize]
public class CustomersController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public CustomersController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /Customers — search (name, email, phone, company), filter by status, sort, paginate
    public async Task<IActionResult> Index(
        string? q, string? status, string? sort = "name", int page = 1)
    {
        var query = _scope.ScopeCustomers(_db.Customers.Include(c => c.Owner), User);

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(c =>
                c.CustomerName.Contains(q) || c.Email.Contains(q) ||
                c.Phone.Contains(q) || (c.CompanyName != null && c.CompanyName.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(c => c.Status == status);

        query = sort switch
        {
            "name_desc" => query.OrderByDescending(c => c.CustomerName),
            "date" => query.OrderBy(c => c.CreatedDate),
            "date_desc" => query.OrderByDescending(c => c.CreatedDate),
            "company" => query.OrderBy(c => c.CompanyName),
            _ => query.OrderBy(c => c.CustomerName),
        };

        ViewData["Q"] = q; ViewData["Status"] = status; ViewData["Sort"] = sort;
        ViewData["Statuses"] = new SelectList(CrmConstants.CustomerStatuses.All);
        return View(await PaginatedList<Customer>.CreateAsync(query.AsNoTracking(), page, 10));
    }

    // GET: /Customers/Details/5 — customer history + related activities
    public async Task<IActionResult> Details(int id)
    {
        var customer = await _scope.ScopeCustomers(
            _db.Customers.Include(c => c.Owner), User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null) return NotFound();

        ViewData["FollowUps"] = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .Where(f => f.CustomerId == id)
            .OrderByDescending(f => f.FollowUpDate).Take(10).ToListAsync();
        ViewData["Activities"] = await _scope.ScopeActivities(_db.Activities, User)
            .Where(a => a.CustomerId == id)
            .OrderByDescending(a => a.ActivityDate).Take(10).ToListAsync();
        ViewData["Opportunities"] = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .Where(o => o.CustomerId == id)
            .OrderByDescending(o => o.CreatedDate).Take(10).ToListAsync();
        return View(customer);
    }

    public async Task<IActionResult> Create()
    {
        await LoadOwnerListAsync();
        return View(new Customer());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Customer customer)
    {
        // Server-side duplicate + business checks (client rules can be bypassed).
        await ValidateCustomerAsync(customer, isNew: true);
        if (!ModelState.IsValid)
        {
            await LoadOwnerListAsync(customer.OwnerId);
            return View(customer);
        }

        customer.CustomerCode = await NextCodeAsync("CUST");
        customer.CreatedDate = DateTime.UtcNow;
        customer.CreatedBy = User.Identity?.Name;

        // Sales executives always own what they create.
        if (_scope.IsSalesExecutive(User))
            customer.OwnerId = _scope.UserId(User);

        _db.Customers.Add(customer);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Customer", customer.CustomerId.ToString(),
            newValue: JsonSerializer.Serialize(new { customer.CustomerName, customer.Email }));
        TempData["Toast"] = $"Customer “{customer.CustomerName}” saved — nicely done.";
        return RedirectToAction(nameof(Details), new { id = customer.CustomerId });
    }

    public async Task<IActionResult> Edit(int id)
    {
        var customer = await _scope.ScopeCustomers(_db.Customers, User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null) return NotFound();
        await LoadOwnerListAsync(customer.OwnerId);
        return View(customer);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Customer customer)
    {
        if (id != customer.CustomerId) return BadRequest();
        var existing = await _scope.ScopeCustomers(_db.Customers, User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (existing is null) return NotFound(); // manipulated request → rejected

        var oldSnapshot = JsonSerializer.Serialize(new { existing.CustomerName, existing.Email, existing.Status });

        // Bind only editable fields onto the tracked entity (over-posting protection).
        existing.CustomerName = customer.CustomerName;
        existing.Email = customer.Email;
        existing.Phone = customer.Phone;
        existing.CompanyName = customer.CompanyName;
        existing.Address = customer.Address;
        existing.City = customer.City;
        existing.State = customer.State;
        existing.Status = customer.Status;
        existing.Notes = customer.Notes;
        existing.ModifiedDate = DateTime.UtcNow;
        if (!_scope.IsSalesExecutive(User))
            existing.OwnerId = customer.OwnerId;

        await ValidateCustomerAsync(existing, isNew: false);
        // Track important status changes explicitly.
        var statusChanged = !string.Equals(
            JsonSerializer.Deserialize<Dictionary<string, string>>(oldSnapshot)?["Status"],
            existing.Status, StringComparison.Ordinal);

        if (!ModelState.IsValid)
        {
            await LoadOwnerListAsync(existing.OwnerId);
            return View(existing);
        }

        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            statusChanged ? CrmConstants.AuditActions.StatusChange : CrmConstants.AuditActions.Update,
            "Customer", existing.CustomerId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new { existing.CustomerName, existing.Email, existing.Status }));
        TempData["Toast"] = "Changes saved.";
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Delete(int id)
    {
        var customer = await _scope.ScopeCustomers(
            _db.Customers.Include(c => c.Owner), User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        return customer is null ? NotFound() : View(customer);
    }

    // Deactivation (soft delete) — history stays intact, record leaves active lists.
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var customer = await _scope.ScopeCustomers(_db.Customers, User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { customer.CustomerName, customer.Status });
        customer.Status = CrmConstants.CustomerStatuses.Inactive;
        customer.ModifiedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Customer", customer.CustomerId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new { customer.CustomerName, customer.Status }));
        TempData["Toast"] = $"“{customer.CustomerName}” moved to Inactive — their history is still safe.";
        return RedirectToAction(nameof(Index));
    }

    #region Helpers
    private async Task ValidateCustomerAsync(Customer customer, bool isNew)
    {
        // Duplicate prevention: email & phone uniqueness (also enforced by DB indexes).
        if (await _db.Customers.AnyAsync(c => c.CustomerId != customer.CustomerId &&
                                              c.Email.ToLower() == customer.Email.ToLower()))
            ModelState.AddModelError(nameof(customer.Email),
                "This email is already used by another customer.");

        if (await _db.Customers.AnyAsync(c => c.CustomerId != customer.CustomerId &&
                                              c.Phone == customer.Phone))
            ModelState.AddModelError(nameof(customer.Phone),
                "This phone number is already used by another customer.");

        // Same business-identifying customer cannot be created twice.
        if (isNew && await _db.Customers.AnyAsync(c =>
                c.CustomerName.ToLower() == customer.CustomerName.ToLower() &&
                (c.CompanyName ?? "").ToLower() == (customer.CompanyName ?? "").ToLower()))
            ModelState.AddModelError(nameof(customer.CustomerName),
                "A customer with this name and company already exists.");

        if (!string.IsNullOrEmpty(customer.OwnerId) &&
            await _userManager.FindByIdAsync(customer.OwnerId) is null)
            ModelState.AddModelError(nameof(customer.OwnerId), "Please choose a valid sales executive.");
    }

    private async Task<string> NextCodeAsync(string prefix)
    {
        var count = await _db.Customers.CountAsync();
        string code;
        do { code = $"{prefix}-{(count + 1):D4}"; count++; }
        while (await _db.Customers.AnyAsync(c => c.CustomerCode == code));
        return code;
    }

    private async Task LoadOwnerListAsync(string? selected = null)
    {
        var salesPeople = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        var all = salesPeople.Concat(managers).OrderBy(u => u.FullName)
            .Select(u => new { u.Id, Display = $"{u.FullName} ({u.Email})" });
        ViewData["Owners"] = new SelectList(all, "Id", "Display", selected);
    }
    #endregion
}
