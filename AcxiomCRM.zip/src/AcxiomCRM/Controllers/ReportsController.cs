using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace AcxiomCRM.Controllers;

/// <summary>
/// All eight spec reports. Every report honours the caller's data scope,
/// supports filters/sorting/pagination, and can be exported to CSV.
/// </summary>
[Authorize]
public class ReportsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;

    public ReportsController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope)
    {
        _db = db; _userManager = userManager; _scope = scope;
    }

    public IActionResult Index() => View();

    #region Customer report
    public async Task<IActionResult> Customers(
        string? status, string? ownerId, DateTime? from, DateTime? to,
        string sort = "name", int page = 1, string? export = null)
    {
        var query = _scope.ScopeCustomers(_db.Customers.Include(c => c.Owner), User);
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(c => c.Status == status);
        if (!string.IsNullOrWhiteSpace(ownerId)) query = query.Where(c => c.OwnerId == ownerId);
        if (from.HasValue) query = query.Where(c => c.CreatedDate >= from.Value.Date);
        if (to.HasValue) query = query.Where(c => c.CreatedDate < to.Value.Date.AddDays(1));

        query = sort switch
        {
            "date_desc" => query.OrderByDescending(c => c.CreatedDate),
            "company" => query.OrderBy(c => c.CompanyName),
            _ => query.OrderBy(c => c.CustomerName),
        };

        if (export == "csv")
            return Csv("customer-report.csv",
                new[] { "Code", "Name", "Email", "Phone", "Company", "City", "Status", "Owner", "Created" },
                await query.Select(c => new[]
                {
                    c.CustomerCode, c.CustomerName, c.Email, c.Phone, c.CompanyName ?? "",
                    c.City ?? "", c.Status, c.Owner != null ? c.Owner.FullName : "", c.CreatedDate.ToString("yyyy-MM-dd")
                }).ToListAsync());

        await LoadCommonFiltersAsync(status, ownerId, from, to);
        ViewData["Sort"] = sort;
        ViewData["Statuses"] = new SelectList(CrmConstants.CustomerStatuses.All, status);
        return View(await PaginatedList<Customer>.CreateAsync(query.AsNoTracking(), page, 15));
    }
    #endregion

    #region Lead report
    public async Task<IActionResult> Leads(
        string? source, string? status, string? ownerId, bool? converted,
        string sort = "date_desc", int page = 1, string? export = null)
    {
        var query = _scope.ScopeLeads(_db.Leads.Include(l => l.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(source)) query = query.Where(l => l.Source == source);
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(l => l.Status == status);
        if (!string.IsNullOrWhiteSpace(ownerId)) query = query.Where(l => l.AssignedTo == ownerId);
        if (converted.HasValue)
            query = converted.Value
                ? query.Where(l => l.Status == CrmConstants.LeadStatuses.Converted)
                : query.Where(l => l.Status != CrmConstants.LeadStatuses.Converted);

        query = sort switch
        {
            "value_desc" => query.OrderByDescending(l => l.ExpectedValue),
            "name" => query.OrderBy(l => l.LeadName),
            _ => query.OrderByDescending(l => l.CreatedDate),
        };

        if (export == "csv")
            return Csv("lead-report.csv",
                new[] { "Code", "Name", "Email", "Phone", "Company", "Source", "Status", "Priority", "ExpectedValue", "Owner", "Created" },
                await query.Select(l => new[]
                {
                    l.LeadCode, l.LeadName, l.Email ?? "", l.Phone ?? "", l.CompanyName ?? "",
                    l.Source ?? "", l.Status, l.Priority, l.ExpectedValue.ToString("F2"),
                    l.AssignedUser != null ? l.AssignedUser.FullName : "", l.CreatedDate.ToString("yyyy-MM-dd")
                }).ToListAsync());

        ViewData["Sort"] = sort; ViewData["Source"] = source;
        ViewData["Status"] = status; ViewData["OwnerId"] = ownerId; ViewData["Converted"] = converted;
        ViewData["Sources"] = new SelectList(CrmConstants.LeadSources.All, source);
        ViewData["Statuses"] = new SelectList(CrmConstants.LeadStatuses.All, status);
        ViewData["Owners"] = new SelectList(await OwnerListAsync(), "Id", "Display", ownerId);
        return View(await PaginatedList<Lead>.CreateAsync(query.AsNoTracking(), page, 15));
    }
    #endregion

    #region Follow-up report
    public async Task<IActionResult> FollowUps(
        string? status, string? ownerId, DateTime? from, DateTime? to,
        bool? overdueOnly, int page = 1, string? export = null)
    {
        var query = _scope.ScopeFollowUps(
            _db.FollowUps.Include(f => f.Customer).Include(f => f.Lead).Include(f => f.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(f => f.Status == status);
        if (!string.IsNullOrWhiteSpace(ownerId)) query = query.Where(f => f.AssignedTo == ownerId);
        if (from.HasValue) query = query.Where(f => f.FollowUpDate >= from.Value.Date);
        if (to.HasValue) query = query.Where(f => f.FollowUpDate < to.Value.Date.AddDays(1));
        if (overdueOnly == true)
            query = query.Where(f => f.Status == CrmConstants.FollowUpStatuses.Planned
                && f.FollowUpDate.Date < DateTime.Today);

        query = query.OrderBy(f => f.FollowUpDate);

        if (export == "csv")
            return Csv("followup-report.csv",
                new[] { "Date", "Subject", "Type", "Status", "Related", "Owner", "Overdue" },
                await query.Select(f => new[]
                {
                    f.FollowUpDate.ToString("yyyy-MM-dd"), f.Subject, f.FollowUpType, f.Status,
                    f.Customer != null ? f.Customer.CustomerName : f.Lead != null ? f.Lead.LeadName : "",
                    f.AssignedUser != null ? f.AssignedUser.FullName : "",
                    (f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date < DateTime.Today) ? "Yes" : "No"
                }).ToListAsync());

        await LoadCommonFiltersAsync(status, ownerId, from, to);
        ViewData["Statuses"] = new SelectList(CrmConstants.FollowUpStatuses.All, status);
        ViewData["OverdueOnly"] = overdueOnly == true;
        return View(await PaginatedList<FollowUp>.CreateAsync(query.AsNoTracking(), page, 15));
    }
    #endregion

    #region Opportunity report
    public async Task<IActionResult> Opportunities(
        string? stage, string? ownerId, DateTime? closeFrom, DateTime? closeTo,
        string sort = "close", int page = 1, string? export = null)
    {
        var query = _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer).Include(o => o.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(stage)) query = query.Where(o => o.Stage == stage);
        if (!string.IsNullOrWhiteSpace(ownerId)) query = query.Where(o => o.AssignedTo == ownerId);
        if (closeFrom.HasValue) query = query.Where(o => o.ExpectedCloseDate >= closeFrom.Value.Date);
        if (closeTo.HasValue) query = query.Where(o => o.ExpectedCloseDate < closeTo.Value.Date.AddDays(1));

        query = sort switch
        {
            "amount_desc" => query.OrderByDescending(o => o.Amount),
            "probability_desc" => query.OrderByDescending(o => o.Probability),
            _ => query.OrderBy(o => o.ExpectedCloseDate),
        };

        if (export == "csv")
            return Csv("opportunity-report.csv",
                new[] { "Name", "Customer", "Stage", "Amount", "Probability", "Weighted", "ExpectedClose", "Owner", "Created" },
                await query.Select(o => new[]
                {
                    o.OpportunityName, o.Customer != null ? o.Customer.CustomerName : "",
                    o.Stage, o.Amount.ToString("F2"), o.Probability.ToString(),
                    (o.Amount * o.Probability / 100m).ToString("F2"),
                    o.ExpectedCloseDate.ToString("yyyy-MM-dd"),
                    o.AssignedUser != null ? o.AssignedUser.FullName : "",
                    o.CreatedDate.ToString("yyyy-MM-dd")
                }).ToListAsync());

        ViewData["Sort"] = sort; ViewData["Stage"] = stage;
        ViewData["OwnerId"] = ownerId; ViewData["CloseFrom"] = closeFrom?.ToString("yyyy-MM-dd");
        ViewData["CloseTo"] = closeTo?.ToString("yyyy-MM-dd");
        ViewData["Stages"] = new SelectList(CrmConstants.OpportunityStages.All, stage);
        ViewData["Owners"] = new SelectList(await OwnerListAsync(), "Id", "Display", ownerId);
        return View(await PaginatedList<Opportunity>.CreateAsync(query.AsNoTracking(), page, 15));
    }
    #endregion

    #region Pipeline report (stage-wise + owner-wise, weighted)
    [Authorize(Roles = "Admin,Manager,SalesExecutive")]
    public async Task<IActionResult> Pipeline()
    {
        var opps = _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.AssignedUser), User)
            .Where(o => o.Stage != CrmConstants.OpportunityStages.Won
                     && o.Stage != CrmConstants.OpportunityStages.Lost);

        var byStage = await opps
            .GroupBy(o => o.Stage)
            .Select(g => new PipelineRow
            {
                Label = g.Key, Count = g.Count(),
                Amount = (decimal)g.Sum(o => (double)o.Amount),
                Weighted = (decimal)g.Sum(o => (double)(o.Amount * o.Probability / 100m)),
            }).ToListAsync();

        var byOwner = await opps
            .GroupBy(o => o.AssignedUser != null ? o.AssignedUser.FullName : "Unassigned")
            .Select(g => new PipelineRow
            {
                Label = g.Key, Count = g.Count(),
                Amount = (decimal)g.Sum(o => (double)o.Amount),
                Weighted = (decimal)g.Sum(o => (double)(o.Amount * o.Probability / 100m)),
            }).ToListAsync();

        // Keep every stage visible even when empty — an honest pipeline shows its gaps.
        foreach (var s in CrmConstants.OpportunityStages.All.Where(s =>
                     s != CrmConstants.OpportunityStages.Won && s != CrmConstants.OpportunityStages.Lost))
            if (!byStage.Any(r => r.Label == s))
                byStage.Add(new PipelineRow { Label = s });

        ViewData["ByStage"] = byStage.OrderBy(r =>
            Array.IndexOf(CrmConstants.OpportunityStages.All, r.Label)).ToList();
        ViewData["ByOwner"] = byOwner.OrderByDescending(r => r.Amount).ToList();
        return View();
    }

    public class PipelineRow
    {
        public string Label { get; set; } = "";
        public int Count { get; set; }
        public decimal Amount { get; set; }
        public decimal Weighted { get; set; }
    }
    #endregion

    #region Conversion report (lead conversion + opportunity outcomes)
    [Authorize(Roles = "Admin,Manager,SalesExecutive")]
    public async Task<IActionResult> Conversion()
    {
        var leads = _scope.ScopeLeads(_db.Leads, User);
        var total = await leads.CountAsync();
        var converted = await leads.CountAsync(l => l.Status == CrmConstants.LeadStatuses.Converted);
        var byStatus = await leads.GroupBy(l => l.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() }).ToListAsync();

        var opps = _scope.ScopeOpportunities(_db.Opportunities, User);
        var won = await opps.CountAsync(o => o.Stage == CrmConstants.OpportunityStages.Won);
        var lost = await opps.CountAsync(o => o.Stage == CrmConstants.OpportunityStages.Lost);
        var oppTotal = await opps.CountAsync();

        ViewData["LeadTotal"] = total;
        ViewData["LeadConverted"] = converted;
        ViewData["LeadRate"] = total == 0 ? 0 : Math.Round(converted * 100m / total, 1);
        ViewData["LeadByStatus"] = byStatus.OrderByDescending(x => x.Count).ToList();
        ViewData["OppWon"] = won;
        ViewData["OppLost"] = lost;
        ViewData["OppTotal"] = oppTotal;
        ViewData["WinRate"] = (won + lost) == 0 ? 0 : Math.Round(won * 100m / (won + lost), 1);
        return View();
    }
    #endregion

    #region User activity report
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> UserActivity(DateTime? from, DateTime? to, string? export = null)
    {
        from ??= DateTime.Today.AddDays(-30);
        to ??= DateTime.Today;
        var fromDate = from.Value.Date;
        var toDate = to.Value.Date.AddDays(1);

        var rows = await _db.AuditLogs
            .Where(a => a.CreatedDate >= fromDate && a.CreatedDate < toDate)
            .GroupBy(a => new { a.UserId, a.UserName })
            .Select(g => new UserActivityRow
            {
                UserName = g.Key.UserName ?? "(system)",
                TotalActions = g.Count(),
                Logins = g.Count(a => a.Action == CrmConstants.AuditActions.Login),
                Creates = g.Count(a => a.Action == CrmConstants.AuditActions.Create),
                Updates = g.Count(a => a.Action == CrmConstants.AuditActions.Update),
                Deletes = g.Count(a => a.Action == CrmConstants.AuditActions.Delete),
            })
            .OrderByDescending(r => r.TotalActions)
            .ToListAsync();

        if (export == "csv")
            return Csv("user-activity-report.csv",
                new[] { "User", "TotalActions", "Logins", "Creates", "Updates", "Deletes" },
                rows.Select(r => new[]
                {
                    r.UserName, r.TotalActions.ToString(), r.Logins.ToString(),
                    r.Creates.ToString(), r.Updates.ToString(), r.Deletes.ToString()
                }).ToList());

        ViewData["From"] = from?.ToString("yyyy-MM-dd");
        ViewData["To"] = to?.ToString("yyyy-MM-dd");
        return View(rows);
    }

    public class UserActivityRow
    {
        public string UserName { get; set; } = "";
        public int TotalActions { get; set; }
        public int Logins { get; set; }
        public int Creates { get; set; }
        public int Updates { get; set; }
        public int Deletes { get; set; }
    }
    #endregion

    #region Audit report (Admin only — full security + business events)
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Audit(DateTime? from, DateTime? to, string? action, int page = 1)
    {
        from ??= DateTime.Today.AddDays(-30);
        to ??= DateTime.Today;
        var query = _db.AuditLogs.AsQueryable()
            .Where(a => a.CreatedDate >= from.Value.Date && a.CreatedDate < to.Value.Date.AddDays(1));
        if (!string.IsNullOrWhiteSpace(action)) query = query.Where(a => a.Action == action);
        query = query.OrderByDescending(a => a.CreatedDate);

        ViewData["From"] = from?.ToString("yyyy-MM-dd");
        ViewData["To"] = to?.ToString("yyyy-MM-dd");
        ViewData["Action"] = action;
        ViewData["Actions"] = new SelectList(
            await _db.AuditLogs.Select(a => a.Action).Distinct().OrderBy(a => a).ToListAsync(), action);
        return View(await PaginatedList<AuditLog>.CreateAsync(query.AsNoTracking(), page, 20));
    }
    #endregion

    #region Helpers
    private async Task LoadCommonFiltersAsync(string? status, string? ownerId, DateTime? from, DateTime? to)
    {
        ViewData["Status"] = status; ViewData["OwnerId"] = ownerId;
        ViewData["From"] = from?.ToString("yyyy-MM-dd"); ViewData["To"] = to?.ToString("yyyy-MM-dd");
        ViewData["Owners"] = new SelectList(await OwnerListAsync(), "Id", "Display", ownerId);
    }

    private async Task<List<object>> OwnerListAsync()
    {
        // Managers/Admins may filter by anyone; sales users only ever see themselves.
        if (_scope.IsSalesExecutive(User))
        {
            var me = await _userManager.FindByIdAsync(_scope.UserId(User) ?? "");
            return me is null ? new() : new() { new { Id = me.Id, Display = $"{me.FullName} ({me.Email})" } };
        }
        var sales = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        return sales.Concat(managers).OrderBy(u => u.FullName)
            .Select(u => (object)new { Id = u.Id, Display = $"{u.FullName} ({u.Email})" }).ToList();
    }

    private static FileResult Csv(string fileName, string[] headers, List<string[]> rows)
    {
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(",", headers.Select(Escape)));
        foreach (var row in rows)
            sb.AppendLine(string.Join(",", row.Select(Escape)));
        return new FileContentResult(Encoding.UTF8.GetBytes(sb.ToString()), "text/csv")
        {
            FileDownloadName = fileName
        };

        static string Escape(string? v)
        {
            v ??= "";
            return v.Contains(',') || v.Contains('"') || v.Contains('\n')
                ? $"\"{v.Replace("\"", "\"\"")}\"" : v;
        }
    }
    #endregion
}
