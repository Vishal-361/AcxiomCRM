using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Secured follow-up endpoints, including completion.</summary>
[Authorize]
 [Route("api/followups")]
public class FollowUpsApiController : ApiBaseController
{
    private readonly ApplicationDbContext _db;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public FollowUpsApiController(
        ApplicationDbContext db, IScopeService scope, IAuditService audit)
    {
        _db = db; _scope = scope; _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<FollowUpDto>>> List(
        [FromQuery] string? status, [FromQuery] bool? overdue,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = _scope.ScopeFollowUps(
            _db.FollowUps.Include(f => f.Customer).Include(f => f.Lead).Include(f => f.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(f => f.Status == status);
        if (overdue == true)
            query = query.Where(f => f.Status == CrmConstants.FollowUpStatuses.Planned
                && f.FollowUpDate.Date < DateTime.Today);

        var total = await query.CountAsync();
        var items = await query.OrderBy(f => f.FollowUpDate)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<FollowUpDto>
        {
            Items = items.Select(ToDto).ToList(),
            Page = page, PageSize = pageSize, TotalCount = total,
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<FollowUpDto>> Get(int id)
    {
        var fu = await _scope.ScopeFollowUps(
            _db.FollowUps.Include(f => f.Customer).Include(f => f.Lead).Include(f => f.AssignedUser), User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        return fu is null ? NotFoundResource("Follow-up") : Ok(ToDto(fu));
    }

    [HttpPost]
    public async Task<ActionResult<FollowUpDto>> Create([FromBody] FollowUpCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var error = await ValidateAsync(dto.RelatedType, dto.CustomerId, dto.LeadId,
            dto.FollowUpType, dto.FollowUpDate);
        if (error is not null) return Error(400, error);

        var fu = new FollowUp
        {
            RelatedType = dto.RelatedType,
            CustomerId = dto.CustomerId, LeadId = dto.LeadId,
            FollowUpDate = dto.FollowUpDate.Date,
            Subject = dto.Subject.Trim(), FollowUpType = dto.FollowUpType,
            Status = CrmConstants.FollowUpStatuses.Planned,
            Remarks = dto.Remarks?.Trim(),
            AssignedTo = _scope.IsSalesExecutive(User) ? _scope.UserId(User) : dto.AssignedTo,
            CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
        };
        _db.FollowUps.Add(fu);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "FollowUp", fu.FollowUpId.ToString(),
            newValue: JsonSerializer.Serialize(new { fu.Subject, fu.FollowUpDate }));
        return CreatedAtAction(nameof(Get), new { id = fu.FollowUpId }, ToDto(fu));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<FollowUpDto>> Update(int id, [FromBody] FollowUpUpdateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null)
            return await _db.FollowUps.AnyAsync(f => f.FollowUpId == id)
                ? ForbiddenResource() : NotFoundResource("Follow-up");

        var error = await ValidateAsync(dto.RelatedType, dto.CustomerId, dto.LeadId,
            dto.FollowUpType, dto.FollowUpDate, allowPast: true);
        if (error is not null) return Error(400, error);
        if (!CrmConstants.FollowUpStatuses.All.Contains(dto.Status))
            return Error(400, "Please choose a valid status.");

        var old = JsonSerializer.Serialize(new { fu.Subject, fu.FollowUpDate, fu.Status });
        fu.RelatedType = dto.RelatedType;
        fu.CustomerId = dto.CustomerId; fu.LeadId = dto.LeadId;
        fu.FollowUpDate = dto.FollowUpDate.Date;
        fu.Subject = dto.Subject.Trim(); fu.FollowUpType = dto.FollowUpType;
        fu.Status = dto.Status; fu.Remarks = dto.Remarks?.Trim();
        if (dto.Status == CrmConstants.FollowUpStatuses.Completed && fu.CompletedDate is null)
            fu.CompletedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Update, "FollowUp", id.ToString(), oldValue: old,
            newValue: JsonSerializer.Serialize(new { fu.Subject, fu.FollowUpDate, fu.Status }));
        return Ok(ToDto(fu));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null)
            return await _db.FollowUps.AnyAsync(f => f.FollowUpId == id)
                ? ForbiddenResource() : NotFoundResource("Follow-up");

        var old = JsonSerializer.Serialize(new { fu.Subject, fu.Status });
        _db.FollowUps.Remove(fu);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "FollowUp", id.ToString(), oldValue: old);
        return Ok(new { message = "Follow-up deleted." });
    }

    [HttpPost("{id:int}/complete")]
    public async Task<ActionResult<FollowUpDto>> Complete(int id)
    {
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null)
            return await _db.FollowUps.AnyAsync(f => f.FollowUpId == id)
                ? ForbiddenResource() : NotFoundResource("Follow-up");

        fu.Status = CrmConstants.FollowUpStatuses.Completed;
        fu.CompletedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Complete, "FollowUp", id.ToString(),
            newValue: JsonSerializer.Serialize(new { fu.Status }));
        return Ok(ToDto(fu));
    }

    #region Rules + mapping
    private async Task<string?> ValidateAsync(string relatedType, int? customerId, int? leadId,
        string type, DateTime date, bool allowPast = false)
    {
        if (relatedType is not ("Customer" or "Lead"))
            return "RelatedType must be Customer or Lead.";
        if (customerId is null && leadId is null)
            return "Please attach this follow-up to a customer or a lead.";
        if (!CrmConstants.FollowUpTypes.All.Contains(type))
            return "Please choose a valid follow-up type.";
        if (!allowPast && date.Date < DateTime.Today)
            return "Follow-up date cannot be earlier than today.";
        if (customerId.HasValue &&
            !await _scope.ScopeCustomers(_db.Customers, User).AnyAsync(c => c.CustomerId == customerId.Value))
            return "Please choose a valid customer.";
        if (leadId.HasValue &&
            !await _scope.ScopeLeads(_db.Leads, User).AnyAsync(l => l.LeadId == leadId.Value))
            return "Please choose a valid lead.";
        return null;
    }

    private static FollowUpDto ToDto(FollowUp f) => new()
    {
        FollowUpId = f.FollowUpId, RelatedType = f.RelatedType,
        RelatedName = f.Customer != null ? f.Customer.CustomerName : f.Lead?.LeadName,
        FollowUpDate = f.FollowUpDate, Subject = f.Subject,
        FollowUpType = f.FollowUpType, Status = f.Status,
        AssignedToName = f.AssignedUser?.FullName,
        IsOverdue = f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date < DateTime.Today,
    };
    #endregion
}
