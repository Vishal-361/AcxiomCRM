using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Secured lead endpoints, including the lead → customer conversion workflow.</summary>
[Authorize]
 [Route("api/leads")]
public class LeadsApiController : ApiBaseController
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public LeadsApiController(
        ApplicationDbContext db, UserManager<ApplicationUser> userManager,
        IScopeService scope, IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<LeadDto>>> List(
        [FromQuery] string? q, [FromQuery] string? status,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = _scope.ScopeLeads(_db.Leads.Include(l => l.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(l => l.LeadName.Contains(q)
                || (l.CompanyName != null && l.CompanyName.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(l => l.Status == status);

        var total = await query.CountAsync();
        var items = await query.OrderByDescending(l => l.CreatedDate)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<LeadDto>
        {
            Items = items.Select(ToDto).ToList(),
            Page = page, PageSize = pageSize, TotalCount = total,
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<LeadDto>> Get(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads.Include(l => l.AssignedUser), User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        return lead is null ? NotFoundResource("Lead") : Ok(ToDto(lead));
    }

    [HttpPost]
    public async Task<ActionResult<LeadDto>> Create([FromBody] LeadCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        if (dto.Source is not null && !CrmConstants.LeadSources.All.Contains(dto.Source))
            return Error(400, "Please choose a valid lead source.");
        if (!CrmConstants.LeadPriorities.All.Contains(dto.Priority))
            return Error(400, "Please choose a valid priority.");

        var lead = new Lead
        {
            LeadCode = await NextCodeAsync(),
            LeadName = dto.LeadName.Trim(),
            Email = dto.Email?.Trim(), Phone = dto.Phone?.Trim(),
            CompanyName = dto.CompanyName?.Trim(), Source = dto.Source,
            Status = CrmConstants.LeadStatuses.New,
            Priority = dto.Priority, ExpectedValue = dto.ExpectedValue,
            Notes = dto.Notes?.Trim(),
            AssignedTo = _scope.IsSalesExecutive(User) ? _scope.UserId(User) : dto.AssignedTo,
            CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
        };
        _db.Leads.Add(lead);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Lead", lead.LeadId.ToString(),
            newValue: JsonSerializer.Serialize(new { lead.LeadName, lead.Status }));
        return CreatedAtAction(nameof(Get), new { id = lead.LeadId }, ToDto(lead));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<LeadDto>> Update(int id, [FromBody] LeadUpdateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null)
            return await _db.Leads.AnyAsync(l => l.LeadId == id)
                ? ForbiddenResource() : NotFoundResource("Lead");

        if (!CrmConstants.LeadStatuses.All.Contains(dto.Status))
            return Error(400, "Please choose a valid lead status.");
        if (!CrmConstants.LeadStatuses.CanTransition(lead.Status, dto.Status))
            return Error(400, $"A lead cannot move from “{lead.Status}” to “{dto.Status}”.");

        var old = JsonSerializer.Serialize(new { lead.LeadName, lead.Status });
        lead.LeadName = dto.LeadName.Trim();
        lead.Email = dto.Email?.Trim(); lead.Phone = dto.Phone?.Trim();
        lead.CompanyName = dto.CompanyName?.Trim(); lead.Source = dto.Source;
        lead.Status = dto.Status; lead.Priority = dto.Priority;
        lead.ExpectedValue = dto.ExpectedValue; lead.Notes = dto.Notes?.Trim();
        lead.ModifiedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.StatusChange, "Lead", id.ToString(), oldValue: old,
            newValue: JsonSerializer.Serialize(new { lead.LeadName, lead.Status }));
        return Ok(ToDto(lead));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null)
            return await _db.Leads.AnyAsync(l => l.LeadId == id)
                ? ForbiddenResource() : NotFoundResource("Lead");

        var old = JsonSerializer.Serialize(new { lead.LeadName, lead.Status });
        _db.Leads.Remove(lead);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Lead", id.ToString(), oldValue: old);
        return Ok(new { message = "Lead deleted." });
    }

    /// <summary>Convert a Qualified lead into a customer (and an opening opportunity).</summary>
    [HttpPost("{id:int}/convert")]
    public async Task<IActionResult> Convert(int id, [FromQuery] bool createOpportunity = true)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null)
            return await _db.Leads.AnyAsync(l => l.LeadId == id)
                ? ForbiddenResource() : NotFoundResource("Lead");
        if (lead.Status != CrmConstants.LeadStatuses.Qualified)
            return Error(400, "Only a Qualified lead can be converted.");

        var customer = new Customer
        {
            CustomerCode = await NextCustomerCodeAsync(),
            CustomerName = lead.LeadName,
            Email = string.IsNullOrWhiteSpace(lead.Email) ? $"{lead.LeadCode}@converted.local" : lead.Email!,
            Phone = string.IsNullOrWhiteSpace(lead.Phone) ? "9000000000" : lead.Phone!,
            CompanyName = lead.CompanyName,
            Status = CrmConstants.CustomerStatuses.Active,
            OwnerId = lead.AssignedTo,
            Notes = $"Converted from lead {lead.LeadCode}.",
            CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
        };
        _db.Customers.Add(customer);

        int? oppId = null;
        if (createOpportunity)
        {
            var opp = new Opportunity
            {
                OpportunityName = $"{lead.LeadName} — New business",
                Customer = customer, LeadId = lead.LeadId,
                Amount = lead.ExpectedValue > 0 ? lead.ExpectedValue : 1,
                Stage = CrmConstants.OpportunityStages.Qualification,
                Probability = 20, ExpectedCloseDate = DateTime.Today.AddDays(30),
                Source = lead.Source, AssignedTo = lead.AssignedTo,
                CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
            };
            _db.Opportunities.Add(opp);
            await _db.SaveChangesAsync();
            oppId = opp.OpportunityId;
        }
        else await _db.SaveChangesAsync();

        lead.Status = CrmConstants.LeadStatuses.Converted;
        lead.ConvertedDate = DateTime.UtcNow;
        lead.ConvertedCustomerId = customer.CustomerId;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Convert, "Lead", id.ToString(),
            newValue: JsonSerializer.Serialize(new { CustomerId = customer.CustomerId, OpportunityId = oppId }));
        return Ok(new
        {
            message = "Lead converted.",
            customerId = customer.CustomerId,
            opportunityId = oppId,
        });
    }

    #region Mapping
    private static LeadDto ToDto(Lead l) => new()
    {
        LeadId = l.LeadId, LeadCode = l.LeadCode, LeadName = l.LeadName,
        Email = l.Email, Phone = l.Phone, CompanyName = l.CompanyName,
        Source = l.Source, Status = l.Status, Priority = l.Priority,
        ExpectedValue = l.ExpectedValue, AssignedToName = l.AssignedUser?.FullName,
        CreatedDate = l.CreatedDate,
    };

    private async Task<string> NextCodeAsync()
    {
        var count = await _db.Leads.CountAsync();
        string code;
        do { code = $"LEAD-{(count + 1):D4}"; count++; }
        while (await _db.Leads.AnyAsync(l => l.LeadCode == code));
        return code;
    }

    private async Task<string> NextCustomerCodeAsync()
    {
        var count = await _db.Customers.CountAsync();
        string code;
        do { code = $"CUST-{(count + 1):D4}"; count++; }
        while (await _db.Customers.AnyAsync(c => c.CustomerCode == code));
        return code;
    }
    #endregion
}
