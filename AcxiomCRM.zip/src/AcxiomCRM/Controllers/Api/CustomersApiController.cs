using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Secured customer endpoints. DTOs in, DTOs out — entities never leave the server.</summary>
[Authorize]
 [Route("api/customers")]
public class CustomersApiController : ApiBaseController
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public CustomersApiController(
        ApplicationDbContext db, UserManager<ApplicationUser> userManager,
        IScopeService scope, IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<CustomerDto>>> List(
        [FromQuery] string? q, [FromQuery] string? status,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = _scope.ScopeCustomers(_db.Customers.Include(c => c.Owner), User);
        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(c => c.CustomerName.Contains(q) || c.Email.Contains(q)
                || c.Phone.Contains(q) || (c.CompanyName != null && c.CompanyName.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(c => c.Status == status);

        var total = await query.CountAsync();
        var items = await query.OrderBy(c => c.CustomerName)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<CustomerDto>
        {
            Items = items.Select(ToDto).ToList(),
            Page = page, PageSize = pageSize, TotalCount = total,
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<CustomerDto>> Get(int id)
    {
        var customer = await _scope.ScopeCustomers(_db.Customers.Include(c => c.Owner), User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        return customer is null ? NotFoundResource("Customer") : Ok(ToDto(customer));
    }

    [HttpPost]
    public async Task<ActionResult<CustomerDto>> Create([FromBody] CustomerCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();

        var email = dto.Email.Trim();
        var phone = dto.Phone.Trim();
        if (await _db.Customers.AnyAsync(c => c.Email.ToLower() == email.ToLower()))
            return ConflictResource("This email is already used by another customer.");
        if (await _db.Customers.AnyAsync(c => c.Phone == phone))
            return ConflictResource("This phone number is already used by another customer.");

        var customer = new Customer
        {
            CustomerCode = await NextCodeAsync(),
            CustomerName = dto.CustomerName.Trim(),
            Email = email, Phone = phone,
            CompanyName = dto.CompanyName?.Trim(), Address = dto.Address?.Trim(),
            City = dto.City?.Trim(), State = dto.State?.Trim(),
            Status = CrmConstants.CustomerStatuses.Active,
            Notes = dto.Notes?.Trim(),
            CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
            OwnerId = _scope.IsSalesExecutive(User) ? _scope.UserId(User) : dto.OwnerId,
        };
        if (!string.IsNullOrEmpty(customer.OwnerId) &&
            await _userManager.FindByIdAsync(customer.OwnerId) is null)
            return Error(400, "Please choose a valid sales executive.");

        _db.Customers.Add(customer);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Customer", customer.CustomerId.ToString(),
            newValue: JsonSerializer.Serialize(new { customer.CustomerName, customer.Email }));

        return CreatedAtAction(nameof(Get), new { id = customer.CustomerId }, ToDto(customer));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<CustomerDto>> Update(int id, [FromBody] CustomerUpdateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var customer = await _scope.ScopeCustomers(_db.Customers, User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null)
            return await _db.Customers.AnyAsync(c => c.CustomerId == id)
                ? ForbiddenResource() : NotFoundResource("Customer");

        if (!CrmConstants.CustomerStatuses.All.Contains(dto.Status))
            return Error(400, "Please choose a valid status.");
        if (await _db.Customers.AnyAsync(c => c.CustomerId != id && c.Email.ToLower() == dto.Email.Trim().ToLower()))
            return ConflictResource("This email is already used by another customer.");
        if (await _db.Customers.AnyAsync(c => c.CustomerId != id && c.Phone == dto.Phone.Trim()))
            return ConflictResource("This phone number is already used by another customer.");

        var old = JsonSerializer.Serialize(new { customer.CustomerName, customer.Email, customer.Status });
        customer.CustomerName = dto.CustomerName.Trim();
        customer.Email = dto.Email.Trim();
        customer.Phone = dto.Phone.Trim();
        customer.CompanyName = dto.CompanyName?.Trim();
        customer.Address = dto.Address?.Trim();
        customer.City = dto.City?.Trim();
        customer.State = dto.State?.Trim();
        customer.Status = dto.Status;
        customer.Notes = dto.Notes?.Trim();
        customer.ModifiedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Update, "Customer", id.ToString(), oldValue: old,
            newValue: JsonSerializer.Serialize(new { customer.CustomerName, customer.Email, customer.Status }));
        return Ok(ToDto(customer));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var customer = await _scope.ScopeCustomers(_db.Customers, User)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
        if (customer is null)
            return await _db.Customers.AnyAsync(c => c.CustomerId == id)
                ? ForbiddenResource() : NotFoundResource("Customer");

        var old = JsonSerializer.Serialize(new { customer.CustomerName, customer.Status });
        customer.Status = CrmConstants.CustomerStatuses.Inactive; // deactivation, history preserved
        customer.ModifiedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Customer", id.ToString(), oldValue: old);
        return Ok(new { message = "Customer deactivated.", customer = ToDto(customer) });
    }

    #region Mapping
    private static CustomerDto ToDto(Customer c) => new()
    {
        CustomerId = c.CustomerId, CustomerCode = c.CustomerCode,
        CustomerName = c.CustomerName, Email = c.Email, Phone = c.Phone,
        CompanyName = c.CompanyName, City = c.City, State = c.State,
        Status = c.Status, OwnerName = c.Owner?.FullName, CreatedDate = c.CreatedDate,
    };

    private async Task<string> NextCodeAsync()
    {
        var count = await _db.Customers.CountAsync();
        string code;
        do { code = $"CUST-{(count + 1):D4}"; count++; }
        while (await _db.Customers.AnyAsync(c => c.CustomerCode == code));
        return code;
    }
    #endregion
}
