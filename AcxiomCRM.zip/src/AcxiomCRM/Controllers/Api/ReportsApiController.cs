using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Reporting data endpoints (scoped to the caller's role).</summary>
[Authorize]
 [Route("api/reports")]
public class ReportsApiController : ApiBaseController
{
    private readonly ApplicationDbContext _db;
    private readonly IScopeService _scope;

    public ReportsApiController(ApplicationDbContext db, IScopeService scope)
    {
        _db = db; _scope = scope;
    }

    /// <summary>Pipeline report data: stage-wise + owner-wise amounts (Admin/Manager scope).</summary>
    [HttpGet("pipeline")]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<ActionResult<PipelineReportDto>> Pipeline()
    {
        var opps = _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.AssignedUser), User)
            .Where(o => o.Stage != CrmConstants.OpportunityStages.Won
                     && o.Stage != CrmConstants.OpportunityStages.Lost);

        var byStage = await opps.GroupBy(o => o.Stage)
            .Select(g => new StagePipelineDto
            {
                Stage = g.Key, Count = g.Count(),
                Amount = (decimal)g.Sum(o => (double)o.Amount),
                WeightedAmount = (decimal)g.Sum(o => (double)(o.Amount * o.Probability / 100m)),
            }).ToListAsync();

        var byOwner = await opps.GroupBy(o => o.AssignedUser != null ? o.AssignedUser.FullName : "Unassigned")
            .Select(g => new OwnerPipelineDto
            {
                OwnerName = g.Key, Count = g.Count(),
                Amount = (decimal)g.Sum(o => (double)o.Amount),
                WeightedAmount = (decimal)g.Sum(o => (double)(o.Amount * o.Probability / 100m)),
            }).ToListAsync();

        return Ok(new PipelineReportDto
        {
            ByStage = byStage.OrderBy(s =>
                Array.IndexOf(CrmConstants.OpportunityStages.All, s.Stage)).ToList(),
            ByOwner = byOwner.OrderByDescending(o => o.Amount).ToList(),
            TotalPipelineValue = byStage.Sum(s => s.Amount),
            TotalWeightedValue = byStage.Sum(s => s.WeightedAmount),
        });
    }
}
