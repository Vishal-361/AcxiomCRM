using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Secured opportunity endpoints with full business-rule enforcement.</summary>
[Authorize]
 [Route("api/opportunities")]
public class OpportunitiesApiController : ApiBaseController
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public OpportunitiesApiController(
        ApplicationDbContext db, UserManager<ApplicationUser> userManager,
        IScopeService scope, IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<OpportunityDto>>> List(
        [FromQuery] string? q, [FromQuery] string? stage,
        [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        pageSize = Math.Clamp(pageSize, 1, 100);
        var query = _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer).Include(o => o.AssignedUser), User);
        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(o => o.OpportunityName.Contains(q)
                || (o.Customer != null && o.Customer.CustomerName.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(stage)) query = query.Where(o => o.Stage == stage);

        var total = await query.CountAsync();
        var items = await query.OrderByDescending(o => o.CreatedDate)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return Ok(new PagedResult<OpportunityDto>
        {
            Items = items.Select(ToDto).ToList(),
            Page = page, PageSize = pageSize, TotalCount = total,
        });
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<OpportunityDto>> Get(int id)
    {
        var opp = await _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer).Include(o => o.AssignedUser), User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        return opp is null ? NotFoundResource("Opportunity") : Ok(ToDto(opp));
    }

    [HttpPost]
    public async Task<ActionResult<OpportunityDto>> Create([FromBody] OpportunityCreateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var businessError = ValidateBusiness(dto.Stage, dto.ExpectedCloseDate);
        if (businessError is not null) return Error(400, businessError);
        var fkError = await ValidateFksAsync(dto.CustomerId, dto.AssignedTo);
        if (fkError is not null) return Error(400, fkError);

        var opp = new Opportunity
        {
            OpportunityName = dto.OpportunityName.Trim(),
            CustomerId = dto.CustomerId, LeadId = dto.LeadId,
            Amount = dto.Amount, Stage = dto.Stage, Probability = dto.Probability,
            ExpectedCloseDate = dto.ExpectedCloseDate.Date,
            Source = dto.Source, Notes = dto.Notes?.Trim(),
            Status = CrmConstants.OpportunityStages.IsActive(dto.Stage) ? "Open" : dto.Stage,
            AssignedTo = _scope.IsSalesExecutive(User) ? _scope.UserId(User) : dto.AssignedTo,
            CreatedDate = DateTime.UtcNow, CreatedBy = User.Identity?.Name,
        };
        _db.Opportunities.Add(opp);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Opportunity", opp.OpportunityId.ToString(),
            newValue: JsonSerializer.Serialize(new { opp.OpportunityName, opp.Amount, opp.Stage }));
        return CreatedAtAction(nameof(Get), new { id = opp.OpportunityId }, ToDto(opp));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<OpportunityDto>> Update(int id, [FromBody] OpportunityUpdateDto dto)
    {
        if (!ModelState.IsValid) return ValidationFailed();
        var opp = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opp is null)
            return await _db.Opportunities.AnyAsync(o => o.OpportunityId == id)
                ? ForbiddenResource() : NotFoundResource("Opportunity");

        var businessError = ValidateBusiness(dto.Stage, dto.ExpectedCloseDate);
        if (businessError is not null) return Error(400, businessError);
        var fkError = await ValidateFksAsync(dto.CustomerId, dto.AssignedTo);
        if (fkError is not null) return Error(400, fkError);

        var old = JsonSerializer.Serialize(new
        {
            opp.OpportunityName, opp.Amount, opp.Stage, opp.Probability, opp.ExpectedCloseDate
        });
        opp.OpportunityName = dto.OpportunityName.Trim();
        opp.CustomerId = dto.CustomerId; opp.LeadId = dto.LeadId;
        opp.Amount = dto.Amount; opp.Stage = dto.Stage; opp.Probability = dto.Probability;
        opp.ExpectedCloseDate = dto.ExpectedCloseDate.Date;
        opp.Source = dto.Source; opp.Notes = dto.Notes?.Trim();
        opp.Status = CrmConstants.OpportunityStages.IsActive(dto.Stage) ? "Open" : dto.Stage;
        opp.ModifiedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Update, "Opportunity", id.ToString(), oldValue: old,
            newValue: JsonSerializer.Serialize(new
            {
                opp.OpportunityName, opp.Amount, opp.Stage, opp.Probability, opp.ExpectedCloseDate
            }));
        return Ok(ToDto(opp));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var opp = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opp is null)
            return await _db.Opportunities.AnyAsync(o => o.OpportunityId == id)
                ? ForbiddenResource() : NotFoundResource("Opportunity");

        var old = JsonSerializer.Serialize(new { opp.OpportunityName, opp.Amount, opp.Stage });
        _db.Opportunities.Remove(opp);
        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Opportunity", id.ToString(), oldValue: old);
        return Ok(new { message = "Opportunity deleted." });
    }

    #region Rules + mapping
    private static string? ValidateBusiness(string stage, DateTime closeDate)
    {
        if (!CrmConstants.OpportunityStages.All.Contains(stage))
            return "Please choose a valid pipeline stage.";
        if (CrmConstants.OpportunityStages.IsActive(stage) && closeDate.Date < DateTime.Today)
            return "Expected Close Date cannot be in the past.";
        return null;
    }

    private async Task<string?> ValidateFksAsync(int? customerId, string? assignedTo)
    {
        if (customerId.HasValue &&
            !await _scope.ScopeCustomers(_db.Customers, User).AnyAsync(c => c.CustomerId == customerId.Value))
            return "Please choose a valid customer.";
        if (!string.IsNullOrEmpty(assignedTo) && await _userManager.FindByIdAsync(assignedTo) is null)
            return "Please choose a valid owner.";
        return null;
    }

    private static OpportunityDto ToDto(Opportunity o) => new()
    {
        OpportunityId = o.OpportunityId, OpportunityName = o.OpportunityName,
        CustomerName = o.Customer?.CustomerName, Stage = o.Stage,
        Amount = o.Amount, Probability = o.Probability,
        WeightedValue = o.Amount * o.Probability / 100m,
        ExpectedCloseDate = o.ExpectedCloseDate,
        OwnerName = o.AssignedUser?.FullName, CreatedDate = o.CreatedDate,
    };
    #endregion
}
