using AcxiomCRM.Models;
using AcxiomCRM.Models.Dtos;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

/// <summary>Authentication endpoints for API consumers (cookie-based, like the web UI).</summary>
 [Route("api/auth")]
public class AuthApiController : ApiBaseController
{
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IAuditService _audit;

    public AuthApiController(
        SignInManager<ApplicationUser> signInManager,
        UserManager<ApplicationUser> userManager,
        IAuditService audit)
    {
        _signInManager = signInManager;
        _userManager = userManager;
        _audit = audit;
    }

    /// <summary>Authenticate a user. Public, rate-limited.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request)
    {
        if (!ModelState.IsValid) return ValidationFailed();

        var result = await _signInManager.PasswordSignInAsync(
            request.Email, request.Password, isPersistent: false, lockoutOnFailure: true);

        if (result.Succeeded)
        {
            var user = await _userManager.FindByEmailAsync(request.Email);
            await _audit.LogAsync(user?.Id, user?.Email, CrmConstants.AuditActions.Login, "User", user?.Id);
            return Ok(new LoginResponse
            {
                UserId = user!.Id,
                FullName = user.FullName,
                Email = user.Email ?? "",
                Roles = (await _userManager.GetRolesAsync(user)).ToList(),
            });
        }

        if (result.IsLockedOut)
        {
            var user = await _userManager.FindByEmailAsync(request.Email);
            await _audit.LogAsync(user?.Id, request.Email, CrmConstants.AuditActions.AccountLocked,
                "User", user?.Id, result: "LockedOut");
            return Error(423, "This account is temporarily locked after too many failed attempts.");
        }

        await _audit.LogAsync(null, request.Email, CrmConstants.AuditActions.FailedLogin,
            "User", null, result: "Failed");
        return Error(401, "Invalid email or password.");
    }

    /// <summary>Terminate the current session.</summary>
    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        var userId = _userManager.GetUserId(User);
        await _signInManager.SignOutAsync();
        await _audit.LogAsync(userId, User.Identity?.Name, CrmConstants.AuditActions.Logout, "User", userId);
        return Ok(new { message = "Signed out." });
    }
}
