using AcxiomCRM.Models.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers.Api;

/// <summary>
/// Shared API plumbing: consistent JSON error objects, never stack traces,
/// never password hashes / tokens / internal DB fields.
/// </summary>
[ApiController]
public abstract class ApiBaseController : ControllerBase
{
    protected ActionResult Error(int statusCode, string message,
        Dictionary<string, string[]>? errors = null)
    {
        var body = new ErrorResponse
        {
            Message = message,
            Errors = errors,
            TraceId = HttpContext.TraceIdentifier,
        };
        return StatusCode(statusCode, body);
    }

    protected Dictionary<string, string[]> ModelErrors() =>
        ModelState
            .Where(kv => kv.Value?.Errors.Count > 0)
            .ToDictionary(
                kv => kv.Key,
                kv => kv.Value!.Errors.Select(e =>
                    string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Invalid value." : e.ErrorMessage).ToArray());

    protected ActionResult ValidationFailed() =>
        Error(400, "The request could not be understood — please review the highlighted fields.",
            ModelErrors());

    protected ActionResult NotFoundResource(string what) =>
        Error(404, $"{what} was not found.");

    protected ActionResult ForbiddenResource() =>
        Error(403, "You do not have permission to access this resource.");

    protected ActionResult ConflictResource(string message) =>
        Error(409, message);
}
