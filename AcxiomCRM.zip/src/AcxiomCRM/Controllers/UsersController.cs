using AcxiomCRM.Models;
using AcxiomCRM.Models.ViewModels;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>
/// User & role administration.
/// Admin: full control. Manager: read-only list (limited administration).
/// Sales executives have no access here (spec permission matrix).
/// Password hashes are never displayed, returned or logged.
/// </summary>
[Authorize(Roles = "Admin,Manager")]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public UsersController(
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /Users — Admin full, Manager read-only
    public async Task<IActionResult> Index(string? q, string? role)
    {
        var users = _userManager.Users.OrderBy(u => u.FullName).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            users = users.Where(u => u.FullName.Contains(q) || u.Email!.Contains(q));
        }

        var items = new List<UserListItem>();
        foreach (var u in await users.ToListAsync())
        {
            var roles = await _userManager.GetRolesAsync(u);
            if (!string.IsNullOrWhiteSpace(role) && !roles.Contains(role)) continue;
            items.Add(new UserListItem
            {
                Id = u.Id, FullName = u.FullName, Email = u.Email ?? "",
                Role = roles.FirstOrDefault() ?? "—",
                // Deactivated accounts carry a far-future lockout end set by an admin.
                IsActive = !(u.LockoutEnd > DateTimeOffset.UtcNow.AddYears(50)),
                IsLockedOut = u.LockoutEnd > DateTimeOffset.UtcNow,
                CreatedDate = u.CreatedDate,
            });
        }

        ViewData["Q"] = q; ViewData["Role"] = role;
        ViewData["Roles"] = new SelectList(CrmConstants.Roles.All, role);
        ViewData["ReadOnly"] = !_scope.IsAdmin(User);
        return View(items);
    }

    [Authorize(Roles = "Admin")]
    public IActionResult Create()
    {
        ViewData["Roles"] = new SelectList(CrmConstants.Roles.All, CrmConstants.Roles.SalesExecutive);
        return View(new CreateUserViewModel());
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateUserViewModel model)
    {
        if (!CrmConstants.Roles.All.Contains(model.Role))
            ModelState.AddModelError(nameof(model.Role), "Please choose a valid role.");
        if (!ModelState.IsValid)
        {
            ViewData["Roles"] = new SelectList(CrmConstants.Roles.All, model.Role);
            return View(model);
        }

        var user = new ApplicationUser
        {
            FullName = model.FullName.Trim(),
            UserName = model.Email.Trim(),
            Email = model.Email.Trim(),
            EmailConfirmed = true,
            CreatedDate = DateTime.UtcNow,
            CreatedBy = User.Identity?.Name,
        };
        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors)
                ModelState.AddModelError(string.Empty, AccountController.FriendlyIdentityError(e));
            ViewData["Roles"] = new SelectList(CrmConstants.Roles.All, model.Role);
            return View(model);
        }
        await _userManager.AddToRoleAsync(user, model.Role);

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "User", user.Id,
            newValue: JsonSerializer.Serialize(new { user.Email, Role = model.Role }));
        TempData["Toast"] = $"Account created for {user.FullName} — please share the temporary password securely.";
        return RedirectToAction(nameof(Index));
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();
        var roles = await _userManager.GetRolesAsync(user);
        return View(new EditUserViewModel
        {
            Id = user.Id, FullName = user.FullName, Email = user.Email ?? "",
            Role = roles.FirstOrDefault() ?? CrmConstants.Roles.SalesExecutive,
            IsActive = !(user.LockoutEnd > DateTimeOffset.UtcNow.AddYears(50)),
        });
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(EditUserViewModel model)
    {
        var user = await _userManager.FindByIdAsync(model.Id);
        if (user is null) return NotFound();
        if (!CrmConstants.Roles.All.Contains(model.Role))
            ModelState.AddModelError(nameof(model.Role), "Please choose a valid role.");
        if (!ModelState.IsValid) return View(model);

        var oldRoles = await _userManager.GetRolesAsync(user);
        var wasActive = !(user.LockoutEnd > DateTimeOffset.UtcNow.AddYears(50));
        var oldSnapshot = JsonSerializer.Serialize(new
        {
            user.FullName, Role = oldRoles.FirstOrDefault(), Active = wasActive
        });

        user.FullName = model.FullName.Trim();
        var roleChanged = !oldRoles.Contains(model.Role);
        if (roleChanged)
        {
            await _userManager.RemoveFromRolesAsync(user, oldRoles);
            await _userManager.AddToRoleAsync(user, model.Role);
        }
        // Deactivation = lockout far in the future (account stays auditable).
        await _userManager.SetLockoutEndDateAsync(user,
            model.IsActive ? null : DateTimeOffset.MaxValue);
        await _userManager.UpdateAsync(user);

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            roleChanged ? CrmConstants.AuditActions.RoleChange : CrmConstants.AuditActions.Update,
            "User", user.Id, oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new
            {
                FullName = user.FullName, Role = model.Role, Active = model.IsActive
            }));
        TempData["Toast"] = "User updated.";
        return RedirectToAction(nameof(Index));
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ResetPassword(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();
        return View(new ResetPasswordViewModel
        {
            Id = user.Id, Email = user.Email ?? "", FullName = user.FullName
        });
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
    {
        var user = await _userManager.FindByIdAsync(model.Id);
        if (user is null) return NotFound();
        if (!ModelState.IsValid)
        {
            model.Email = user.Email ?? ""; model.FullName = user.FullName;
            return View(model);
        }

        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        var result = await _userManager.ResetPasswordAsync(user, token, model.NewPassword);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors)
                ModelState.AddModelError(string.Empty, AccountController.FriendlyIdentityError(e));
            model.Email = user.Email ?? ""; model.FullName = user.FullName;
            return View(model);
        }

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.PasswordReset, "User", user.Id,
            newValue: "Password reset by administrator");
        TempData["Toast"] = $"Password reset for {user.FullName} — please share it securely.";
        return RedirectToAction(nameof(Index));
    }

    // POST: /Users/Unlock/{id} — controlled unlock after lockout
    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Unlock(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();

        await _userManager.SetLockoutEndDateAsync(user, null);
        await _userManager.ResetAccessFailedCountAsync(user);
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.AccountUnlocked, "User", user.Id);
        TempData["Toast"] = $"Account unlocked for {user.FullName}.";
        return RedirectToAction(nameof(Index));
    }
}
