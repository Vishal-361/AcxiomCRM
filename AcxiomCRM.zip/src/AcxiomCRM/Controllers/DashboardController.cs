using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Models.ViewModels;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Controllers;

/// <summary>
/// Role-based dashboard: KPI cards, Chart.js charts and activity summaries,
/// all computed from server-authorized (scoped) data.
/// </summary>
[Authorize]
public class DashboardController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;

    public DashboardController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope)
    {
        _db = db;
        _userManager = userManager;
        _scope = scope;
    }

    [HttpGet]
    public async Task<IActionResult> Index(DateFilterViewModel? filter)
    {
        filter ??= new DateFilterViewModel();
        var (from, to) = filter.ResolveRange();

        var user = await _userManager.GetUserAsync(User);
        var vm = new DashboardViewModel
        {
            Filter = filter,
            Greeting = GreetingFor(DateTime.Now),
            UserDisplayName = user?.FullName ?? User.Identity?.Name ?? "there",
            RoleDisplayName = _scope.IsAdmin(User) ? "Administrator"
                : _scope.IsManager(User) ? "Manager" : "Sales Executive",
        };

        var customers = _scope.ScopeCustomers(_db.Customers, User);
        var leads = _scope.ScopeLeads(_db.Leads, User);
        var opportunities = _scope.ScopeOpportunities(_db.Opportunities, User);
        var followUps = _scope.ScopeFollowUps(_db.FollowUps, User);
        var activities = _scope.ScopeActivities(_db.Activities, User);

        var openOpps = opportunities.Where(o =>
            o.Stage != CrmConstants.OpportunityStages.Won &&
            o.Stage != CrmConstants.OpportunityStages.Lost);

        vm.TotalCustomers = await customers.CountAsync();
        vm.TotalLeads = await leads.CountAsync();
        vm.OpenLeads = await leads.CountAsync(l =>
            l.Status == CrmConstants.LeadStatuses.New ||
            l.Status == CrmConstants.LeadStatuses.Contacted ||
            l.Status == CrmConstants.LeadStatuses.Qualified);
        vm.TotalOpportunities = await opportunities.CountAsync();
        vm.OpenOpportunities = await openOpps.CountAsync();
        vm.WonOpportunities = await opportunities.CountAsync(o => o.Stage == CrmConstants.OpportunityStages.Won);
        vm.LostOpportunities = await opportunities.CountAsync(o => o.Stage == CrmConstants.OpportunityStages.Lost);
        vm.TotalPipelineValue = (decimal)await openOpps.SumAsync(o => (double)o.Amount);
        vm.PendingFollowUps = await followUps.CountAsync(f =>
            f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date >= DateTime.Today);
        vm.OverdueFollowUps = await followUps.CountAsync(f =>
            f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date < DateTime.Today);

        if (_scope.IsAdmin(User))
        {
            vm.TotalUsers = await _userManager.Users.CountAsync();
            // Client-side count: SQLite cannot translate the nullable DateTimeOffset comparison.
            var lockoutEnds = await _userManager.Users.Select(u => u.LockoutEnd).ToListAsync();
            vm.LockedOutUsers = lockoutEnds.Count(d => d > DateTimeOffset.UtcNow);
        }

        // ---- Chart 1: Lead status breakdown (within the chosen period) ----
        var leadGroups = await leads
            .Where(l => l.CreatedDate >= from && l.CreatedDate <= to)
            .GroupBy(l => l.Status)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToListAsync();
        foreach (var s in CrmConstants.LeadStatuses.All)
            vm.LeadStatusCounts[s] = leadGroups.FirstOrDefault(g => g.Key == s)?.Count ?? 0;

        // ---- Chart 2: Opportunity pipeline by stage ----
        var stageGroups = await openOpps
            .GroupBy(o => o.Stage)
            .Select(g => new { g.Key, Amount = (decimal)g.Sum(o => (double)o.Amount) })
            .ToListAsync();
        foreach (var s in CrmConstants.OpportunityStages.All.Where(s =>
                     s != CrmConstants.OpportunityStages.Won && s != CrmConstants.OpportunityStages.Lost))
            vm.PipelineByStage[s] = stageGroups.FirstOrDefault(g => g.Key == s)?.Amount ?? 0m;

        // ---- Chart 3: Monthly sales (won amounts per month, last 6 months) ----
        var sixMonthsAgo = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-5);
        var wonByMonth = await opportunities
            .Where(o => o.Stage == CrmConstants.OpportunityStages.Won && o.CreatedDate >= sixMonthsAgo)
            .GroupBy(o => new { o.CreatedDate.Year, o.CreatedDate.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Amount = (decimal)g.Sum(o => (double)o.Amount) })
            .ToListAsync();
        for (var d = sixMonthsAgo; d <= DateTime.Today; d = d.AddMonths(1))
        {
            var label = d.ToString("MMM yyyy");
            vm.MonthlySales[label] = wonByMonth
                .FirstOrDefault(g => g.Year == d.Year && g.Month == d.Month)?.Amount ?? 0m;
        }

        // ---- Upcoming follow-ups + recent activities ----
        vm.UpcomingFollowUps = await followUps
            .Include(f => f.Customer).Include(f => f.Lead)
            .Where(f => f.Status == CrmConstants.FollowUpStatuses.Planned)
            .OrderBy(f => f.FollowUpDate)
            .Take(8)
            .ToListAsync();

        vm.RecentActivities = await activities
            .Include(a => a.Customer).Include(a => a.Lead)
            .OrderByDescending(a => a.ActivityDate)
            .Take(8)
            .ToListAsync();

        return View(vm);
    }

    /// <summary>Chart data endpoint (server-authorized) for live date-filter refresh.</summary>
    [HttpGet]
    public async Task<IActionResult> ChartData([FromQuery] DateFilterViewModel filter)
    {
        filter ??= new DateFilterViewModel();
        var (from, to) = filter.ResolveRange();
        var leads = _scope.ScopeLeads(_db.Leads, User);
        var opportunities = _scope.ScopeOpportunities(_db.Opportunities, User);

        var leadGroups = await leads
            .Where(l => l.CreatedDate >= from && l.CreatedDate <= to)
            .GroupBy(l => l.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();

        var openOpps = opportunities.Where(o =>
            o.Stage != CrmConstants.OpportunityStages.Won &&
            o.Stage != CrmConstants.OpportunityStages.Lost);
        var stageGroups = await openOpps
            .GroupBy(o => o.Stage)
            .Select(g => new { Stage = g.Key, Amount = (decimal)g.Sum(o => (double)o.Amount) })
            .ToListAsync();

        return Json(new { leadStatus = leadGroups, pipelineByStage = stageGroups });
    }

    private static string GreetingFor(DateTime now) => now.Hour switch
    {
        < 12 => "Good morning",
        < 17 => "Good afternoon",
        _ => "Good evening",
    };
}
