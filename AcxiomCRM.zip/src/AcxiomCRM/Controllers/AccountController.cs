using AcxiomCRM.Models;
using AcxiomCRM.Models.ViewModels;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

/// <summary>
/// Authentication: login, registration, logout and access-denied handling.
/// Every security event is written to the audit log (without secrets).
/// </summary>
public class AccountController : Controller
{
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IAuditService _audit;

    public AccountController(
        SignInManager<ApplicationUser> signInManager,
        UserManager<ApplicationUser> userManager,
        IAuditService audit)
    {
        _signInManager = signInManager;
        _userManager = userManager;
        _audit = audit;
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToAction("Index", "Dashboard");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        // Server-side: never reveal whether the email exists or the password was wrong.
        var result = await _signInManager.PasswordSignInAsync(
            model.Email, model.Password, model.RememberMe, lockoutOnFailure: true);

        if (result.Succeeded)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            await _audit.LogAsync(user?.Id, user?.Email, CrmConstants.AuditActions.Login, "User", user?.Id);
            TempData["Welcome"] = $"Welcome back, {user?.FullName?.Split(' ')[0]} — good to see you again.";
            return RedirectToLocal(model.ReturnUrl);
        }

        if (result.IsLockedOut)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            await _audit.LogAsync(user?.Id, model.Email, CrmConstants.AuditActions.AccountLocked,
                "User", user?.Id, result: "LockedOut");
            ModelState.AddModelError(string.Empty,
                "This account is temporarily locked after too many failed attempts. Please try again in a little while, or ask your administrator for help.");
            return View(model);
        }

        await _audit.LogAsync(null, model.Email, CrmConstants.AuditActions.FailedLogin,
            "User", null, result: "Failed");
        ModelState.AddModelError(string.Empty,
            "We couldn't sign you in with those details. Please check your email and password and try again.");
        return View(model);
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register()
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToAction("Index", "Dashboard");
        return View(new RegisterViewModel());
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = new ApplicationUser
        {
            FullName = model.FullName.Trim(),
            UserName = model.Email.Trim(),
            Email = model.Email.Trim(),
            EmailConfirmed = true,
            CreatedDate = DateTime.UtcNow,
            CreatedBy = "Self-registration",
        };

        // Identity enforces the password policy and stores only a PBKDF2 hash.
        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
                ModelState.AddModelError(string.Empty, FriendlyIdentityError(error));
            return View(model);
        }

        // Least privilege: self-registered users join as Sales Executive.
        await _userManager.AddToRoleAsync(user, CrmConstants.Roles.SalesExecutive);
        await _audit.LogAsync(user.Id, user.Email, CrmConstants.AuditActions.Register, "User", user.Id,
            newValue: $"Registered as {CrmConstants.Roles.SalesExecutive}");

        await _signInManager.SignInAsync(user, isPersistent: false);
        TempData["Welcome"] = $"Welcome aboard, {user.FullName.Split(' ')[0]}! Your workspace is ready.";
        return RedirectToAction("Index", "Dashboard");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        var userId = _userManager.GetUserId(User);
        var email = User.Identity?.Name;
        await _signInManager.SignOutAsync();
        await _audit.LogAsync(userId, email, CrmConstants.AuditActions.Logout, "User", userId);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult AccessDenied() => View();

    [HttpGet]
    [AllowAnonymous]
    public IActionResult LockedOut() => View();

    private IActionResult RedirectToLocal(string? returnUrl)
    {
        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);
        return RedirectToAction("Index", "Dashboard");
    }

    /// <summary>Human-friendly translations of Identity errors (no technical jargon).</summary>
    internal static string FriendlyIdentityError(IdentityError error) => error.Code switch
    {
        "DuplicateUserName" or "DuplicateEmail" =>
            "An account with this email already exists. Try signing in instead.",
        "PasswordTooShort" => "Password must be at least 8 characters long.",
        "PasswordRequiresDigit" => "Password needs at least one number.",
        "PasswordRequiresLower" => "Password needs at least one lowercase letter.",
        "PasswordRequiresUpper" => "Password needs at least one UPPERCASE letter.",
        "PasswordRequiresNonAlphanumeric" => "Password needs at least one symbol (like ! or @).",
        _ => "Please review the highlighted fields and try again.",
    };
}
