using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>Opportunity pipeline: amount, probability, close date, stage management.</summary>
[Authorize]
public class OpportunitiesController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public OpportunitiesController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /Opportunities — search (name, customer), filter (stage, status), sort, paginate
    public async Task<IActionResult> Index(
        string? q, string? stage, string? sort = "date_desc", int page = 1)
    {
        var query = _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer).Include(o => o.AssignedUser), User);

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(o => o.OpportunityName.Contains(q) ||
                (o.Customer != null && o.Customer.CustomerName.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(stage)) query = query.Where(o => o.Stage == stage);

        query = sort switch
        {
            "amount_desc" => query.OrderByDescending(o => o.Amount),
            "close" => query.OrderBy(o => o.ExpectedCloseDate),
            "name" => query.OrderBy(o => o.OpportunityName),
            _ => query.OrderByDescending(o => o.CreatedDate),
        };

        var list = await PaginatedList<Opportunity>.CreateAsync(query.AsNoTracking(), page, 10);
        ViewData["Q"] = q; ViewData["Stage"] = stage; ViewData["Sort"] = sort;
        ViewData["Stages"] = new SelectList(CrmConstants.OpportunityStages.All);
        // Kanban-friendly stage summary for the pipeline board
        ViewData["StageSummary"] = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .GroupBy(o => o.Stage)
            .Select(g => new { Stage = g.Key, Count = g.Count(), Amount = (decimal)g.Sum(o => (double)o.Amount) })
            .ToListAsync();
        return View(list);
    }

    public async Task<IActionResult> Details(int id)
    {
        var opp = await _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer).Include(o => o.AssignedUser), User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        return opp is null ? NotFound() : View(opp);
    }

    public async Task<IActionResult> Create(int? customerId = null)
    {
        await LoadLookupsAsync();
        return View(new Opportunity { CustomerId = customerId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Opportunity opportunity)
    {
        if (_scope.IsSalesExecutive(User)) opportunity.AssignedTo = _scope.UserId(User);
        opportunity.Status = CrmConstants.OpportunityStages.IsActive(opportunity.Stage) ? "Open" : opportunity.Stage;
        await ValidateOpportunityAsync(opportunity);
        if (!ModelState.IsValid) { await LoadLookupsAsync(opportunity); return View(opportunity); }

        opportunity.CreatedDate = DateTime.UtcNow;
        opportunity.CreatedBy = User.Identity?.Name;
        _db.Opportunities.Add(opportunity);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Opportunity", opportunity.OpportunityId.ToString(),
            newValue: JsonSerializer.Serialize(new
            {
                opportunity.OpportunityName, opportunity.Amount,
                opportunity.Stage, opportunity.Probability
            }));
        TempData["Toast"] = $"Opportunity “{opportunity.OpportunityName}” is in the pipeline.";
        return RedirectToAction(nameof(Details), new { id = opportunity.OpportunityId });
    }

    public async Task<IActionResult> Edit(int id)
    {
        var opp = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opp is null) return NotFound();
        await LoadLookupsAsync(opp);
        return View(opp);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Opportunity opportunity)
    {
        if (id != opportunity.OpportunityId) return BadRequest();
        var existing = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (existing is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new
        {
            existing.OpportunityName, existing.Amount, existing.Stage,
            existing.Probability, existing.ExpectedCloseDate
        });

        existing.OpportunityName = opportunity.OpportunityName;
        existing.CustomerId = opportunity.CustomerId;
        existing.Amount = opportunity.Amount;
        existing.Stage = opportunity.Stage;
        existing.Probability = opportunity.Probability;
        existing.ExpectedCloseDate = opportunity.ExpectedCloseDate;
        existing.Source = opportunity.Source;
        existing.Notes = opportunity.Notes;
        existing.Status = CrmConstants.OpportunityStages.IsActive(opportunity.Stage) ? "Open" : opportunity.Stage;
        existing.ModifiedDate = DateTime.UtcNow;
        if (!_scope.IsSalesExecutive(User)) existing.AssignedTo = opportunity.AssignedTo;

        await ValidateOpportunityAsync(existing);
        if (!ModelState.IsValid) { await LoadLookupsAsync(existing); return View(existing); }

        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Update, "Opportunity", existing.OpportunityId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new
            {
                existing.OpportunityName, existing.Amount, existing.Stage,
                existing.Probability, existing.ExpectedCloseDate
            }));
        TempData["Toast"] = "Opportunity updated — the forecast thanks you.";
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Delete(int id)
    {
        var opp = await _scope.ScopeOpportunities(
            _db.Opportunities.Include(o => o.Customer), User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        return opp is null ? NotFound() : View(opp);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var opp = await _scope.ScopeOpportunities(_db.Opportunities, User)
            .FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (opp is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { opp.OpportunityName, opp.Amount, opp.Stage });
        _db.Opportunities.Remove(opp);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Opportunity", id.ToString(), oldValue: oldSnapshot);
        TempData["Toast"] = $"Opportunity “{opp.OpportunityName}” removed from the pipeline.";
        return RedirectToAction(nameof(Index));
    }

    #region Helpers
    private async Task ValidateOpportunityAsync(Opportunity opportunity)
    {
        // FK integrity: the customer must exist and be visible to this user.
        if (opportunity.CustomerId.HasValue &&
            !await _scope.ScopeCustomers(_db.Customers, User)
                .AnyAsync(c => c.CustomerId == opportunity.CustomerId.Value))
            ModelState.AddModelError(nameof(opportunity.CustomerId),
                "Please choose a valid customer.");

        if (!string.IsNullOrEmpty(opportunity.AssignedTo) &&
            await _userManager.FindByIdAsync(opportunity.AssignedTo) is null)
            ModelState.AddModelError(nameof(opportunity.AssignedTo),
                "Please choose a valid owner.");
    }

    private async Task LoadLookupsAsync(Opportunity? opp = null)
    {
        ViewData["Stages"] = new SelectList(CrmConstants.OpportunityStages.All, opp?.Stage);
        var customers = await _scope.ScopeCustomers(_db.Customers, User)
            .OrderBy(c => c.CustomerName)
            .Select(c => new { c.CustomerId, c.CustomerName })
            .ToListAsync();
        ViewData["Customers"] = new SelectList(customers, "CustomerId", "CustomerName", opp?.CustomerId);

        var sales = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        ViewData["Owners"] = new SelectList(
            sales.Concat(managers).OrderBy(u => u.FullName)
                .Select(u => new { u.Id, Display = $"{u.FullName} ({u.Email})" }),
            "Id", "Display", opp?.AssignedTo);
    }
    #endregion
}
