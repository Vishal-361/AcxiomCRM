using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>Lead capture, qualification workflow, assignment, conversion and tracking.</summary>
[Authorize]
public class LeadsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public LeadsController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /Leads — search (name, company), filter (status, assigned user), sort, paginate
    public async Task<IActionResult> Index(
        string? q, string? status, string? assignedTo, string? sort = "date_desc", int page = 1)
    {
        var query = _scope.ScopeLeads(
            _db.Leads.Include(l => l.AssignedUser), User);

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(l => l.LeadName.Contains(q) ||
                (l.CompanyName != null && l.CompanyName.Contains(q)) ||
                (l.Email != null && l.Email.Contains(q)));
        }
        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(l => l.Status == status);
        if (!string.IsNullOrWhiteSpace(assignedTo)) query = query.Where(l => l.AssignedTo == assignedTo);

        query = sort switch
        {
            "name" => query.OrderBy(l => l.LeadName),
            "name_desc" => query.OrderByDescending(l => l.LeadName),
            "value_desc" => query.OrderByDescending(l => l.ExpectedValue),
            "date" => query.OrderBy(l => l.CreatedDate),
            _ => query.OrderByDescending(l => l.CreatedDate),
        };

        ViewData["Q"] = q; ViewData["Status"] = status;
        ViewData["AssignedTo"] = assignedTo; ViewData["Sort"] = sort;
        ViewData["Statuses"] = new SelectList(CrmConstants.LeadStatuses.All);
        ViewData["Assignees"] = new SelectList(
            await AssigneeListAsync(), "Id", "Display", assignedTo);
        return View(await PaginatedList<Lead>.CreateAsync(query.AsNoTracking(), page, 10));
    }

    public async Task<IActionResult> Details(int id)
    {
        var lead = await _scope.ScopeLeads(
            _db.Leads.Include(l => l.AssignedUser), User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return NotFound();

        ViewData["AllowedNext"] = CrmConstants.LeadStatuses.AllowedTransitions
            .TryGetValue(lead.Status, out var next) ? next : Array.Empty<string>();
        return View(lead);
    }

    public async Task<IActionResult> Create()
    {
        await LoadLookupsAsync();
        return View(new Lead());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Lead lead)
    {
        if (_scope.IsSalesExecutive(User)) lead.AssignedTo = _scope.UserId(User);
        await ValidateLeadAsync(lead);
        if (!ModelState.IsValid) { await LoadLookupsAsync(lead); return View(lead); }

        lead.LeadCode = await NextCodeAsync("LEAD");
        lead.Status = CrmConstants.LeadStatuses.New; // every lead starts New
        lead.CreatedDate = DateTime.UtcNow;
        lead.CreatedBy = User.Identity?.Name;

        _db.Leads.Add(lead);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "Lead", lead.LeadId.ToString(),
            newValue: JsonSerializer.Serialize(new { lead.LeadName, lead.Status }));
        TempData["Toast"] = $"Lead “{lead.LeadName}” captured — good hunting.";
        return RedirectToAction(nameof(Details), new { id = lead.LeadId });
    }

    public async Task<IActionResult> Edit(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return NotFound();
        await LoadLookupsAsync(lead);
        return View(lead);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Lead lead)
    {
        if (id != lead.LeadId) return BadRequest();
        var existing = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (existing is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { existing.LeadName, existing.Status });

        // Business rule: prevent invalid status transitions per the configured workflow.
        if (!CrmConstants.LeadStatuses.CanTransition(existing.Status, lead.Status))
        {
            ModelState.AddModelError(nameof(lead.Status),
                $"A lead cannot move from “{existing.Status}” to “{lead.Status}”.");
        }

        existing.LeadName = lead.LeadName;
        existing.Email = lead.Email;
        existing.Phone = lead.Phone;
        existing.CompanyName = lead.CompanyName;
        existing.Source = lead.Source;
        existing.Status = lead.Status;
        existing.Priority = lead.Priority;
        existing.ExpectedValue = lead.ExpectedValue;
        existing.Notes = lead.Notes;
        existing.ModifiedDate = DateTime.UtcNow;
        if (!_scope.IsSalesExecutive(User)) existing.AssignedTo = lead.AssignedTo;

        await ValidateLeadAsync(existing);
        if (!ModelState.IsValid) { await LoadLookupsAsync(existing); return View(existing); }

        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.StatusChange, "Lead", existing.LeadId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new { existing.LeadName, existing.Status }));
        TempData["Toast"] = "Lead updated.";
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Delete(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads.Include(l => l.AssignedUser), User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        return lead is null ? NotFound() : View(lead);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { lead.LeadName, lead.Status });
        _db.Leads.Remove(lead);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "Lead", id.ToString(), oldValue: oldSnapshot);
        TempData["Toast"] = $"Lead “{lead.LeadName}” deleted.";
        return RedirectToAction(nameof(Index));
    }

    // GET: /Leads/Convert/5 — confirm conversion of a Qualified lead
    public async Task<IActionResult> Convert(int id)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return NotFound();
        if (lead.Status != CrmConstants.LeadStatuses.Qualified)
        {
            TempData["Toast"] = "Only a Qualified lead can be converted — qualify it first.";
            return RedirectToAction(nameof(Details), new { id });
        }
        return View(lead);
    }

    // POST: /Leads/Convert/5 — Qualified lead → Customer (+ optional Opportunity), audited
    [HttpPost, ActionName("Convert")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConvertConfirmed(int id, bool createOpportunity = true)
    {
        var lead = await _scope.ScopeLeads(_db.Leads, User)
            .FirstOrDefaultAsync(l => l.LeadId == id);
        if (lead is null) return NotFound();
        if (lead.Status != CrmConstants.LeadStatuses.Qualified)
        {
            ModelState.AddModelError(string.Empty, "Only a Qualified lead can be converted.");
            return View(lead);
        }

        // Create the customer from the lead (email/phone fall back to placeholders only
        // when the lead didn't capture them — customer rules still apply).
        var customer = new Customer
        {
            CustomerCode = await NextCustomerCodeAsync(),
            CustomerName = lead.LeadName,
            Email = string.IsNullOrWhiteSpace(lead.Email) ? $"{lead.LeadCode}@converted.local" : lead.Email!,
            Phone = string.IsNullOrWhiteSpace(lead.Phone) ? "9000000000" : lead.Phone!,
            CompanyName = lead.CompanyName,
            Status = CrmConstants.CustomerStatuses.Active,
            OwnerId = lead.AssignedTo,
            Notes = $"Converted from lead {lead.LeadCode} on {DateTime.Today:dd MMM yyyy}.",
            CreatedDate = DateTime.UtcNow,
            CreatedBy = User.Identity?.Name,
        };
        _db.Customers.Add(customer);

        Opportunity? opportunity = null;
        if (createOpportunity)
        {
            opportunity = new Opportunity
            {
                OpportunityName = $"{lead.LeadName} — New business",
                Customer = customer,
                LeadId = lead.LeadId,
                Amount = lead.ExpectedValue > 0 ? lead.ExpectedValue : 1,
                Stage = CrmConstants.OpportunityStages.Qualification,
                Probability = 20,
                ExpectedCloseDate = DateTime.Today.AddDays(30),
                Source = lead.Source,
                AssignedTo = lead.AssignedTo,
                Notes = $"Created from converted lead {lead.LeadCode}.",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = User.Identity?.Name,
            };
            _db.Opportunities.Add(opportunity);
        }

        lead.Status = CrmConstants.LeadStatuses.Converted;
        lead.ConvertedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        lead.ConvertedCustomerId = customer.CustomerId;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Convert, "Lead", lead.LeadId.ToString(),
            oldValue: JsonSerializer.Serialize(new { Status = CrmConstants.LeadStatuses.Qualified }),
            newValue: JsonSerializer.Serialize(new
            {
                Status = CrmConstants.LeadStatuses.Converted,
                CustomerId = customer.CustomerId,
                OpportunityId = opportunity?.OpportunityId
            }));
        TempData["Toast"] = $"“{lead.LeadName}” is now a customer{(opportunity is null ? "" : " with an open opportunity")} — the pipeline thanks you.";
        return RedirectToAction("Details", "Customers", new { id = customer.CustomerId });
    }

    #region Helpers
    private async Task ValidateLeadAsync(Lead lead)
    {
        if (!string.IsNullOrWhiteSpace(lead.Email) &&
            await _db.Customers.AnyAsync(c => c.Email.ToLower() == lead.Email!.ToLower()))
            ModelState.AddModelError(nameof(lead.Email),
                "This email already belongs to an existing customer.");
    }

    private async Task<string> NextCodeAsync(string prefix)
    {
        var count = await _db.Leads.CountAsync();
        string code;
        do { code = $"{prefix}-{(count + 1):D4}"; count++; }
        while (await _db.Leads.AnyAsync(l => l.LeadCode == code));
        return code;
    }

    private async Task<string> NextCustomerCodeAsync()
    {
        var count = await _db.Customers.CountAsync();
        string code;
        do { code = $"CUST-{(count + 1):D4}"; count++; }
        while (await _db.Customers.AnyAsync(c => c.CustomerCode == code));
        return code;
    }

    private async Task<List<object>> AssigneeListAsync()
    {
        var sales = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        return sales.Concat(managers).OrderBy(u => u.FullName)
            .Select(u => (object)new { Id = u.Id, Display = $"{u.FullName} ({u.Email})" }).ToList();
    }

    private async Task LoadLookupsAsync(Lead? lead = null)
    {
        ViewData["Statuses"] = new SelectList(CrmConstants.LeadStatuses.All, lead?.Status);
        ViewData["Sources"] = new SelectList(CrmConstants.LeadSources.All, lead?.Source);
        ViewData["Priorities"] = new SelectList(CrmConstants.LeadPriorities.All, lead?.Priority ?? "Medium");
        ViewData["Assignees"] = new SelectList(await AssigneeListAsync(), "Id", "Display", lead?.AssignedTo);
    }
    #endregion
}
