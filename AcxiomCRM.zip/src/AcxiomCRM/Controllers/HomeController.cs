using AcxiomCRM.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace AcxiomCRM.Controllers;

/// <summary>System pages: friendly error page (production exception handler target).</summary>
public class HomeController : Controller
{
    [AllowAnonymous]
    [Route("Home/Error")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        // Deliberately generic: technical details stay in the server logs.
        return View("~/Views/Shared/Error.cshtml",
            new ErrorViewModel { RequestId = HttpContext.TraceIdentifier });
    }
}
