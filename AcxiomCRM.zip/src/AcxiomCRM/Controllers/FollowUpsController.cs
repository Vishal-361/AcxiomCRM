using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace AcxiomCRM.Controllers;

/// <summary>Follow-up scheduling, completion, rescheduling and overdue tracking.</summary>
[Authorize]
public class FollowUpsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IScopeService _scope;
    private readonly IAuditService _audit;

    public FollowUpsController(
        ApplicationDbContext db,
        UserManager<ApplicationUser> userManager,
        IScopeService scope,
        IAuditService audit)
    {
        _db = db; _userManager = userManager; _scope = scope; _audit = audit;
    }

    // GET: /FollowUps — filter (date, status, assigned user, related), sort, paginate
    public async Task<IActionResult> Index(
        string? status, string? assignedTo, DateTime? date, string? related,
        string view = "upcoming", int page = 1)
    {
        var query = _scope.ScopeFollowUps(
            _db.FollowUps.Include(f => f.Customer).Include(f => f.Lead).Include(f => f.AssignedUser), User);

        var today = DateTime.Today;
        query = view switch
        {
            "overdue" => query.Where(f => f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date < today),
            "completed" => query.Where(f => f.Status == CrmConstants.FollowUpStatuses.Completed),
            "all" => query,
            _ => query.Where(f => f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date >= today),
        };

        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(f => f.Status == status);
        if (!string.IsNullOrWhiteSpace(assignedTo)) query = query.Where(f => f.AssignedTo == assignedTo);
        if (date.HasValue) query = query.Where(f => f.FollowUpDate.Date == date.Value.Date);
        if (!string.IsNullOrWhiteSpace(related))
            query = query.Where(f =>
                (f.Customer != null && f.Customer.CustomerName.Contains(related)) ||
                (f.Lead != null && f.Lead.LeadName.Contains(related)));

        query = query.OrderBy(f => f.FollowUpDate).ThenBy(f => f.FollowUpId);

        ViewData["View"] = view; ViewData["Status"] = status;
        ViewData["AssignedTo"] = assignedTo; ViewData["Date"] = date?.ToString("yyyy-MM-dd");
        ViewData["Related"] = related;
        ViewData["Statuses"] = new SelectList(CrmConstants.FollowUpStatuses.All, status);
        ViewData["Assignees"] = new SelectList(await AssigneeListAsync(), "Id", "Display", assignedTo);
        ViewData["OverdueCount"] = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .CountAsync(f => f.Status == CrmConstants.FollowUpStatuses.Planned && f.FollowUpDate.Date < today);
        return View(await PaginatedList<FollowUp>.CreateAsync(query.AsNoTracking(), page, 10));
    }

    public async Task<IActionResult> Create(string? relatedType = null, int? customerId = null, int? leadId = null)
    {
        await LoadLookupsAsync();
        return View(new FollowUp
        {
            RelatedType = relatedType ?? (leadId.HasValue ? "Lead" : "Customer"),
            CustomerId = customerId, LeadId = leadId,
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(FollowUp followUp)
    {
        if (_scope.IsSalesExecutive(User)) followUp.AssignedTo = _scope.UserId(User);
        await ValidateFollowUpAsync(followUp);
        if (!ModelState.IsValid) { await LoadLookupsAsync(followUp); return View(followUp); }

        followUp.CreatedDate = DateTime.UtcNow;
        followUp.CreatedBy = User.Identity?.Name;
        _db.FollowUps.Add(followUp);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Create, "FollowUp", followUp.FollowUpId.ToString(),
            newValue: JsonSerializer.Serialize(new
            {
                followUp.Subject, followUp.FollowUpDate, followUp.Status
            }));
        TempData["Toast"] = "Follow-up scheduled — future you says thanks.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null) return NotFound();
        await LoadLookupsAsync(fu);
        return View(fu);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, FollowUp followUp, DateTime? newDate = null)
    {
        if (id != followUp.FollowUpId) return BadRequest();
        var existing = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (existing is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { existing.Subject, existing.FollowUpDate, existing.Status });
        var wasRescheduled = newDate.HasValue && newDate.Value.Date != existing.FollowUpDate.Date;

        existing.Subject = followUp.Subject;
        existing.FollowUpType = followUp.FollowUpType;
        existing.Remarks = followUp.Remarks;
        existing.Status = followUp.Status;
        if (wasRescheduled) existing.FollowUpDate = newDate!.Value.Date;
        if (followUp.Status == CrmConstants.FollowUpStatuses.Completed && existing.CompletedDate is null)
            existing.CompletedDate = DateTime.UtcNow;
        if (!_scope.IsSalesExecutive(User)) existing.AssignedTo = followUp.AssignedTo;

        await ValidateFollowUpAsync(existing, allowPastForCompleted: true);
        if (wasRescheduled && existing.FollowUpDate.Date < DateTime.Today)
            ModelState.AddModelError(nameof(followUp.FollowUpDate),
                "Follow-up date cannot be earlier than today.");

        if (!ModelState.IsValid) { await LoadLookupsAsync(existing); return View(existing); }

        await _db.SaveChangesAsync();
        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            wasRescheduled ? CrmConstants.AuditActions.Reschedule : CrmConstants.AuditActions.Update,
            "FollowUp", existing.FollowUpId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new
            {
                existing.Subject, existing.FollowUpDate, existing.Status
            }));
        TempData["Toast"] = wasRescheduled ? "Follow-up rescheduled." : "Follow-up updated.";
        return RedirectToAction(nameof(Index));
    }

    // POST: /FollowUps/Complete/5 — mark done (audited, records completion)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Complete(int id)
    {
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { fu.Status });
        fu.Status = CrmConstants.FollowUpStatuses.Completed;
        fu.CompletedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Complete, "FollowUp", fu.FollowUpId.ToString(),
            oldValue: oldSnapshot,
            newValue: JsonSerializer.Serialize(new { fu.Status, fu.CompletedDate }));
        TempData["Toast"] = "Follow-up completed — one more relationship nurtured.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var fu = await _scope.ScopeFollowUps(
            _db.FollowUps.Include(f => f.Customer).Include(f => f.Lead), User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        return fu is null ? NotFound() : View(fu);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var fu = await _scope.ScopeFollowUps(_db.FollowUps, User)
            .FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (fu is null) return NotFound();

        var oldSnapshot = JsonSerializer.Serialize(new { fu.Subject, fu.Status });
        _db.FollowUps.Remove(fu);
        await _db.SaveChangesAsync();

        await _audit.LogAsync(_scope.UserId(User), User.Identity?.Name,
            CrmConstants.AuditActions.Delete, "FollowUp", id.ToString(), oldValue: oldSnapshot);
        TempData["Toast"] = "Follow-up removed.";
        return RedirectToAction(nameof(Index));
    }

    #region Helpers
    private async Task ValidateFollowUpAsync(FollowUp fu, bool allowPastForCompleted = false)
    {
        // New/planned follow-ups cannot be dated before today (unless explicitly completing history).
        if (!allowPastForCompleted &&
            fu.Status == CrmConstants.FollowUpStatuses.Planned &&
            fu.FollowUpDate.Date < DateTime.Today)
            ModelState.AddModelError(nameof(fu.FollowUpDate),
                "Follow-up date cannot be earlier than today.");

        if (fu.CustomerId.HasValue &&
            !await _scope.ScopeCustomers(_db.Customers, User).AnyAsync(c => c.CustomerId == fu.CustomerId.Value))
            ModelState.AddModelError(nameof(fu.CustomerId), "Please choose a valid customer.");

        if (fu.LeadId.HasValue &&
            !await _scope.ScopeLeads(_db.Leads, User).AnyAsync(l => l.LeadId == fu.LeadId.Value))
            ModelState.AddModelError(nameof(fu.LeadId), "Please choose a valid lead.");
    }

    private async Task<List<object>> AssigneeListAsync()
    {
        var sales = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.SalesExecutive);
        var managers = await _userManager.GetUsersInRoleAsync(CrmConstants.Roles.Manager);
        return sales.Concat(managers).OrderBy(u => u.FullName)
            .Select(u => (object)new { Id = u.Id, Display = $"{u.FullName} ({u.Email})" }).ToList();
    }

    private async Task LoadLookupsAsync(FollowUp? fu = null)
    {
        ViewData["Types"] = new SelectList(CrmConstants.FollowUpTypes.All, fu?.FollowUpType);
        ViewData["Statuses"] = new SelectList(CrmConstants.FollowUpStatuses.All, fu?.Status);
        ViewData["RelatedTypes"] = new SelectList(new[] { "Customer", "Lead" }, fu?.RelatedType);
        ViewData["Customers"] = new SelectList(
            await _scope.ScopeCustomers(_db.Customers, User).OrderBy(c => c.CustomerName)
                .Select(c => new { c.CustomerId, c.CustomerName }).ToListAsync(),
            "CustomerId", "CustomerName", fu?.CustomerId);
        ViewData["Leads"] = new SelectList(
            await _scope.ScopeLeads(_db.Leads, User).OrderBy(l => l.LeadName)
                .Select(l => new { l.LeadId, l.LeadName }).ToListAsync(),
            "LeadId", "LeadName", fu?.LeadId);
        ViewData["Assignees"] = new SelectList(await AssigneeListAsync(), "Id", "Display", fu?.AssignedTo);
    }
    #endregion
}
