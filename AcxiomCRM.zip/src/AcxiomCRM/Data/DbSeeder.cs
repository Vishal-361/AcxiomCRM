using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Data;

/// <summary>
/// Seeds roles, demo users and a friendly set of sample CRM data
/// so every dashboard card, chart and report has something truthful to show.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        await db.Database.EnsureCreatedAsync();

        // ---- Roles ----
        foreach (var role in CrmConstants.Roles.All)
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));

        // ---- Demo users (passwords meet the policy; change them after first login) ----
        var demoUsers = new[]
        {
            ("Aarav Sharma", "admin@acxiomcrm.com",   "Admin@123",   CrmConstants.Roles.Admin),
            ("Meera Nair",   "manager@acxiomcrm.com", "Manager@123", CrmConstants.Roles.Manager),
            ("Rahul Verma",  "sales@acxiomcrm.com",   "Sales@123",   CrmConstants.Roles.SalesExecutive),
            ("Priya Singh",  "priya@acxiomcrm.com",   "Sales@123",   CrmConstants.Roles.SalesExecutive),
        };

        var usersByEmail = new Dictionary<string, ApplicationUser>();
        foreach (var (fullName, email, password, role) in demoUsers)
        {
            var user = await userManager.FindByEmailAsync(email);
            if (user is null)
            {
                user = new ApplicationUser
                {
                    FullName = fullName, UserName = email, Email = email,
                    EmailConfirmed = true, CreatedDate = DateTime.UtcNow, CreatedBy = "Seeder",
                };
                var result = await userManager.CreateAsync(user, password);
                if (result.Succeeded) await userManager.AddToRoleAsync(user, role);
            }
            usersByEmail[email] = user;
        }

        if (await db.Customers.AnyAsync()) return; // already seeded

        var sales1 = usersByEmail["sales@acxiomcrm.com"];
        var sales2 = usersByEmail["priya@acxiomcrm.com"];
        var manager = usersByEmail["manager@acxiomcrm.com"];
        var today = DateTime.Today;

        // ---- Customers ----
        var customers = new List<Customer>
        {
            NewCustomer("CUST-0001", "Acme Industries", "contact@acmeindustries.in", "9876543210", "Acme Industries Pvt Ltd", "Bengaluru", "Karnataka", sales1),
            NewCustomer("CUST-0002", "Brightline Retail", "hello@brightlineretail.in", "9876543211", "Brightline Retail Ltd", "Mumbai", "Maharashtra", sales1),
            NewCustomer("CUST-0003", "Coral Logistics", "info@corallogistics.in", "9876543212", "Coral Logistics", "Chennai", "Tamil Nadu", sales2),
            NewCustomer("CUST-0004", "Dunes Hospitality", "stay@duneshospitality.in", "9876543213", "Dunes Hospitality Group", "Jaipur", "Rajasthan", sales2),
            NewCustomer("CUST-0005", "Evergreen Foods", "care@evergreenfoods.in", "9876543214", "Evergreen Foods", "Kochi", "Kerala", sales1),
            NewCustomer("CUST-0006", "Frontier Textiles", "sales@frontiertextiles.in", "9876543215", "Frontier Textiles", "Surat", "Gujarat", manager),
        };
        db.Customers.AddRange(customers);
        await db.SaveChangesAsync();

        // ---- Leads ----
        var leads = new List<Lead>
        {
            NewLead("LEAD-0001", "Karan Malhotra", "karan@northwindtraders.in", "9811111111", "Northwind Traders", "Website", "New", "High", 250000, sales1),
            NewLead("LEAD-0002", "Sneha Kulkarni", "sneha@harborlights.in", "9811111112", "Harbor Lights", "Referral", "Contacted", "Medium", 120000, sales1),
            NewLead("LEAD-0003", "Vikram Rao", "vikram@summitauto.in", "9811111113", "Summit Auto", "Cold Call", "Qualified", "Urgent", 850000, sales2),
            NewLead("LEAD-0004", "Anita Desai", "anita@orchidpharma.in", "9811111114", "Orchid Pharma", "Email Campaign", "Contacted", "Medium", 300000, sales2),
            NewLead("LEAD-0005", "Rohan Iyer", "rohan@peakfitness.in", "9811111115", "Peak Fitness", "Social Media", "Unqualified", "Low", 40000, sales1),
            NewLead("LEAD-0006", "Divya Menon", "divya@lumenenergy.in", "9811111116", "Lumen Energy", "Website", "Qualified", "High", 640000, sales2),
            NewLead("LEAD-0007", "Arjun Pillai", "arjun@oldlead.in", "9811111117", "Old Ventures", "Walk-in", "Lost", "Low", 90000, sales1),
        };
        db.Leads.AddRange(leads);
        await db.SaveChangesAsync();

        // ---- Opportunities ----
        var opportunities = new List<Opportunity>
        {
            NewOpp("Acme — Annual support contract", customers[0], 480000, "Negotiation", 75, today.AddDays(20), sales1),
            NewOpp("Brightline — POS rollout", customers[1], 1250000, "Proposal", 50, today.AddDays(45), sales1),
            NewOpp("Coral — Fleet tracking", customers[2], 760000, "Qualification", 30, today.AddDays(60), sales2),
            NewOpp("Dunes — Booking engine", customers[3], 920000, "Proposal", 60, today.AddDays(35), sales2),
            NewOpp("Evergreen — Supply chain suite", customers[4], 1500000, "Negotiation", 80, today.AddDays(15), sales1),
            NewOpp("Frontier — ERP phase 1 (won)", customers[5], 2100000, "Won", 100, today.AddDays(-10), manager),
            NewOpp("Old Ventures — Pilot (lost)", customers[5], 180000, "Lost", 0, today.AddDays(-40), sales1),
        };
        // Won/Lost are closed: close date in the past is legitimate for them.
        db.Opportunities.AddRange(opportunities);
        await db.SaveChangesAsync();

        // ---- Follow-ups (upcoming, overdue, completed) ----
        var followUps = new List<FollowUp>
        {
            NewFollowUp("Customer", customers[0].CustomerId, null, today.AddDays(1), "Quarterly business review call", "Call", "Planned", sales1, "Walk through renewal options."),
            NewFollowUp("Customer", customers[1].CustomerId, null, today.AddDays(3), "Demo the new reporting module", "Meeting", "Planned", sales1, "Bring the ROI one-pager."),
            NewFollowUp("Lead", null, leads[2].LeadId, today.AddDays(-2), "Share proposal for fleet tracking", "Email", "Planned", sales2, "Overdue — chase politely."),
            NewFollowUp("Lead", null, leads[1].LeadId, today.AddDays(5), "Understand their timeline", "Call", "Planned", sales1, null),
            NewFollowUp("Customer", customers[3].CustomerId, null, today.AddDays(-5), "Collect feedback on pilot", "Call", "Completed", sales2, "Positive — wants phase 2 quote."),
            NewFollowUp("Customer", customers[4].CustomerId, null, today.AddDays(7), "Contract signing walkthrough", "Meeting", "Planned", sales1, null),
        };
        foreach (var f in followUps.Where(f => f.Status == "Completed")) f.CompletedDate = today.AddDays(-5);
        db.FollowUps.AddRange(followUps);

        // ---- Activities ----
        db.Activities.AddRange(new List<Activity>
        {
            NewActivity("Call", "Intro call with Northwind", "Spoke to Karan; sending deck.", today.AddDays(-1), null, leads[0].LeadId, sales1, "Completed"),
            NewActivity("Meeting", "Acme QBR", "Quarterly review at their office.", today.AddDays(-3), customers[0].CustomerId, null, sales1, "Completed"),
            NewActivity("Email", "Proposal sent to Summit Auto", "Fleet tracking proposal v2.", today.AddDays(-2), null, leads[2].LeadId, sales2, "Completed"),
            NewActivity("Task", "Prepare ROI one-pager", "For Brightline demo.", today.AddDays(2), customers[1].CustomerId, null, sales1, "Planned"),
            NewActivity("Call", "Check-in with Orchid Pharma", null, today.AddDays(4), null, leads[3].LeadId, sales2, "Planned"),
        });

        await db.SaveChangesAsync();
    }

    private static Customer NewCustomer(string code, string name, string email, string phone,
        string company, string city, string state, ApplicationUser owner) => new()
    {
        CustomerCode = code, CustomerName = name, Email = email, Phone = phone,
        CompanyName = company, Address = "Registered office", City = city, State = state,
        Status = CrmConstants.CustomerStatuses.Active, OwnerId = owner.Id,
        Notes = "Seeded demo record.", CreatedDate = DateTime.UtcNow.AddDays(-30), CreatedBy = "Seeder",
    };

    private static Lead NewLead(string code, string name, string? email, string? phone,
        string company, string source, string status, string priority, decimal value, ApplicationUser owner) => new()
    {
        LeadCode = code, LeadName = name, Email = email, Phone = phone, CompanyName = company,
        Source = source, Status = status, Priority = priority, ExpectedValue = value,
        AssignedTo = owner.Id, Notes = "Seeded demo record.", CreatedDate = DateTime.UtcNow.AddDays(-20), CreatedBy = "Seeder",
    };

    private static Opportunity NewOpp(string name, Customer customer, decimal amount,
        string stage, int probability, DateTime closeDate, ApplicationUser owner) => new()
    {
        OpportunityName = name, CustomerId = customer.CustomerId, Amount = amount,
        Stage = stage, Probability = probability, ExpectedCloseDate = closeDate,
        Status = CrmConstants.OpportunityStages.IsActive(stage) ? "Open" : stage,
        Source = "Seed", AssignedTo = owner.Id, Notes = "Seeded demo record.",
        CreatedDate = DateTime.UtcNow.AddDays(-25), CreatedBy = "Seeder",
    };

    private static FollowUp NewFollowUp(string relatedType, int? customerId, int? leadId,
        DateTime date, string subject, string type, string status, ApplicationUser owner, string? remarks) => new()
    {
        RelatedType = relatedType, CustomerId = customerId, LeadId = leadId,
        FollowUpDate = date, Subject = subject, FollowUpType = type, Status = status,
        Remarks = remarks, AssignedTo = owner.Id, CreatedDate = DateTime.UtcNow.AddDays(-6), CreatedBy = "Seeder",
    };

    private static Activity NewActivity(string type, string subject, string? description,
        DateTime date, int? customerId, int? leadId, ApplicationUser owner, string status) => new()
    {
        ActivityType = type, Subject = subject, Description = description, ActivityDate = date,
        CustomerId = customerId, LeadId = leadId, AssignedTo = owner.Id, Status = status,
        CreatedDate = DateTime.UtcNow.AddDays(-4), CreatedBy = "Seeder",
    };
}
