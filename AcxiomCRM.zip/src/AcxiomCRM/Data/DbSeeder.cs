using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Data;

/// <summary>
/// Seeds roles, demo users and a friendly set of sample CRM data
/// so every dashboard card, chart and report has something truthful to show.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        await db.Database.EnsureCreatedAsync();

        // ---- Roles ----
        foreach (var role in CrmConstants.Roles.All)
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));

        // ---- Demo users (passwords meet the policy; change them after first login) ----
        var demoUsers = new[]
        {
            ("Aarav Sharma", "admin@acxiomcrm.com",   "Admin@123",   CrmConstants.Roles.Admin),
            ("Meera Nair",   "manager@acxiomcrm.com", "Manager@123", CrmConstants.Roles.Manager),
            ("Rahul Verma",  "sales@acxiomcrm.com",   "Sales@123",   CrmConstants.Roles.SalesExecutive),
            ("Priya Singh",  "priya@acxiomcrm.com",   "Sales@123",   CrmConstants.Roles.SalesExecutive),
        };

        var usersByEmail = new Dictionary<string, ApplicationUser>();
        foreach (var (fullName, email, password, role) in demoUsers)
        {
            var user = await userManager.FindByEmailAsync(email);
            if (user is null)
            {
                user = new ApplicationUser
                {
                    FullName = fullName, UserName = email, Email = email,
                    EmailConfirmed = true, CreatedDate = DateTime.UtcNow, CreatedBy = "Seeder",
                };
                var result = await userManager.CreateAsync(user, password);
                if (result.Succeeded) await userManager.AddToRoleAsync(user, role);
            }
            else
            {
                // Self-heal (demo accounts only): a database seeded by an older
                // build keeps its original password hash forever, because the
                // create-branch above never runs again — a stale hash then makes
                // the documented demo password fail, and no restart can fix it.
                // If the documented password doesn't check out, reset it,
                // restore the role, and clear any lockout from failed attempts.
                if (!await userManager.CheckPasswordAsync(user, password))
                {
                    var resetToken = await userManager.GeneratePasswordResetTokenAsync(user);
                    await userManager.ResetPasswordAsync(user, resetToken, password);
                }
                if (!await userManager.IsInRoleAsync(user, role))
                    await userManager.AddToRoleAsync(user, role);
                if (await userManager.IsLockedOutAsync(user))
                    await userManager.SetLockoutEndDateAsync(user, null);
                await userManager.ResetAccessFailedCountAsync(user);
            }
            usersByEmail[email] = user;
        }

        // Extra demo batch for the sales login, so the sales dashboard, pipeline
        // and reports always have something to show. Idempotent: runs on fresh
        // databases and on ones seeded before this batch existed.
        await SeedSalesDemoDataAsync(db, usersByEmail["sales@acxiomcrm.com"]);

        if (await db.Customers.AnyAsync(c => c.CustomerCode == "CUST-0001")) return; // core already seeded

        var sales1 = usersByEmail["sales@acxiomcrm.com"];
        var sales2 = usersByEmail["priya@acxiomcrm.com"];
        var manager = usersByEmail["manager@acxiomcrm.com"];
        var today = DateTime.Today;

        // ---- Customers ----
        var customers = new List<Customer>
        {
            NewCustomer("CUST-0001", "Acme Industries", "contact@acmeindustries.in", "9876543210", "Acme Industries Pvt Ltd", "Bengaluru", "Karnataka", sales1),
            NewCustomer("CUST-0002", "Brightline Retail", "hello@brightlineretail.in", "9876543211", "Brightline Retail Ltd", "Mumbai", "Maharashtra", sales1),
            NewCustomer("CUST-0003", "Coral Logistics", "info@corallogistics.in", "9876543212", "Coral Logistics", "Chennai", "Tamil Nadu", sales2),
            NewCustomer("CUST-0004", "Dunes Hospitality", "stay@duneshospitality.in", "9876543213", "Dunes Hospitality Group", "Jaipur", "Rajasthan", sales2),
            NewCustomer("CUST-0005", "Evergreen Foods", "care@evergreenfoods.in", "9876543214", "Evergreen Foods", "Kochi", "Kerala", sales1),
            NewCustomer("CUST-0006", "Frontier Textiles", "sales@frontiertextiles.in", "9876543215", "Frontier Textiles", "Surat", "Gujarat", manager),
        };
        db.Customers.AddRange(customers);
        await db.SaveChangesAsync();

        // ---- Leads ----
        var leads = new List<Lead>
        {
            NewLead("LEAD-0001", "Karan Malhotra", "karan@northwindtraders.in", "9811111111", "Northwind Traders", "Website", "New", "High", 250000, sales1),
            NewLead("LEAD-0002", "Sneha Kulkarni", "sneha@harborlights.in", "9811111112", "Harbor Lights", "Referral", "Contacted", "Medium", 120000, sales1),
            NewLead("LEAD-0003", "Vikram Rao", "vikram@summitauto.in", "9811111113", "Summit Auto", "Cold Call", "Qualified", "Urgent", 850000, sales2),
            NewLead("LEAD-0004", "Anita Desai", "anita@orchidpharma.in", "9811111114", "Orchid Pharma", "Email Campaign", "Contacted", "Medium", 300000, sales2),
            NewLead("LEAD-0005", "Rohan Iyer", "rohan@peakfitness.in", "9811111115", "Peak Fitness", "Social Media", "Unqualified", "Low", 40000, sales1),
            NewLead("LEAD-0006", "Divya Menon", "divya@lumenenergy.in", "9811111116", "Lumen Energy", "Website", "Qualified", "High", 640000, sales2),
            NewLead("LEAD-0007", "Arjun Pillai", "arjun@oldlead.in", "9811111117", "Old Ventures", "Walk-in", "Lost", "Low", 90000, sales1),
        };
        db.Leads.AddRange(leads);
        await db.SaveChangesAsync();

        // ---- Opportunities ----
        var opportunities = new List<Opportunity>
        {
            NewOpp("Acme — Annual support contract", customers[0], 480000, "Negotiation", 75, today.AddDays(20), sales1),
            NewOpp("Brightline — POS rollout", customers[1], 1250000, "Proposal", 50, today.AddDays(45), sales1),
            NewOpp("Coral — Fleet tracking", customers[2], 760000, "Qualification", 30, today.AddDays(60), sales2),
            NewOpp("Dunes — Booking engine", customers[3], 920000, "Proposal", 60, today.AddDays(35), sales2),
            NewOpp("Evergreen — Supply chain suite", customers[4], 1500000, "Negotiation", 80, today.AddDays(15), sales1),
            NewOpp("Frontier — ERP phase 1 (won)", customers[5], 2100000, "Won", 100, today.AddDays(-10), manager),
            NewOpp("Old Ventures — Pilot (lost)", customers[5], 180000, "Lost", 0, today.AddDays(-40), sales1),
        };
        // Won/Lost are closed: close date in the past is legitimate for them.
        db.Opportunities.AddRange(opportunities);
        await db.SaveChangesAsync();

        // ---- Follow-ups (upcoming, overdue, completed) ----
        var followUps = new List<FollowUp>
        {
            NewFollowUp("Customer", customers[0].CustomerId, null, today.AddDays(1), "Quarterly business review call", "Call", "Planned", sales1, "Walk through renewal options."),
            NewFollowUp("Customer", customers[1].CustomerId, null, today.AddDays(3), "Demo the new reporting module", "Meeting", "Planned", sales1, "Bring the ROI one-pager."),
            NewFollowUp("Lead", null, leads[2].LeadId, today.AddDays(-2), "Share proposal for fleet tracking", "Email", "Planned", sales2, "Overdue — chase politely."),
            NewFollowUp("Lead", null, leads[1].LeadId, today.AddDays(5), "Understand their timeline", "Call", "Planned", sales1, null),
            NewFollowUp("Customer", customers[3].CustomerId, null, today.AddDays(-5), "Collect feedback on pilot", "Call", "Completed", sales2, "Positive — wants phase 2 quote."),
            NewFollowUp("Customer", customers[4].CustomerId, null, today.AddDays(7), "Contract signing walkthrough", "Meeting", "Planned", sales1, null),
        };
        foreach (var f in followUps.Where(f => f.Status == "Completed")) f.CompletedDate = today.AddDays(-5);
        db.FollowUps.AddRange(followUps);

        // ---- Activities ----
        db.Activities.AddRange(new List<Activity>
        {
            NewActivity("Call", "Intro call with Northwind", "Spoke to Karan; sending deck.", today.AddDays(-1), null, leads[0].LeadId, sales1, "Completed"),
            NewActivity("Meeting", "Acme QBR", "Quarterly review at their office.", today.AddDays(-3), customers[0].CustomerId, null, sales1, "Completed"),
            NewActivity("Email", "Proposal sent to Summit Auto", "Fleet tracking proposal v2.", today.AddDays(-2), null, leads[2].LeadId, sales2, "Completed"),
            NewActivity("Task", "Prepare ROI one-pager", "For Brightline demo.", today.AddDays(2), customers[1].CustomerId, null, sales1, "Planned"),
            NewActivity("Call", "Check-in with Orchid Pharma", null, today.AddDays(4), null, leads[3].LeadId, sales2, "Planned"),
        });

        await db.SaveChangesAsync();
    }

    private static Customer NewCustomer(string code, string name, string email, string phone,
        string company, string city, string state, ApplicationUser owner) => new()
    {
        CustomerCode = code, CustomerName = name, Email = email, Phone = phone,
        CompanyName = company, Address = "Registered office", City = city, State = state,
        Status = CrmConstants.CustomerStatuses.Active, OwnerId = owner.Id,
        Notes = "Seeded demo record.", CreatedDate = DateTime.UtcNow.AddDays(-30), CreatedBy = "Seeder",
    };

    /// <summary>
    /// Adds a batch of demo records owned by the main sales login
    /// (sales@acxiomcrm.com). Runs once — keyed on CUST-0101 — so it is safe
    /// on databases that were seeded before this batch existed.
    /// </summary>
    private static async Task SeedSalesDemoDataAsync(ApplicationDbContext db, ApplicationUser sales)
    {
        if (await db.Customers.AnyAsync(c => c.CustomerCode == "CUST-0101")) return;
        var today = DateTime.Today;

        var names = new[]
        {
            ("CUST-0101", "Aarohan Textiles", "contact@aarohantextiles.in", "9123456701", "Aarohan Textiles Pvt Ltd", "Coimbatore", "Tamil Nadu"),
            ("CUST-0102", "Bluepeak Foods", "hello@bluepeakfoods.in", "9123456702", "Bluepeak Foods Ltd", "Pune", "Maharashtra"),
            ("CUST-0103", "Citrus Media", "team@citrusmedia.in", "9123456703", "Citrus Media House", "Hyderabad", "Telangana"),
            ("CUST-0104", "Delta Auto Parts", "sales@deltaautoparts.in", "9123456704", "Delta Auto Parts", "Faridabad", "Haryana"),
            ("CUST-0105", "Elmpark Hotels", "reservations@elmparkhotels.in", "9123456705", "Elmpark Hotels Group", "Udaipur", "Rajasthan"),
            ("CUST-0106", "Fernweh Travel", "hi@fernwehtravel.in", "9123456706", "Fernweh Travel Co", "Goa", "Goa"),
            ("CUST-0107", "Granite Infra", "info@graniteinfra.in", "9123456707", "Granite Infra Projects", "Ahmedabad", "Gujarat"),
            ("CUST-0108", "Harvest Agro", "care@harvestagro.in", "9123456708", "Harvest Agro Foods", "Ludhiana", "Punjab"),
            ("CUST-0109", "Ionix Systems", "contact@ionixsystems.in", "9123456709", "Ionix Systems Pvt Ltd", "Noida", "Uttar Pradesh"),
            ("CUST-0110", "Juniper Clinics", "admin@juniperclinics.in", "9123456710", "Juniper Clinics Chain", "Kolkata", "West Bengal"),
        };
        var customers = names.Select(n => NewCustomer(n.Item1, n.Item2, n.Item3, n.Item4, n.Item5, n.Item6, n.Item7, sales)).ToList();
        db.Customers.AddRange(customers);
        await db.SaveChangesAsync();

        var leads = new List<Lead>
        {
            NewLead("LEAD-0101", "Suresh Yadav", "suresh@aarohantextiles.in", "9133456701", "Aarohan Textiles", "Website", "New", "High", 180000, sales),
            NewLead("LEAD-0102", "Farah Khan", "farah@citrusmedia.in", "9133456702", "Citrus Media", "Referral", "Contacted", "Medium", 240000, sales),
            NewLead("LEAD-0103", "Mohan Das", "mohan@deltaautoparts.in", "9133456703", "Delta Auto Parts", "Cold Call", "Qualified", "High", 520000, sales),
            NewLead("LEAD-0104", "Lata Bose", "lata@juniperclinics.in", "9133456704", "Juniper Clinics", "Email Campaign", "New", "Medium", 310000, sales),
            NewLead("LEAD-0105", "Imran Sheikh", "imran@ionixsystems.in", "9133456705", "Ionix Systems", "Website", "Contacted", "Low", 95000, sales),
        };
        db.Leads.AddRange(leads);
        await db.SaveChangesAsync();

        db.Opportunities.AddRange(new List<Opportunity>
        {
            NewOpp("Aarohan — ERP rollout", customers[0], 640000, "Qualification", 25, today.AddDays(50), sales),
            NewOpp("Citrus — Ad platform deal", customers[2], 880000, "Proposal", 55, today.AddDays(30), sales),
            NewOpp("Ionix — AMC renewal", customers[8], 320000, "Negotiation", 80, today.AddDays(12), sales),
            NewOpp("Juniper — Patient app (won)", customers[9], 450000, "Won", 100, today.AddDays(-6), sales),
        });
        await db.SaveChangesAsync();

        db.FollowUps.AddRange(new List<FollowUp>
        {
            NewFollowUp("Customer", customers[0].CustomerId, null, today.AddDays(2), "Kick off ERP discovery", "Meeting", "Planned", sales, null),
            NewFollowUp("Customer", customers[2].CustomerId, null, today.AddDays(-1), "Send revised ad-platform quote", "Email", "Planned", sales, "Overdue — send today."),
            NewFollowUp("Lead", null, leads[2].LeadId, today.AddDays(4), "Delta Auto Parts site visit", "Call", "Planned", sales, null),
            NewFollowUp("Customer", customers[8].CustomerId, null, today.AddDays(6), "AMC renewal paperwork", "Call", "Planned", sales, null),
        });

        db.Activities.AddRange(new List<Activity>
        {
            NewActivity("Call", "Intro call with Aarohan", "Spoke to Suresh; likes the ERP pitch.", today.AddDays(-2), customers[0].CustomerId, null, sales, "Completed"),
            NewActivity("Email", "Quote sent to Citrus Media", "Ad-platform quote v1.", today.AddDays(-1), customers[2].CustomerId, null, sales, "Completed"),
            NewActivity("Task", "Prep AMC renewal docs", "For Ionix Systems.", today.AddDays(3), customers[8].CustomerId, null, sales, "Planned"),
        });
        await db.SaveChangesAsync();
    }

    private static Lead NewLead(string code, string name, string? email, string? phone,
        string company, string source, string status, string priority, decimal value, ApplicationUser owner) => new()
    {
        LeadCode = code, LeadName = name, Email = email, Phone = phone, CompanyName = company,
        Source = source, Status = status, Priority = priority, ExpectedValue = value,
        AssignedTo = owner.Id, Notes = "Seeded demo record.", CreatedDate = DateTime.UtcNow.AddDays(-20), CreatedBy = "Seeder",
    };

    private static Opportunity NewOpp(string name, Customer customer, decimal amount,
        string stage, int probability, DateTime closeDate, ApplicationUser owner) => new()
    {
        OpportunityName = name, CustomerId = customer.CustomerId, Amount = amount,
        Stage = stage, Probability = probability, ExpectedCloseDate = closeDate,
        Status = CrmConstants.OpportunityStages.IsActive(stage) ? "Open" : stage,
        Source = "Seed", AssignedTo = owner.Id, Notes = "Seeded demo record.",
        CreatedDate = DateTime.UtcNow.AddDays(-25), CreatedBy = "Seeder",
    };

    private static FollowUp NewFollowUp(string relatedType, int? customerId, int? leadId,
        DateTime date, string subject, string type, string status, ApplicationUser owner, string? remarks) => new()
    {
        RelatedType = relatedType, CustomerId = customerId, LeadId = leadId,
        FollowUpDate = date, Subject = subject, FollowUpType = type, Status = status,
        Remarks = remarks, AssignedTo = owner.Id, CreatedDate = DateTime.UtcNow.AddDays(-6), CreatedBy = "Seeder",
    };

    private static Activity NewActivity(string type, string subject, string? description,
        DateTime date, int? customerId, int? leadId, ApplicationUser owner, string status) => new()
    {
        ActivityType = type, Subject = subject, Description = description, ActivityDate = date,
        CustomerId = customerId, LeadId = leadId, AssignedTo = owner.Id, Status = status,
        CreatedDate = DateTime.UtcNow.AddDays(-4), CreatedBy = "Seeder",
    };
}
