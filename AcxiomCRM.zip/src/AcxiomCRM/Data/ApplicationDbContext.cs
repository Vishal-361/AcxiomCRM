using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AcxiomCRM.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Lead> Leads => Set<Lead>();
    public DbSet<Opportunity> Opportunities => Set<Opportunity>();
    public DbSet<FollowUp> FollowUps => Set<FollowUp>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // ---- Uniqueness constraints (duplicate prevention, enforced by the DB too) ----
        builder.Entity<Customer>().HasIndex(c => c.Email).IsUnique();
        builder.Entity<Customer>().HasIndex(c => c.Phone).IsUnique();
        builder.Entity<Customer>().HasIndex(c => c.CustomerCode).IsUnique();
        builder.Entity<Lead>().HasIndex(l => l.LeadCode).IsUnique();

        // ---- Decimal precision for money ----
        builder.Entity<Opportunity>().Property(o => o.Amount).HasPrecision(18, 2);
        builder.Entity<Lead>().Property(l => l.ExpectedValue).HasPrecision(18, 2);

        // ---- Relationships (no cascading deletes into audit history) ----
        builder.Entity<Customer>()
            .HasOne(c => c.Owner)
            .WithMany()
            .HasForeignKey(c => c.OwnerId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<Lead>()
            .HasOne(l => l.AssignedUser)
            .WithMany()
            .HasForeignKey(l => l.AssignedTo)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<Opportunity>()
            .HasOne(o => o.Customer)
            .WithMany()
            .HasForeignKey(o => o.CustomerId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<Opportunity>()
            .HasOne(o => o.AssignedUser)
            .WithMany()
            .HasForeignKey(o => o.AssignedTo)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<FollowUp>()
            .HasOne(f => f.Customer)
            .WithMany()
            .HasForeignKey(f => f.CustomerId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<FollowUp>()
            .HasOne(f => f.Lead)
            .WithMany()
            .HasForeignKey(f => f.LeadId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<Activity>()
            .HasOne(a => a.Customer)
            .WithMany()
            .HasForeignKey(a => a.CustomerId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<Activity>()
            .HasOne(a => a.Lead)
            .WithMany()
            .HasForeignKey(a => a.LeadId)
            .OnDelete(DeleteBehavior.SetNull);

        // ---- Query performance indexes ----
        builder.Entity<Customer>().HasIndex(c => c.Status);
        builder.Entity<Lead>().HasIndex(l => l.Status);
        builder.Entity<Opportunity>().HasIndex(o => o.Stage);
        builder.Entity<FollowUp>().HasIndex(f => f.FollowUpDate);
        builder.Entity<FollowUp>().HasIndex(f => f.Status);
        builder.Entity<AuditLog>().HasIndex(a => a.CreatedDate);
        builder.Entity<AuditLog>().HasIndex(a => a.EntityName);
    }
}
