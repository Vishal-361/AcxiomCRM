using System.Collections.Concurrent;
using System.Net;

namespace AcxiomCRM.Services;

/// <summary>
/// Simple in-memory sliding-window rate limiter for authentication-sensitive
/// endpoints (brute-force protection). Returns 429 when the budget is spent.
/// </summary>
public class LoginRateLimitingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly int _maxAttempts;
    private readonly TimeSpan _window;
    private static readonly ConcurrentDictionary<string, List<DateTime>> _hits = new();

    private static readonly string[] GuardedPaths =
    {
        "/Account/Login",
        "/api/auth/login",
    };

    public LoginRateLimitingMiddleware(RequestDelegate next, IConfiguration configuration)
    {
        _next = next;
        // Configurable via appsettings (AcxiomCRM section).
        _maxAttempts = configuration.GetSection("AcxiomCRM").GetValue("LoginRateLimitPerMinute", 10);
        _window = TimeSpan.FromMinutes(1);
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (HttpMethods.IsPost(context.Request.Method) &&
            GuardedPaths.Any(p => context.Request.Path.StartsWithSegments(p, StringComparison.OrdinalIgnoreCase)))
        {
            var key = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            var now = DateTime.UtcNow;
            var attempts = _hits.GetOrAdd(key, _ => new List<DateTime>());
            lock (attempts)
            {
                attempts.RemoveAll(t => now - t > _window);
                if (attempts.Count >= _maxAttempts)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.TooManyRequests;
                    context.Response.ContentType = "application/json";
                    return;
                }
                attempts.Add(now);
            }
        }

        // Opportunistic cleanup so the dictionary cannot grow forever.
        if (_hits.Count > 10000) _hits.Clear();

        await _next(context);
    }
}
