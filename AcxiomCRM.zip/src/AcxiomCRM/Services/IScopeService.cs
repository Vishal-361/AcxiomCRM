using AcxiomCRM.Models;
using System.Security.Claims;

namespace AcxiomCRM.Services;

/// <summary>
/// Enforces the role-based data scopes from the authorization matrix ON THE SERVER:
/// - Admin: every record
/// - Manager: every record (team/business scope)
/// - SalesExecutive: only records assigned to / owned by them
/// Hiding a nav link is never treated as security — every query goes through here.
/// </summary>
public interface IScopeService
{
    bool IsAdmin(ClaimsPrincipal user);
    bool IsManager(ClaimsPrincipal user);
    bool IsSalesExecutive(ClaimsPrincipal user);
    string? UserId(ClaimsPrincipal user);

    IQueryable<Customer> ScopeCustomers(IQueryable<Customer> query, ClaimsPrincipal user);
    IQueryable<Lead> ScopeLeads(IQueryable<Lead> query, ClaimsPrincipal user);
    IQueryable<Opportunity> ScopeOpportunities(IQueryable<Opportunity> query, ClaimsPrincipal user);
    IQueryable<FollowUp> ScopeFollowUps(IQueryable<FollowUp> query, ClaimsPrincipal user);
    IQueryable<Activity> ScopeActivities(IQueryable<Activity> query, ClaimsPrincipal user);

    /// <summary>Can this user touch a record owned by ownerId/assignedTo?</summary>
    bool CanAccessRecord(ClaimsPrincipal user, string? ownerId);
}

public class ScopeService : IScopeService
{
    public bool IsAdmin(ClaimsPrincipal user) => user.IsInRole(CrmConstants.Roles.Admin);
    public bool IsManager(ClaimsPrincipal user) => user.IsInRole(CrmConstants.Roles.Manager);
    public bool IsSalesExecutive(ClaimsPrincipal user) => user.IsInRole(CrmConstants.Roles.SalesExecutive);
    public string? UserId(ClaimsPrincipal user) => user.FindFirstValue(ClaimTypes.NameIdentifier);

    private bool SeesAll(ClaimsPrincipal user) => IsAdmin(user) || IsManager(user);

    public IQueryable<Customer> ScopeCustomers(IQueryable<Customer> q, ClaimsPrincipal user) =>
        SeesAll(user) ? q : q.Where(c => c.OwnerId == UserId(user));

    public IQueryable<Lead> ScopeLeads(IQueryable<Lead> q, ClaimsPrincipal user) =>
        SeesAll(user) ? q : q.Where(l => l.AssignedTo == UserId(user));

    public IQueryable<Opportunity> ScopeOpportunities(IQueryable<Opportunity> q, ClaimsPrincipal user) =>
        SeesAll(user) ? q : q.Where(o => o.AssignedTo == UserId(user));

    public IQueryable<FollowUp> ScopeFollowUps(IQueryable<FollowUp> q, ClaimsPrincipal user) =>
        SeesAll(user) ? q : q.Where(f => f.AssignedTo == UserId(user));

    public IQueryable<Activity> ScopeActivities(IQueryable<Activity> q, ClaimsPrincipal user) =>
        SeesAll(user) ? q : q.Where(a => a.AssignedTo == UserId(user));

    public bool CanAccessRecord(ClaimsPrincipal user, string? ownerId) =>
        SeesAll(user) || ownerId == UserId(user);
}
