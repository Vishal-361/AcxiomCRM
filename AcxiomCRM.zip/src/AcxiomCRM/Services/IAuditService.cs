using AcxiomCRM.Data;
using AcxiomCRM.Models;

namespace AcxiomCRM.Services;

public interface IAuditService
{
    Task LogAsync(string? userId, string? userName, string action,
        string? entityName = null, string? recordId = null,
        string? oldValue = null, string? newValue = null,
        string result = "Success", string? ipAddress = null);
}

public class AuditService : IAuditService
{
    private readonly ApplicationDbContext _db;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public AuditService(ApplicationDbContext db, IHttpContextAccessor httpContextAccessor)
    {
        _db = db;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task LogAsync(string? userId, string? userName, string action,
        string? entityName = null, string? recordId = null,
        string? oldValue = null, string? newValue = null,
        string result = "Success", string? ipAddress = null)
    {
        // Never log secrets: callers must not pass passwords, hashes or tokens here.
        var entry = new AuditLog
        {
            UserId = userId,
            UserName = userName,
            Action = action,
            EntityName = entityName,
            RecordId = recordId,
            OldValue = Truncate(oldValue),
            NewValue = Truncate(newValue),
            Result = result,
            IpAddress = ipAddress ?? _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
            CreatedDate = DateTime.UtcNow,
        };
        _db.AuditLogs.Add(entry);
        await _db.SaveChangesAsync();
    }

    private static string? Truncate(string? value) =>
        value is { Length: > 2000 } ? value[..2000] : value;
}
