/* AcxiomCRM — shell: boot, router, layout, login, shared UI primitives */
(function () {
  "use strict";
  var U = CRM.utils;

  /* ================= toasts ================= */
  function toast(msg, type) {
    var box = document.getElementById("toasts");
    var el = document.createElement("div");
    el.className = "toast " + (type || "info");
    var icon = type === "ok" ? "✓" : type === "err" ? "✕" : "ℹ";
    el.innerHTML = "<span>" + icon + "</span><span>" + U.esc(msg) + "</span>";
    box.appendChild(el);
    setTimeout(function () { el.classList.add("out"); setTimeout(function(){ el.remove(); }, 260); }, 3400);
  }

  /* ================= modal ================= */
  function openModal(opts) {
    closeModal();
    var root = document.getElementById("modal-root");
    var ov = document.createElement("div");
    ov.className = "overlay"; ov.id = "modal-ov";
    ov.innerHTML =
      '<div class="dialog" role="dialog">' +
        '<div class="dialog-h"><h3>' + U.esc(opts.title) + '</h3>' +
        '<button class="x-btn" id="m-close" title="Close">✕</button></div>' +
        '<form id="m-form" novalidate><div class="dialog-b">' + opts.bodyHTML + "</div>" +
        '<div class="dialog-f"><button type="button" class="btn btn-ghost" id="m-cancel">Cancel</button>' +
        '<button type="submit" class="btn ' + (opts.danger ? "btn-danger" : "btn-primary") + '" id="m-ok">' +
        U.esc(opts.okLabel || "Save") + "</button></div></form></div>";
    root.appendChild(ov);
    var form = ov.querySelector("#m-form");
    ov.querySelector("#m-close").onclick = closeModal;
    ov.querySelector("#m-cancel").onclick = closeModal;
    ov.addEventListener("mousedown", function (e) { if (e.target === ov) closeModal(); });
    document.addEventListener("keydown", escClose);
    // clear invalid styling as the user types
    form.addEventListener("input", function (e) {
      var g = e.target.closest(".f-group"); if (g) g.classList.remove("invalid");
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      clearErrors(form);
      var btn = ov.querySelector("#m-ok");
      btn.disabled = true;
      var done = function () { btn.disabled = false; };
      var r = opts.onOk(form, done);
      if (r !== false && !(r && r.then)) { closeModal(); }
      else if (r && r.then) r.then(function (keep) { if (!keep) closeModal(); done(); });
      else done();
    });
    var first = form.querySelector(".inp");
    if (first) setTimeout(function(){ first.focus(); }, 60);
    return form;
  }
  function escClose(e) { if (e.key === "Escape") closeModal(); }
  function closeModal() {
    var ov = document.getElementById("modal-ov");
    if (ov) ov.remove();
    document.removeEventListener("keydown", escClose);
  }
  function clearErrors(form) {
    form.querySelectorAll(".f-group.invalid").forEach(function (g) { g.classList.remove("invalid"); });
  }
  function showErrors(form, errors) {
    Object.keys(errors).forEach(function (k) {
      var g = form.querySelector('[data-f="' + k + '"]');
      if (g) { g.classList.add("invalid"); var e = g.querySelector(".f-err"); if (e) e.textContent = errors[k]; }
    });
    var firstBad = form.querySelector(".f-group.invalid .inp");
    if (firstBad) firstBad.focus();
  }
  function confirmDlg(title, message, okLabel) {
    return new Promise(function (resolve) {
      openModal({
        title: title, danger: true, okLabel: okLabel || "Delete",
        bodyHTML: '<p style="margin:0;color:var(--muted)">' + U.esc(message) + "</p>",
        onOk: function () { resolve(true); }
      });
      var ov = document.getElementById("modal-ov");
      var cancel = ov.querySelector("#m-cancel");
      var old = cancel.onclick;
      cancel.onclick = function () { resolve(false); closeModal(); };
      ov.querySelector("#m-close").onclick = function () { resolve(false); closeModal(); };
    });
  }

  /* ================= form fields ================= */
  function fieldHTML(type, name, label, o) {
    o = o || {};
    var req = o.req ? ' <span class="req">*</span>' : "";
    var val = o.value == null ? "" : String(o.value);
    var common = ' name="' + name + '" class="inp"' + (o.max ? ' maxlength="' + o.max + '"' : "");
    var input = "";
    if (type === "select") {
      input = '<select' + common + ">" + (o.options || []).map(function (op) {
        return '<option value="' + U.esc(op.v) + '"' + (String(op.v) === val ? " selected" : "") + ">" + U.esc(op.t) + "</option>";
      }).join("") + "</select>";
    } else if (type === "textarea") {
      input = "<textarea" + common + ' rows="' + (o.rows || 3) + '">' + U.esc(val) + "</textarea>";
    } else {
      input = "<input type=\"" + type + '"' + common + ' value="' + U.esc(val) + '"' +
        (o.min != null ? ' min="' + o.min + '"' : "") + (o.step ? ' step="' + o.step + '"' : "") +
        (o.placeholder ? ' placeholder="' + U.esc(o.placeholder) + '"' : "") + ">";
    }
    return '<div class="f-group' + (o.full ? " f-full" : "") + '" data-f="' + name + '">' +
      "<label>" + U.esc(label) + req + "</label>" + input +
      (o.hint ? '<div class="hint">' + U.esc(o.hint) + "</div>" : "") +
      '<div class="f-err"></div></div>';
  }
  var F = {
    text: function (n, l, o) { return fieldHTML("text", n, l, o); },
    email: function (n, l, o) { return fieldHTML("email", n, l, o); },
    tel: function (n, l, o) { return fieldHTML("tel", n, l, o); },
    date: function (n, l, o) { return fieldHTML("date", n, l, o); },
    number: function (n, l, o) { return fieldHTML("number", n, l, o); },
    password: function (n, l, o) { return fieldHTML("password", n, l, o); },
    select: function (n, l, o) { return fieldHTML("select", n, l, o); },
    textarea: function (n, l, o) { return fieldHTML("textarea", n, l, o); }
  };
  function collectForm(form) {
    var obj = {};
    form.querySelectorAll("[data-f]").forEach(function (g) {
      var inp = g.querySelector("[name]");
      if (inp) obj[inp.name] = inp.value;
    });
    return obj;
  }

  /* ================= pills / misc ================= */
  function pill(text, cls) { return '<span class="pill ' + cls + '">' + U.esc(text) + "</span>"; }
  function statusPill(s) {
    var map = {
      Active: "p-green", Prospect: "p-blue", Inactive: "p-gray",
      New: "p-blue", Contacted: "p-teal", Qualified: "p-violet", Unqualified: "p-gray",
      Converted: "p-green", Lost: "p-red", Open: "p-blue", Closed: "p-gray",
      Planned: "p-amber", Completed: "p-green", Missed: "p-red", Cancelled: "p-gray",
      Qualification: "p-blue", Proposal: "p-violet", Negotiation: "p-amber", Won: "p-green"
    };
    return pill(s, map[s] || "p-gray");
  }
  function initials(name) {
    return String(name || "?").trim().split(/\s+/).slice(0, 2).map(function (w) { return w[0].toUpperCase(); }).join("");
  }

  /* ================= data table with search / sort / paging ================= */
  function dataView(mount, cfg) {
    var state = { q: "", page: 1, sort: null, dir: 1 };
    var pageSize = cfg.pageSize || 10;

    function rows() {
      var r = cfg.getRows().slice();
      if (state.q) {
        var q = state.q.toLowerCase();
        r = r.filter(function (row) {
          return (cfg.searchKeys || []).some(function (k) {
            var v = typeof k === "function" ? k(row) : row[k];
            return String(v == null ? "" : v).toLowerCase().indexOf(q) !== -1;
          });
        });
      }
      if (state.sort) {
        var k = state.sort;
        r.sort(function (a, b) {
          var av = a[k], bv = b[k];
          if (av == null) av = ""; if (bv == null) bv = "";
          var c = av > bv ? 1 : av < bv ? -1 : 0;
          return c * state.dir;
        });
      }
      return r;
    }

    function render() {
      var all = rows();
      var pages = Math.max(1, Math.ceil(all.length / pageSize));
      if (state.page > pages) state.page = pages;
      var slice = all.slice((state.page - 1) * pageSize, state.page * pageSize);
      var cols = cfg.columns.map(function (c) {
        var arrow = state.sort === c.key ? (state.dir === 1 ? " ▲" : " ▼") : "";
        return '<th data-sort="' + (c.sort === false ? "" : c.key) + '"' +
          (c.num ? ' class="num"' : "") + ' style="' + (c.sort === false ? "" : "cursor:pointer") + '">' +
          U.esc(c.label) + arrow + "</th>";
      }).join("");
      var body = slice.map(function (row) {
        var tds = cfg.columns.map(function (c) {
          var v = c.render ? c.render(row) : row[c.key];
          return '<td' + (c.num ? ' class="num"' : "") + ">" + (v == null || v === "" ? "—" : v) + "</td>";
        }).join("");
        var acts = cfg.actions ? '<td style="white-space:nowrap;text-align:right">' + cfg.actions(row) + "</td>" : "";
        return "<tr>" + tds + acts + "</tr>";
      }).join("");
      if (!slice.length)
        body = '<tr class="empty-row"><td colspan="' + (cfg.columns.length + (cfg.actions ? 1 : 0)) + '">' +
          U.esc(cfg.empty || "No records found.") + "</td></tr>";

      mount.innerHTML =
        (cfg.hideSearch ? "" :
          '<div class="toolbar"><div class="search-box"><span class="s-ico">⌕</span>' +
          '<input class="inp" id="dv-q" placeholder="' + U.esc(cfg.searchPlaceholder || "Search…") + '" value="' + U.esc(state.q) + '"></div>' +
          (cfg.toolbarExtra || "") + '<div class="spacer"></div>' + (cfg.toolbarRight || "") + "</div>") +
        '<div class="tbl-wrap"><table class="tbl"><thead><tr>' + cols + (cfg.actions ? "<th></th>" : "") +
        "</tr></thead><tbody>" + body + "</tbody></table></div>" +
        '<div class="pager"><span>' + all.length + " record(s)</span>" +
        '<button class="btn btn-sm" id="dv-prev"' + (state.page <= 1 ? " disabled" : "") + ">‹ Prev</button>" +
        "<span>Page " + state.page + " of " + pages + "</span>" +
        '<button class="btn btn-sm" id="dv-next"' + (state.page >= pages ? " disabled" : "") + ">Next ›</button></div>";

      if (!cfg.hideSearch) {
        var qi = mount.querySelector("#dv-q");
        qi.addEventListener("input", U.debounce(function () { state.q = qi.value; state.page = 1; render(); }, 200));
      }
      mount.querySelectorAll("th[data-sort]").forEach(function (th) {
        var k = th.getAttribute("data-sort");
        if (!k) return;
        th.addEventListener("click", function () {
          if (state.sort === k) state.dir *= -1; else { state.sort = k; state.dir = 1; }
          render();
        });
      });
      mount.querySelector("#dv-prev").onclick = function () { if (state.page > 1) { state.page--; render(); } };
      mount.querySelector("#dv-next").onclick = function () { state.page++; render(); };
      if (cfg.onAction) {
        mount.querySelectorAll("[data-act]").forEach(function (b) {
          b.addEventListener("click", function (e) {
            e.stopPropagation();
            cfg.onAction(b.getAttribute("data-act"), b.getAttribute("data-id"));
          });
        });
      }
    }
    render();
    return { refresh: function () { state.page = 1; render(); } };
  }

  function actionBtns(canEdit, canDelete) {
    var h = "";
    h += '<button class="icon-btn" data-act="view" title="View details">👁</button>';
    if (canEdit) h += '<button class="icon-btn" data-act="edit" title="Edit">✎</button>';
    if (canDelete) h += '<button class="icon-btn danger" data-act="del" title="Delete">🗑</button>';
    return h;
  }

  function detailModal(title, pairs) {
    openModal({
      title: title, okLabel: "Close",
      bodyHTML: '<div class="detail-grid">' + pairs.map(function (p) {
        return '<div><div class="dk">' + U.esc(p[0]) + '</div><div class="dv">' + p[1] + "</div></div>";
      }).join("") + "</div>",
      onOk: function () {}
    });
  }

  /* ================= layout ================= */
  var NAV = [
    { sec: null },
    { id: "dashboard", label: "Dashboard", icon: "▦" },
    { id: "customers", label: "Customers", icon: "👥" },
    { id: "leads", label: "Leads", icon: "🎯" },
    { id: "opportunities", label: "Opportunities", icon: "💼" },
    { id: "followups", label: "Follow-Ups", icon: "📞" },
    { id: "activities", label: "Activities", icon: "🗓" },
    { id: "reports", label: "Reports", icon: "📊" },
    { id: "api", label: "API Explorer", icon: "🔌" },
    { sec: "Administration" },
    { id: "users", label: "Users & Roles", icon: "🛡" },
    { id: "audit", label: "Audit Log", icon: "📜" }
  ];
  var TITLES = {
    dashboard: ["Dashboard", "Your sales overview"], customers: ["Customers", "Customer master data"],
    leads: ["Leads", "Capture, qualify and convert"], opportunities: ["Opportunities", "Sales pipeline"],
    followups: ["Follow-Ups", "Scheduled touch-points"], activities: ["Activities", "Calls, meetings, emails, tasks"],
    reports: ["Reports", "Filterable reports with CSV export"], api: ["API Explorer", "Test the REST contract live"],
    users: ["Users & Roles", "Manage access"], audit: ["Audit Log", "Security & business trail"]
  };

  function shell(active) {
    var u = CRM.auth.currentUser();
    var nav = NAV.map(function (n) {
      if (n.sec) return '<div class="sep">' + n.sec + "</div>";
      if (!CRM.auth.canAccess(n.id)) return "";
      return '<a href="#/' + n.id + '" class="' + (n.id === active ? "active" : "") + '">' +
        '<span class="ico">' + n.icon + '</span><span class="tx">' + n.label + "</span></a>";
    }).join("");
    return '<div class="shell"><aside class="sidebar">' +
      '<div class="brand">Acxiom<span class="dot">CRM</span><small>Sales Suite</small></div>' +
      '<nav class="nav">' + nav + "</nav>" +
      '<div class="side-user"><div class="avatar">' + initials(u.name) + '</div>' +
      '<div class="uinfo"><div class="nm">' + U.esc(u.name) + '</div><div class="rl">' + U.esc(CRM.auth.roleLabel(u.role)) + "</div></div></div>" +
      "</aside>" +
      '<div class="main"><div class="topbar"><div class="crumb">' + TITLES[active][0] +
      ' <span>/ ' + TITLES[active][1] + "</span></div>" +
      '<div class="topbar-right"><span class="pill p-blue">' + U.esc(CRM.auth.roleLabel(u.role)) + "</span>" +
      '<button class="btn btn-sm" id="btn-logout">Logout</button></div></div>' +
      '<div class="content"><div class="view" id="view"></div></div>' +
      "</div></div>";
  }

  /* ================= login / register ================= */
  function loginView() {
    var app = document.getElementById("app");
    app.innerHTML =
      '<div class="login-wrap"><div class="login-brand">' +
      "<h1>Acxiom<span class='dot'>CRM</span></h1>" +
      "<p>The sales workspace your team will actually enjoy opening — customers, leads, pipeline and follow-ups in one calm place.</p>" +
      '<div class="login-points">' +
      "<div><span class='tick'>✓</span><span>Role-based dashboards for Admins, Managers and Sales Executives</span></div>" +
      "<div><span class='tick'>✓</span><span>Lead-to-customer workflows with guarded status transitions</span></div>" +
      "<div><span class='tick'>✓</span><span>Opportunity pipeline with weighted revenue forecasting</span></div>" +
      "<div><span class='tick'>✓</span><span>Full audit trail — every login, change and delete is recorded</span></div>" +
      "</div></div>" +
      '<div class="login-side"><div class="login-card">' +
      '<div class="tabs" style="margin-bottom:20px"><button class="on" id="tab-login">Login</button><button id="tab-reg">Register</button></div>' +
      '<div id="login-pane"><h2>Welcome back</h2><p class="sub">Sign in to your sales workspace.</p>' +
      '<form id="f-login" novalidate><div class="f-grid" style="grid-template-columns:1fr">' +
      F.email("email", "Email", { req: true, full: true }) +
      fieldHTML("password", "password", "Password", { req: true, full: true }) +
      '</div><div class="f-err" id="login-err" style="margin:10px 0 0"></div>' +
      '<button class="btn btn-primary" id="btn-login" style="width:100%;justify-content:center;margin-top:16px;padding:12px">Sign in</button></form></div>' +
      '<div id="reg-pane" style="display:none"><h2>Create account</h2><p class="sub">New sales executives start here.</p>' +
      '<form id="f-reg" novalidate><div class="f-grid" style="grid-template-columns:1fr">' +
      F.text("name", "Full name", { req: true, full: true }) +
      F.email("email", "Email", { req: true, full: true }) +
      fieldHTML("password", "password", "Password", { req: true, full: true, hint: "Min 8 characters, with a letter and a number." }) +
      '</div><div class="f-err" id="reg-err" style="margin:10px 0 0"></div>' +
      '<button class="btn btn-primary" style="width:100%;justify-content:center;margin-top:16px;padding:12px">Create account</button></form></div>' +
      '<div class="demo-creds"><b>Demo accounts</b> — click to fill in:<br>' +
      '<span class="cred" data-e="admin@acxiomcrm.com" data-p="Admin@123">👑 admin@acxiomcrm.com</span><br>' +
      '<span class="cred" data-e="manager@acxiomcrm.com" data-p="Manager@123">📋 manager@acxiomcrm.com</span><br>' +
      '<span class="cred" data-e="rahul@acxiomcrm.com" data-p="Sales@123">💼 rahul@acxiomcrm.com (sales)</span>' +
      "</div></div></div></div>";

    app.querySelector("#tab-login").onclick = function () { showPane(true); };
    app.querySelector("#tab-reg").onclick = function () { showPane(false); };
    function showPane(login) {
      app.querySelector("#tab-login").classList.toggle("on", login);
      app.querySelector("#tab-reg").classList.toggle("on", !login);
      app.querySelector("#login-pane").style.display = login ? "" : "none";
      app.querySelector("#reg-pane").style.display = login ? "none" : "";
    }
    app.querySelectorAll(".cred").forEach(function (c) {
      c.onclick = function () {
        showPane(true);
        app.querySelector('#f-login [name="email"]').value = c.getAttribute("data-e");
        app.querySelector('#f-login [name="password"]').value = c.getAttribute("data-p");
        app.querySelector('#f-login [name="password"]').focus();
      };
    });
    app.querySelector("#f-login").addEventListener("submit", function (e) {
      e.preventDefault();
      var em = this.email.value.trim(), pw = this.password.value;
      var errBox = app.querySelector("#login-err");
      errBox.style.display = "none";
      var btn = app.querySelector("#btn-login");
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span> Signing in…';
      setTimeout(function () {
        var r = CRM.auth.login(em, pw);
        btn.disabled = false; btn.textContent = "Sign in";
        if (!r.ok) {
          errBox.textContent = r.error; errBox.style.display = "block";
          errBox.parentElement.animate(
            [{ transform: "translateX(0)" }, { transform: "translateX(-7px)" }, { transform: "translateX(7px)" }, { transform: "translateX(0)" }],
            { duration: 260 });
        } else {
          toast("Welcome back, " + r.user.name.split(" ")[0] + "!", "ok");
          if (location.hash === "#/dashboard") CRM.ui.refresh();
          else location.hash = "#/dashboard";
        }
      }, 450);
    });
    app.querySelector("#f-reg").addEventListener("submit", function (e) {
      e.preventDefault();
      var v = collectForm(this);
      var errBox = app.querySelector("#reg-err");
      errBox.style.display = "none";
      var r = CRM.auth.register(v.name, v.email, v.password);
      if (!r.ok) {
        var first = Object.keys(r.errors)[0];
        errBox.textContent = r.errors[first]; errBox.style.display = "block";
      } else {
        toast("Account created — welcome aboard!", "ok");
        if (location.hash === "#/dashboard") CRM.ui.refresh();
        else location.hash = "#/dashboard";
      }
    });
  }

  /* ================= router ================= */
  var ROUTES = {};
  function route(id, fn) { ROUTES[id] = fn; }

  function render() {
    var hash = location.hash || "#/dashboard";
    var id = hash.replace("#/", "").split("?")[0] || "dashboard";
    var app = document.getElementById("app");
    var user = CRM.auth.currentUser();

    if (!user) { loginView(); return; }
    if (id === "login") { location.hash = "#/dashboard"; return; }
    if (!ROUTES[id] || !CRM.auth.canAccess(id)) {
      app.innerHTML = shell("dashboard");
      document.getElementById("view").innerHTML =
        '<div class="card" style="text-align:center;padding:60px"><h2>⛔ Not authorized</h2>' +
        '<p style="color:var(--muted)">Your role (' + U.esc(CRM.auth.roleLabel(user.role)) + ") cannot open this section.</p>" +
        '<a class="btn btn-primary" href="#/dashboard">Back to Dashboard</a></div>';
      wireShell();
      return;
    }
    app.innerHTML = shell(id);
    wireShell();
    document.getElementById("view").innerHTML = "";
    ROUTES[id](document.getElementById("view"));
  }

  function wireShell() {
    var b = document.getElementById("btn-logout");
    if (b) b.onclick = function () { CRM.auth.logout(); toast("Signed out.", "info"); location.hash = "#/login"; render(); };
  }

  function boot() {
    window.addEventListener("hashchange", render);
    if (!location.hash) location.hash = "#/dashboard";
    render();
  }

  CRM.ui = {
    toast: toast, openModal: openModal, closeModal: closeModal, confirmDlg: confirmDlg,
    F: F, collectForm: collectForm, showErrors: showErrors, clearErrors: clearErrors,
    pill: pill, statusPill: statusPill, initials: initials,
    dataView: dataView, actionBtns: actionBtns, detailModal: detailModal,
    route: route, go: function (p) { location.hash = "#/" + p; }, refresh: render
  };
  CRM.boot = boot;
  document.addEventListener("DOMContentLoaded", boot);
})();
