/* AcxiomCRM — simulated REST API layer.
   Demonstrates the documented REST contract: DTOs, status codes, auth, validation.
   In a production ASP.NET Core build these would be real HTTP endpoints. */
(function () {
  "use strict";
  var U = CRM.utils;

  function ok(status, body) { return { status: status, body: body }; }
  function err(status, message, errors) {
    return { status: status, body: { error: message, errors: errors || null } };
  }

  // strip internal fields -> DTO
  function customerDTO(c) {
    return { id: c.id, code: c.code, name: c.name, email: c.email, phone: c.phone,
      company: c.company, address: c.address, city: c.city, state: c.state,
      status: c.status, ownerId: c.ownerId, notes: c.notes,
      createdDate: c.createdAt, modifiedDate: c.modifiedAt };
  }
  function leadDTO(l) {
    return { id: l.id, code: l.code, name: l.name, email: l.email, phone: l.phone,
      company: l.company, source: l.source, status: l.status, priority: l.priority,
      expectedValue: l.expectedValue, assignedTo: l.assignedTo, notes: l.notes, createdDate: l.createdAt };
  }
  function oppDTO(o) {
    return { id: o.id, name: o.name, customerId: o.customerId, ownerId: o.ownerId,
      stage: o.stage, amount: o.amount, probability: o.probability,
      expectedCloseDate: o.expectedCloseDate, status: o.status,
      weightedValue: Math.round(o.amount * o.probability / 100),
      source: o.source, notes: o.notes, createdDate: o.createdAt };
  }

  function authUser(headers) {
    var h = headers || {};
    var auth = h.Authorization || h.authorization || "";
    var m = /^Bearer (.+)$/.exec(auth);
    if (!m) return null;
    var s = CRM.auth.getSession();
    if (s && s.token === m[1]) return CRM.auth.currentUser();
    return null;
  }

  // main dispatcher: handle(method, path, body, headers) -> {status, body}
  function handle(method, path, body, headers) {
    method = String(method).toUpperCase();
    var seg = String(path).split("?")[0].split("/").filter(Boolean);

    // POST /api/auth/login  (public, rate-limited in production)
    if (seg[0] === "api" && seg[1] === "auth" && seg[2] === "login" && method === "POST") {
      if (!body || !body.email || !body.password) return err(400, "Email and password are required.");
      var r = CRM.auth.login(body.email, body.password);
      if (!r.ok) return err(401, r.error);
      return ok(200, { token: r.token, tokenType: "Bearer",
        user: { id: r.user.id, name: r.user.name, email: r.user.email, role: r.user.role } });
    }

    var user = authUser(headers);
    if (!user) return err(401, "Missing or invalid bearer token.");

    // GET /api/customers
    if (seg[0] === "api" && seg[1] === "customers" && seg.length === 2 && method === "GET") {
      var list = CRM.store.scoped("customers").map(customerDTO);
      return ok(200, { count: list.length, data: list });
    }
    // GET /api/customers/{id}
    if (seg[0] === "api" && seg[1] === "customers" && seg.length === 3 && method === "GET") {
      var c = CRM.store.get("customers", seg[2]);
      if (!c) return err(404, "Customer not found.");
      if (user.role === "sales" && c.ownerId !== user.id) return err(403, "Not authorized for this customer.");
      return ok(200, customerDTO(c));
    }
    // POST /api/customers
    if (seg[0] === "api" && seg[1] === "customers" && seg.length === 2 && method === "POST") {
      var errs = CRM.validators.validateCustomer(body || {}, false);
      if (Object.keys(errs).length) return err(400, "Validation failed.", errs);
      var rec = Object.assign({ id: U.uid("c"), code: CRM.store.nextCode("customer", "CUST"),
        status: "Prospect", ownerId: user.id, createdAt: new Date().toISOString(),
        createdBy: user.id, modifiedAt: new Date().toISOString() }, body);
      CRM.store.insert("customers", rec);
      CRM.audit.log({ module: "Customer", action: "Create (API)", recordId: rec.id, details: rec.code });
      return ok(201, customerDTO(rec));
    }
    // PUT /api/customers/{id}
    if (seg[0] === "api" && seg[1] === "customers" && seg.length === 3 && method === "PUT") {
      var ex = CRM.store.get("customers", seg[2]);
      if (!ex) return err(404, "Customer not found.");
      if (!CRM.auth.canEditRecord(ex)) return err(403, "Not authorized to update this customer.");
      var merged = Object.assign({}, ex, body, { id: ex.id });
      var e2 = CRM.validators.validateCustomer(merged, true);
      if (Object.keys(e2).length) return err(400, "Validation failed.", e2);
      CRM.store.update("customers", ex.id, merged);
      CRM.audit.log({ module: "Customer", action: "Update (API)", recordId: ex.id, details: ex.code });
      return ok(200, customerDTO(CRM.store.get("customers", ex.id)));
    }
    // DELETE /api/customers/{id}
    if (seg[0] === "api" && seg[1] === "customers" && seg.length === 3 && method === "DELETE") {
      var del = CRM.store.get("customers", seg[2]);
      if (!del) return err(404, "Customer not found.");
      if (!CRM.auth.canDeleteRecord(del)) return err(403, "Only Admin/Manager can delete customers.");
      CRM.store.remove("customers", del.id);
      CRM.audit.log({ module: "Customer", action: "Delete (API)", recordId: del.id, details: del.code });
      return ok(200, { message: "Customer deleted." });
    }
    // GET /api/leads  +  POST /api/leads
    if (seg[0] === "api" && seg[1] === "leads" && seg.length === 2) {
      if (method === "GET") return ok(200, { count: CRM.store.scoped("leads").length,
        data: CRM.store.scoped("leads").map(leadDTO) });
      if (method === "POST") {
        var le = CRM.validators.validateLead(body || {});
        if (Object.keys(le).length) return err(400, "Validation failed.", le);
        var lr = Object.assign({ id: U.uid("l"), code: CRM.store.nextCode("lead", "LEAD"),
          status: "New", assignedTo: user.id, createdAt: new Date().toISOString() }, body);
        CRM.store.insert("leads", lr);
        CRM.audit.log({ module: "Lead", action: "Create (API)", recordId: lr.id, details: lr.code });
        return ok(201, leadDTO(lr));
      }
    }
    // GET /api/opportunities  +  POST /api/opportunities
    if (seg[0] === "api" && seg[1] === "opportunities" && seg.length === 2) {
      if (method === "GET") return ok(200, { count: CRM.store.scoped("opportunities").length,
        data: CRM.store.scoped("opportunities").map(oppDTO) });
      if (method === "POST") {
        var oe = CRM.validators.validateOpportunity(body || {});
        if (Object.keys(oe).length) return err(400, "Validation failed.", oe);
        var or_ = Object.assign({ id: U.uid("o"), ownerId: user.id, status: "Open",
          createdAt: new Date().toISOString() }, body);
        CRM.store.insert("opportunities", or_);
        CRM.audit.log({ module: "Opportunity", action: "Create (API)", recordId: or_.id, details: or_.name });
        return ok(201, oppDTO(or_));
      }
    }
    // GET /api/reports/pipeline
    if (seg[0] === "api" && seg[1] === "reports" && seg[2] === "pipeline" && method === "GET") {
      if (user.role === "sales") return err(403, "Pipeline report requires Manager or Admin.");
      var stages = {};
      CRM.store.scoped("opportunities").forEach(function (o) {
        if (o.stage === "Won" || o.stage === "Lost") return;
        stages[o.stage] = (stages[o.stage] || 0) + o.amount;
      });
      return ok(200, { stages: stages });
    }

    return err(404, "Unknown endpoint: " + method + " " + path);
  }

  var DOCS = [
    { method: "POST", path: "/api/auth/login", desc: "Authenticate user, returns bearer token", access: "Public" },
    { method: "GET", path: "/api/customers", desc: "List customers in your scope", access: "Authorized" },
    { method: "GET", path: "/api/customers/{id}", desc: "Get one customer", access: "Authorized" },
    { method: "POST", path: "/api/customers", desc: "Create customer (validated)", access: "Authorized" },
    { method: "PUT", path: "/api/customers/{id}", desc: "Update customer", access: "Authorized" },
    { method: "DELETE", path: "/api/customers/{id}", desc: "Delete customer", access: "Admin/Manager" },
    { method: "GET", path: "/api/leads", desc: "List leads in your scope", access: "Authorized" },
    { method: "POST", path: "/api/leads", desc: "Create lead (validated)", access: "Authorized" },
    { method: "GET", path: "/api/opportunities", desc: "List opportunities in your scope", access: "Authorized" },
    { method: "POST", path: "/api/opportunities", desc: "Create opportunity (validated)", access: "Authorized" },
    { method: "GET", path: "/api/reports/pipeline", desc: "Stage-wise pipeline totals", access: "Manager/Admin" }
  ];

  CRM.api = { handle: handle, DOCS: DOCS };
})();
