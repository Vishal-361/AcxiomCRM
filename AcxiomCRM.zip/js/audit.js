/* AcxiomCRM — audit logging (append-only) */
(function () {
  "use strict";
  var U = CRM.utils;

  function log(entry) {
    var u = null;
    try { u = CRM.auth.currentUser(); } catch (e) {}
    var rec = {
      id: U.uid("aud"),
      timestamp: new Date().toISOString(),
      userId: entry.userId || (u ? u.id : null),
      userName: entry.userName || (u ? u.name : (entry.actor || "System")),
      module: entry.module || "—",
      action: entry.action || "—",
      recordId: entry.recordId || null,
      result: entry.result || "Success",
      details: entry.details || "",
      ip: "127.0.0.1"
    };
    CRM.store.insert("audit", rec);
    return rec;
  }

  CRM.audit = { log: log };
})();
