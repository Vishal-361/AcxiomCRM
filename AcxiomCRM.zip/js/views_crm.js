/* AcxiomCRM — CRM module views */
(function () {
  "use strict";
  var U = CRM.utils;

  function salesUsers() {
    return CRM.store.all("users").filter(function (u) { return u.isActive && u.role !== "admin"; });
  }
  function userOptions(sel) {
    return salesUsers().map(function (u) { return { v: u.id, t: u.name + " (" + CRM.auth.roleLabel(u.role) + ")" }; });
  }
  function relatedLabel(type, id) {
    var r = CRM.store.get(type + "s", id);
    if (!r) return "—";
    return (r.code ? r.code + " · " : "") + (r.name || "");
  }
  function logCrud(module, action, rec, details) {
    CRM.audit.log({ module: module, action: action, recordId: rec.id, result: "Success",
      details: details || (rec.code || rec.name || rec.id) });
  }
  function ownerCell(rec) { return U.esc(CRM.store.userName(rec.ownerId || rec.assignedTo)); }

  /* ==================== CUSTOMERS ==================== */
  CRM.ui.route("customers", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Customers</h2><p>Master records with duplicate protection.</p></div>' +
      '<button class="btn btn-primary" id="c-add">+ New Customer</button></div>' +
      '<div class="stat-row" id="c-stats"></div><div id="c-list"></div>';

    function stats() {
      var all = CRM.store.scoped("customers");
      view.querySelector("#c-stats").innerHTML =
        '<div class="stat-chip">Total <b>' + all.length + "</b></div>" +
        '<div class="stat-chip">Active <b>' + all.filter(function (c) { return c.status === "Active"; }).length + "</b></div>" +
        '<div class="stat-chip">Prospects <b>' + all.filter(function (c) { return c.status === "Prospect"; }).length + "</b></div>";
    }
    function formHTML(c) {
      c = c || {};
      var canAssign = me.role !== "sales";
      return '<div class="f-grid">' +
        CRM.ui.F.text("name", "Customer Name", { req: true, value: c.name, max: 80 }) +
        CRM.ui.F.text("company", "Company", { req: true, value: c.company, max: 120 }) +
        CRM.ui.F.email("email", "Email", { req: true, value: c.email, max: 120 }) +
        CRM.ui.F.tel("phone", "Phone", { req: true, value: c.phone, placeholder: "10-digit mobile", hint: "Must be unique across customers." }) +
        CRM.ui.F.text("address", "Address", { value: c.address, max: 250, full: true }) +
        CRM.ui.F.text("city", "City", { value: c.city, max: 60 }) +
        CRM.ui.F.text("state", "State", { value: c.state, max: 60 }) +
        CRM.ui.F.select("status", "Status", { value: c.status || "Prospect",
          options: ["Active", "Prospect", "Inactive"].map(function (s) { return { v: s, t: s }; }) }) +
        (canAssign ? CRM.ui.F.select("ownerId", "Assigned To", { value: c.ownerId || me.id, options: userOptions() }) : "") +
        CRM.ui.F.textarea("notes", "Notes", { value: c.notes, full: true }) +
        "</div>";
    }
    function saveCustomer(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      // client-side quick pass
      var errs = CRM.validators.validateCustomer(Object.assign({}, existing, v), !!existing);
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      // "server-side" enforcement layer (re-validates, as a real server would)
      var serverErrs = CRM.validators.validateCustomer(Object.assign({}, existing, v), !!existing);
      if (Object.keys(serverErrs).length) { CRM.ui.showErrors(form, serverErrs); done(); return false; }
      if (existing) {
        CRM.store.update("customers", existing.id, Object.assign(v, { phone: CRM.validators.normPhone(v.phone), modifiedAt: new Date().toISOString() }));
        logCrud("Customer", "Update", existing, existing.code);
        CRM.ui.toast("Customer updated.", "ok");
      } else {
        var rec = Object.assign({ id: U.uid("c"), code: CRM.store.nextCode("customer", "CUST"),
          ownerId: me.id, phone: CRM.validators.normPhone(v.phone),
          createdAt: new Date().toISOString(), createdBy: me.id, modifiedAt: new Date().toISOString() }, v);
        CRM.store.insert("customers", rec);
        logCrud("Customer", "Create", rec);
        CRM.ui.toast("Customer " + rec.code + " created.", "ok");
      }
      stats(); table.refresh();
    }

    var table;
    function mountTable() {
      table = CRM.ui.dataView(view.querySelector("#c-list"), {
        getRows: function () { return CRM.store.scoped("customers"); },
        searchKeys: ["name", "email", "phone", "company", "code"],
        searchPlaceholder: "Search name, email, phone, company…",
        columns: [
          { key: "code", label: "Code" },
          { key: "name", label: "Customer", render: function (r) { return "<b>" + U.esc(r.name) + "</b>"; } },
          { key: "company", label: "Company", render: function (r) { return U.esc(r.company); } },
          { key: "email", label: "Email", render: function (r) { return U.esc(r.email); }, sort: false },
          { key: "phone", label: "Phone", render: function (r) { return U.esc(r.phone); }, sort: false },
          { key: "status", label: "Status", render: function (r) { return CRM.ui.statusPill(r.status); } },
          { key: "ownerId", label: "Owner", render: ownerCell }
        ],
        actions: function (r) { return CRM.ui.actionBtns(CRM.auth.canEditRecord(r), CRM.auth.canDeleteRecord(r)); },
        onAction: function (act, id) {
          var r = CRM.store.get("customers", id);
          if (act === "view") {
            var fus = CRM.store.all("followups").filter(function (f) { return f.relatedType === "customer" && f.relatedId === id; });
            var opps = CRM.store.all("opportunities").filter(function (o) { return o.customerId === id; });
            CRM.ui.detailModal(r.code + " — " + r.name, [
              ["Company", U.esc(r.company)], ["Email", U.esc(r.email)], ["Phone", U.esc(r.phone)],
              ["Address", U.esc([r.address, r.city, r.state].filter(Boolean).join(", "))],
              ["Status", CRM.ui.statusPill(r.status)], ["Owner", ownerCell(r)],
              ["Open follow-ups", fus.filter(function (f) { return f.status === "Planned"; }).length],
              ["Opportunities", opps.length + " (" + U.fmtMoney(opps.reduce(function (s, o) { return s + o.amount; }, 0)) + ")"],
              ["Notes", U.esc(r.notes || "—")]
            ]);
          } else if (act === "edit") {
            CRM.ui.openModal({ title: "Edit Customer", bodyHTML: formHTML(r),
              onOk: function (f, done) { return saveCustomer(f, r, done); } });
          } else if (act === "del") {
            CRM.ui.confirmDlg("Delete customer?", "Delete " + r.code + " (" + r.name + ")? This cannot be undone.")
              .then(function (yes) {
                if (!yes) return;
                CRM.store.remove("customers", id);
                logCrud("Customer", "Delete", r);
                CRM.ui.toast("Customer deleted.", "ok"); stats(); table.refresh();
              });
          }
        }
      });
    }
    stats(); mountTable();
    view.querySelector("#c-add").onclick = function () {
      CRM.ui.openModal({ title: "New Customer", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveCustomer(f, null, done); } });
    };
  });

  /* ==================== LEADS ==================== */
  CRM.ui.route("leads", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Leads</h2><p>Qualify prospects, then convert the winners.</p></div>' +
      '<button class="btn btn-primary" id="l-add">+ New Lead</button></div>' +
      '<div class="stat-row" id="l-stats"></div><div id="l-list"></div>';

    function stats() {
      var all = CRM.store.scoped("leads");
      var open = all.filter(function (l) { return ["New", "Contacted", "Qualified"].indexOf(l.status) !== -1; });
      view.querySelector("#l-stats").innerHTML =
        '<div class="stat-chip">Total <b>' + all.length + "</b></div>" +
        '<div class="stat-chip">Open <b>' + open.length + "</b></div>" +
        '<div class="stat-chip">Converted <b>' + all.filter(function (l) { return l.status === "Converted"; }).length + "</b></div>" +
        '<div class="stat-chip">Pipeline value <b>' + U.fmtMoney(all.reduce(function (s, l) { return s + (Number(l.expectedValue) || 0); }, 0)) + "</b></div>";
    }
    function statusOptions(current) {
      var allowed = current ? CRM.validators.LEAD_TRANSITIONS[current] || [] : CRM.validators.LEAD_STATUSES;
      var list = current ? [current].concat(allowed.filter(function (s) { return s !== current; })) : allowed;
      return list.map(function (s) { return { v: s, t: s }; });
    }
    function formHTML(l) {
      l = l || {};
      var canAssign = me.role !== "sales";
      return '<div class="f-grid">' +
        CRM.ui.F.text("name", "Lead Name", { req: true, value: l.name, max: 80 }) +
        CRM.ui.F.text("company", "Company", { value: l.company, max: 120 }) +
        CRM.ui.F.email("email", "Email", { value: l.email, max: 120 }) +
        CRM.ui.F.tel("phone", "Phone", { value: l.phone, placeholder: "10-digit mobile" }) +
        CRM.ui.F.select("source", "Source", { value: l.source || "Website",
          options: ["Website", "Referral", "Cold Call", "Trade Show", "Social Media"].map(function (s) { return { v: s, t: s }; }) }) +
        CRM.ui.F.select("status", "Status", { req: true, value: l.status || "New", options: statusOptions(l.status),
          hint: l.status ? "Only valid next steps are offered." : "" }) +
        CRM.ui.F.select("priority", "Priority", { value: l.priority || "Medium",
          options: ["High", "Medium", "Low"].map(function (s) { return { v: s, t: s }; }) }) +
        CRM.ui.F.number("expectedValue", "Expected Value (₹)", { value: l.expectedValue || "", min: 0, step: 1000 }) +
        (canAssign ? CRM.ui.F.select("assignedTo", "Assigned To", { value: l.assignedTo || me.id, options: userOptions() }) : "") +
        CRM.ui.F.textarea("notes", "Notes", { value: l.notes, full: true }) +
        "</div>";
    }
    function saveLead(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      if (v.expectedValue === "") v.expectedValue = 0;
      var merged = Object.assign({}, existing, v);
      var errs = CRM.validators.validateLead(merged);
      if (existing && !errs.status) {
        var tErr = CRM.validators.validateLeadTransition(existing.status, v.status);
        if (tErr) errs.status = tErr;
      }
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      if (v.phone) v.phone = CRM.validators.normPhone(v.phone);
      if (existing) {
        CRM.store.update("leads", existing.id, v);
        logCrud("Lead", "Update", existing, existing.code + " → " + v.status);
        CRM.ui.toast("Lead updated.", "ok");
      } else {
        var rec = Object.assign({ id: U.uid("l"), code: CRM.store.nextCode("lead", "LEAD"),
          assignedTo: me.id, createdAt: new Date().toISOString() }, v);
        CRM.store.insert("leads", rec);
        logCrud("Lead", "Create", rec);
        CRM.ui.toast("Lead " + rec.code + " created.", "ok");
      }
      stats(); table.refresh();
    }
    function convertLead(lead) {
      CRM.ui.openModal({ title: "Convert " + lead.code + " to Customer",
        okLabel: "Convert Lead",
        bodyHTML: "<p style='color:var(--muted);margin-top:0'>Creates a customer record" +
          (Number(lead.expectedValue) > 0 ? " and an opening opportunity" : "") +
          ", then marks the lead Converted. The audit log records the conversion.</p>" +
          '<div class="f-grid">' +
          CRM.ui.F.text("company", "Company", { req: true, value: lead.company, max: 120 }) +
          CRM.ui.F.select("oppStage", "Opportunity Stage", { value: "Qualification",
            options: CRM.validators.OPP_STAGES.filter(function (s) { return s !== "Won" && s !== "Lost"; }).map(function (s) { return { v: s, t: s }; }) }) +
          "</div>",
        onOk: function (f, done) {
          var v = CRM.ui.collectForm(f);
          if (!v.company.trim()) { CRM.ui.showErrors(f, { company: "Company is required." }); done(); return false; }
          var cust = { id: U.uid("c"), code: CRM.store.nextCode("customer", "CUST"),
            name: lead.name, email: lead.email || "", phone: lead.phone || "", company: v.company,
            address: "", city: "", state: "", status: "Active", ownerId: lead.assignedTo,
            notes: "Converted from " + lead.code, createdAt: new Date().toISOString(),
            createdBy: me.id, modifiedAt: new Date().toISOString() };
          CRM.store.insert("customers", cust);
          if (Number(lead.expectedValue) > 0) {
            CRM.store.insert("opportunities", { id: U.uid("o"), name: v.company + " — New Business",
              customerId: cust.id, ownerId: lead.assignedTo, stage: v.oppStage,
              amount: Number(lead.expectedValue), probability: 25,
              expectedCloseDate: U.todayISO().slice(0, 8) + "01",
              source: lead.source, notes: "Auto-created from " + lead.code, status: "Open",
              createdAt: new Date().toISOString() });
          }
          CRM.store.update("leads", lead.id, { status: "Converted" });
          CRM.audit.log({ module: "Lead", action: "Convert", recordId: lead.id, result: "Success",
            details: lead.code + " → " + cust.code });
          CRM.ui.toast("Lead converted to " + cust.code + ".", "ok");
          stats(); table.refresh();
        }
      });
    }

    var table;
    table = CRM.ui.dataView(view.querySelector("#l-list"), {
      getRows: function () { return CRM.store.scoped("leads"); },
      searchKeys: ["name", "company", "email", "phone", "code", "source"],
      searchPlaceholder: "Search leads…",
      columns: [
        { key: "code", label: "Code" },
        { key: "name", label: "Lead", render: function (r) { return "<b>" + U.esc(r.name) + "</b><div style='font-size:12px;color:var(--muted)'>" + U.esc(r.company || "") + "</div>"; } },
        { key: "source", label: "Source" },
        { key: "status", label: "Status", render: function (r) { return CRM.ui.statusPill(r.status); } },
        { key: "priority", label: "Priority", render: function (r) {
          return CRM.ui.pill(r.priority, r.priority === "High" ? "p-red" : r.priority === "Medium" ? "p-amber" : "p-gray"); } },
        { key: "expectedValue", label: "Exp. Value", num: true, render: function (r) { return U.fmtMoney(r.expectedValue); } },
        { key: "assignedTo", label: "Assigned", render: ownerCell }
      ],
      actions: function (r) {
        var h = CRM.ui.actionBtns(CRM.auth.canEditRecord(r), CRM.auth.canDeleteRecord(r));
        if (r.status === "Qualified" && CRM.auth.canEditRecord(r))
          h = '<button class="btn btn-sm btn-primary" data-act="convert" style="margin-right:6px">Convert</button>' + h;
        return h;
      },
      onAction: function (act, id) {
        var r = CRM.store.get("leads", id);
        if (act === "view") {
          CRM.ui.detailModal(r.code + " — " + r.name, [
            ["Company", U.esc(r.company || "—")], ["Email", U.esc(r.email || "—")], ["Phone", U.esc(r.phone || "—")],
            ["Source", U.esc(r.source)], ["Status", CRM.ui.statusPill(r.status)],
            ["Priority", U.esc(r.priority)], ["Expected Value", U.fmtMoney(r.expectedValue)],
            ["Assigned", ownerCell(r)], ["Notes", U.esc(r.notes || "—")]
          ]);
        } else if (act === "edit") {
          CRM.ui.openModal({ title: "Edit Lead", bodyHTML: formHTML(r),
            onOk: function (f, done) { return saveLead(f, r, done); } });
        } else if (act === "convert") { convertLead(r); }
        else if (act === "del") {
          CRM.ui.confirmDlg("Delete lead?", "Delete " + r.code + " (" + r.name + ")?").then(function (yes) {
            if (!yes) return;
            CRM.store.remove("leads", id); logCrud("Lead", "Delete", r);
            CRM.ui.toast("Lead deleted.", "ok"); stats(); table.refresh();
          });
        }
      }
    });
    stats();
    view.querySelector("#l-add").onclick = function () {
      CRM.ui.openModal({ title: "New Lead", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveLead(f, null, done); } });
    };
  });

  /* ==================== OPPORTUNITIES ==================== */
  CRM.ui.route("opportunities", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Opportunities</h2><p>Drag-free pipeline — click a card to work it.</p></div>' +
      '<div style="display:flex;gap:10px"><div class="seg" id="o-viewseg"><button data-v="pipe" class="on">Pipeline</button><button data-v="list">List</button></div>' +
      '<button class="btn btn-primary" id="o-add">+ New Opportunity</button></div></div>' +
      '<div class="stat-row" id="o-stats"></div><div id="o-body"></div>';

    function stats() {
      var all = CRM.store.scoped("opportunities");
      var open = all.filter(function (o) { return o.stage !== "Won" && o.stage !== "Lost"; });
      var weighted = open.reduce(function (s, o) { return s + o.amount * o.probability / 100; }, 0);
      view.querySelector("#o-stats").innerHTML =
        '<div class="stat-chip">Open <b>' + open.length + "</b></div>" +
        '<div class="stat-chip">Pipeline <b>' + U.fmtMoney(open.reduce(function (s, o) { return s + o.amount; }, 0)) + "</b></div>" +
        '<div class="stat-chip">Weighted <b>' + U.fmtMoney(weighted) + "</b></div>" +
        '<div class="stat-chip">Won <b>' + all.filter(function (o) { return o.stage === "Won"; }).length + "</b></div>" +
        '<div class="stat-chip">Lost <b>' + all.filter(function (o) { return o.stage === "Lost"; }).length + "</b></div>";
    }
    function custOptions(sel) {
      return CRM.store.scoped("customers").map(function (c) { return { v: c.id, t: c.code + " — " + c.company }; });
    }
    function formHTML(o) {
      o = o || {};
      var canAssign = me.role !== "sales";
      return '<div class="f-grid">' +
        CRM.ui.F.text("name", "Opportunity Name", { req: true, value: o.name, max: 120, full: true }) +
        CRM.ui.F.select("customerId", "Customer", { req: true, value: o.customerId || "", options: [{ v: "", t: "— Select —" }].concat(custOptions()) }) +
        (canAssign ? CRM.ui.F.select("ownerId", "Owner", { value: o.ownerId || me.id, options: userOptions() }) : "") +
        CRM.ui.F.select("stage", "Stage", { value: o.stage || "Qualification",
          options: CRM.validators.OPP_STAGES.map(function (s) { return { v: s, t: s }; }) }) +
        CRM.ui.F.number("amount", "Amount (₹)", { req: true, value: o.amount == null ? "" : o.amount, min: 1, step: 1000 }) +
        CRM.ui.F.number("probability", "Probability %", { req: true, value: o.probability == null ? "" : o.probability, min: 0, max: 100 }) +
        CRM.ui.F.date("expectedCloseDate", "Expected Close Date", { req: true, value: o.expectedCloseDate, hint: "Cannot be in the past for an open opportunity." }) +
        CRM.ui.F.text("source", "Source", { value: o.source || "" }) +
        CRM.ui.F.textarea("notes", "Notes", { value: o.notes, full: true }) +
        "</div>";
    }
    function saveOpp(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      var errs = CRM.validators.validateOpportunity(Object.assign({}, existing, v));
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      var patch = Object.assign({}, v, { amount: Number(v.amount), probability: Number(v.probability),
        status: (v.stage === "Won" || v.stage === "Lost") ? "Closed" : "Open" });
      if (existing) {
        CRM.store.update("opportunities", existing.id, patch);
        logCrud("Opportunity", "Update", existing, existing.name + " → " + v.stage);
        CRM.ui.toast("Opportunity updated.", "ok");
      } else {
        var rec = Object.assign({ id: U.uid("o"), ownerId: me.id, createdAt: new Date().toISOString() }, patch);
        CRM.store.insert("opportunities", rec);
        logCrud("Opportunity", "Create", rec, rec.name);
        CRM.ui.toast("Opportunity created.", "ok");
      }
      stats(); renderBody();
    }
    function oppDetail(o) {
      var c = CRM.store.get("customers", o.customerId);
      CRM.ui.detailModal(o.name, [
        ["Customer", U.esc(c ? c.company : "—")], ["Stage", CRM.ui.statusPill(o.stage)],
        ["Amount", U.fmtMoney(o.amount)], ["Probability", o.probability + "%"],
        ["Weighted Value", "<b>" + U.fmtMoney(o.amount * o.probability / 100) + "</b>"],
        ["Expected Close", U.fmtDate(o.expectedCloseDate)], ["Owner", ownerCell(o)],
        ["Source", U.esc(o.source || "—")], ["Notes", U.esc(o.notes || "—")]
      ]);
    }

    var mode = "pipe", listTable = null;
    function renderBody() {
      var body = view.querySelector("#o-body");
      var all = CRM.store.scoped("opportunities");
      if (mode === "pipe") {
        body.innerHTML = '<div class="kanban">' + CRM.validators.OPP_STAGES.map(function (st) {
          var items = all.filter(function (o) { return o.stage === st; });
          var total = items.reduce(function (s, o) { return s + o.amount; }, 0);
          return '<div class="col"><div class="col-h"><span>' + CRM.ui.statusPill(st) + '</span><span class="badge-n">' + items.length + "</span></div>" +
            '<div class="col-total">' + U.fmtMoney(total) + "</div>" +
            items.map(function (o) {
              var canE = CRM.auth.canEditRecord(o);
              return '<div class="opp-card" data-id="' + o.id + '"><div class="oc-t">' + U.esc(o.name) + "</div>" +
                '<div class="oc-m"><span>' + U.fmtMoney(o.amount) + "</span><span>" + o.probability + "%</span></div>" +
                '<div class="prog"><i style="width:' + o.probability + '%"></i></div>' +
                '<div class="oc-m" style="margin-top:6px"><span>' + U.esc(CRM.store.userName(o.ownerId)) + "</span>" +
                (canE ? '<span><button class="icon-btn" data-act="edit" data-id="' + o.id + '" title="Edit">✎</button>' +
                  (CRM.auth.canDeleteRecord(o) ? '<button class="icon-btn danger" data-act="del" data-id="' + o.id + '" title="Delete">🗑</button>' : "") + "</span>" : "") +
                "</div></div>";
            }).join("") + "</div>";
        }).join("") + "</div>";
        body.querySelectorAll(".opp-card").forEach(function (card) {
          card.addEventListener("click", function (e) {
            if (e.target.closest("[data-act]")) return;
            oppDetail(CRM.store.get("opportunities", card.getAttribute("data-id")));
          });
        });
        body.querySelectorAll("[data-act]").forEach(function (b) {
          b.addEventListener("click", function (e) {
            e.stopPropagation();
            var o = CRM.store.get("opportunities", b.getAttribute("data-id"));
            if (b.getAttribute("data-act") === "edit")
              CRM.ui.openModal({ title: "Edit Opportunity", bodyHTML: formHTML(o),
                onOk: function (f, done) { return saveOpp(f, o, done); } });
            else CRM.ui.confirmDlg("Delete opportunity?", "Delete “" + o.name + "”?").then(function (yes) {
              if (!yes) return;
              CRM.store.remove("opportunities", o.id); logCrud("Opportunity", "Delete", o);
              CRM.ui.toast("Opportunity deleted.", "ok"); stats(); renderBody();
            });
          });
        });
      } else {
        body.innerHTML = '<div id="o-list"></div>';
        listTable = CRM.ui.dataView(body.querySelector("#o-list"), {
          getRows: function () { return CRM.store.scoped("opportunities"); },
          searchKeys: ["name", function (r) { var c = CRM.store.get("customers", r.customerId); return c ? c.company : ""; }],
          searchPlaceholder: "Search opportunities…",
          columns: [
            { key: "name", label: "Opportunity", render: function (r) { return "<b>" + U.esc(r.name) + "</b>"; } },
            { key: "customerId", label: "Customer", render: function (r) { var c = CRM.store.get("customers", r.customerId); return U.esc(c ? c.company : "—"); } },
            { key: "stage", label: "Stage", render: function (r) { return CRM.ui.statusPill(r.stage); } },
            { key: "amount", label: "Amount", num: true, render: function (r) { return U.fmtMoney(r.amount); } },
            { key: "probability", label: "Prob.", num: true, render: function (r) { return r.probability + "%"; } },
            { key: "weighted", label: "Weighted", num: true, sort: false, render: function (r) { return U.fmtMoney(r.amount * r.probability / 100); } },
            { key: "expectedCloseDate", label: "Close Date", render: function (r) { return U.fmtDate(r.expectedCloseDate); } },
            { key: "ownerId", label: "Owner", render: ownerCell }
          ],
          actions: function (r) { return CRM.ui.actionBtns(CRM.auth.canEditRecord(r), CRM.auth.canDeleteRecord(r)); },
          onAction: function (act, id) {
            var o = CRM.store.get("opportunities", id);
            if (act === "view") oppDetail(o);
            else if (act === "edit") CRM.ui.openModal({ title: "Edit Opportunity", bodyHTML: formHTML(o),
              onOk: function (f, done) { return saveOpp(f, o, done); } });
            else if (act === "del") CRM.ui.confirmDlg("Delete opportunity?", "Delete “" + o.name + "”?").then(function (yes) {
              if (!yes) return;
              CRM.store.remove("opportunities", id); logCrud("Opportunity", "Delete", o);
              CRM.ui.toast("Opportunity deleted.", "ok"); stats(); renderBody();
            });
          }
        });
      }
    }

    stats(); renderBody();
    view.querySelectorAll("#o-viewseg button").forEach(function (b) {
      b.onclick = function () {
        view.querySelectorAll("#o-viewseg button").forEach(function (x) { x.classList.remove("on"); });
        b.classList.add("on"); mode = b.getAttribute("data-v"); renderBody();
      };
    });
    view.querySelector("#o-add").onclick = function () {
      CRM.ui.openModal({ title: "New Opportunity", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveOpp(f, null, done); } });
    };
  });

  /* ==================== FOLLOW-UPS ==================== */
  CRM.ui.route("followups", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Follow-Ups</h2><p>Never let a conversation go cold.</p></div>' +
      '<button class="btn btn-primary" id="f-add">+ Schedule Follow-Up</button></div>' +
      '<div class="stat-row" id="f-stats"></div>' +
      '<div class="toolbar"><div class="seg" id="f-seg">' +
      ["Planned", "Overdue", "Completed", "Missed", "Cancelled", "All"].map(function (s, i) {
        return '<button data-s="' + s + '"' + (i === 0 ? ' class="on"' : "") + ">" + s + "</button>";
      }).join("") + "</div></div><div id='f-list'></div>";

    var filter = "Planned", table;
    function stats() {
      var all = CRM.store.scoped("followups");
      var today = U.todayISO();
      view.querySelector("#f-stats").innerHTML =
        '<div class="stat-chip">Planned <b>' + all.filter(function (f) { return f.status === "Planned"; }).length + "</b></div>" +
        '<div class="stat-chip">Overdue <b>' + all.filter(function (f) { return f.status === "Planned" && f.date < today; }).length + "</b></div>" +
        '<div class="stat-chip">Due today <b>' + all.filter(function (f) { return f.status === "Planned" && f.date === today; }).length + "</b></div>";
    }
    function relOptions() {
      var out = [];
      CRM.store.scoped("customers").forEach(function (c) { out.push({ v: "customer:" + c.id, t: "👥 " + c.code + " — " + c.company }); });
      CRM.store.scoped("leads").forEach(function (l) { out.push({ v: "lead:" + l.id, t: "🎯 " + l.code + " — " + l.name }); });
      CRM.store.scoped("opportunities").forEach(function (o) { out.push({ v: "opportunity:" + o.id, t: "💼 " + o.name }); });
      return out;
    }
    function formHTML(f) {
      f = f || {};
      var relVal = f.relatedType ? f.relatedType + ":" + f.relatedId : "";
      var canAssign = me.role !== "sales";
      return '<div class="f-grid">' +
        CRM.ui.F.select("related", "Related Record", { req: true, value: relVal, options: [{ v: "", t: "— Select —" }].concat(relOptions()) }) +
        CRM.ui.F.date("date", "Follow-Up Date", { req: true, value: f.date || U.todayISO(), hint: "Cannot be earlier than today for a planned follow-up." }) +
        CRM.ui.F.text("subject", "Subject", { req: true, value: f.subject, max: 140, full: true }) +
        CRM.ui.F.select("type", "Type", { value: f.type || "Call",
          options: ["Call", "Meeting", "Email", "Task"].map(function (s) { return { v: s, t: s }; }) }) +
        CRM.ui.F.select("status", "Status", { value: f.status || "Planned",
          options: ["Planned", "Completed", "Missed", "Cancelled"].map(function (s) { return { v: s, t: s }; }) }) +
        (canAssign ? CRM.ui.F.select("assignedTo", "Assigned To", { value: f.assignedTo || me.id, options: userOptions() }) : "") +
        CRM.ui.F.textarea("notes", "Notes", { value: f.notes, full: true }) +
        "</div>";
    }
    function saveFu(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      if (!v.related) { CRM.ui.showErrors(form, { related: "Link the follow-up to a customer, lead or opportunity." }); done(); return false; }
      var parts = v.related.split(":");
      var rec = { relatedType: parts[0], relatedId: parts[1], date: v.date, subject: v.subject,
        type: v.type, status: v.status, assignedTo: v.assignedTo || me.id, notes: v.notes };
      var errs = CRM.validators.validateFollowup(Object.assign({}, existing, rec));
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      if (existing) {
        CRM.store.update("followups", existing.id, rec);
        logCrud("FollowUp", "Update", existing, existing.subject + " → " + v.status);
        CRM.ui.toast("Follow-up updated.", "ok");
      } else {
        var r2 = Object.assign({ id: U.uid("f"), createdAt: new Date().toISOString() }, rec);
        CRM.store.insert("followups", r2);
        logCrud("FollowUp", "Create", r2, r2.subject);
        CRM.ui.toast("Follow-up scheduled.", "ok");
      }
      stats(); table.refresh();
    }

    function mount() {
      table = CRM.ui.dataView(view.querySelector("#f-list"), {
        getRows: function () {
          var all = CRM.store.scoped("followups").slice().sort(function (a, b) { return a.date < b.date ? -1 : 1; });
          var today = U.todayISO();
          if (filter === "Overdue") return all.filter(function (f) { return f.status === "Planned" && f.date < today; });
          if (filter === "All") return all;
          return all.filter(function (f) { return f.status === filter; });
        },
        searchKeys: ["subject", "notes", function (r) { return relatedLabel(r.relatedType, r.relatedId); }],
        searchPlaceholder: "Search follow-ups…",
        columns: [
          { key: "date", label: "Date", render: function (r) {
            var overdue = r.status === "Planned" && r.date < U.todayISO();
            return (overdue ? "🔴 " : "") + U.fmtDate(r.date); } },
          { key: "subject", label: "Subject", render: function (r) { return "<b>" + U.esc(r.subject) + "</b>"; } },
          { key: "related", label: "Related", sort: false, render: function (r) { return U.esc(relatedLabel(r.relatedType, r.relatedId)); } },
          { key: "type", label: "Type" },
          { key: "status", label: "Status", render: function (r) {
            var overdue = r.status === "Planned" && r.date < U.todayISO();
            return overdue ? CRM.ui.pill("Overdue", "p-red") : CRM.ui.statusPill(r.status); } },
          { key: "assignedTo", label: "Assigned", render: ownerCell }
        ],
        actions: function (r) {
          var h = "";
          if (r.status === "Planned" && CRM.auth.canEditRecord(r))
            h += '<button class="btn btn-sm btn-primary" data-act="done" style="margin-right:6px">✓ Done</button>';
          h += CRM.ui.actionBtns(CRM.auth.canEditRecord(r), CRM.auth.canDeleteRecord(r));
          return h;
        },
        onAction: function (act, id) {
          var r = CRM.store.get("followups", id);
          if (act === "done") {
            CRM.store.update("followups", id, { status: "Completed" });
            logCrud("FollowUp", "Complete", r, r.subject);
            CRM.ui.toast("Marked as completed. Nice work! 🎉", "ok");
            stats(); table.refresh();
          } else if (act === "view") {
            CRM.ui.detailModal(r.subject, [
              ["Date", U.fmtDate(r.date)], ["Type", U.esc(r.type)], ["Status", CRM.ui.statusPill(r.status)],
              ["Related", U.esc(relatedLabel(r.relatedType, r.relatedId))],
              ["Assigned", ownerCell(r)], ["Notes", U.esc(r.notes || "—")]
            ]);
          } else if (act === "edit") {
            CRM.ui.openModal({ title: "Edit Follow-Up", bodyHTML: formHTML(r),
              onOk: function (f, done) { return saveFu(f, r, done); } });
          } else if (act === "del") {
            CRM.ui.confirmDlg("Delete follow-up?", "Delete “" + r.subject + "”?").then(function (yes) {
              if (!yes) return;
              CRM.store.remove("followups", id); logCrud("FollowUp", "Delete", r);
              CRM.ui.toast("Follow-up deleted.", "ok"); stats(); table.refresh();
            });
          }
        }
      });
    }
    stats(); mount();
    view.querySelectorAll("#f-seg button").forEach(function (b) {
      b.onclick = function () {
        view.querySelectorAll("#f-seg button").forEach(function (x) { x.classList.remove("on"); });
        b.classList.add("on"); filter = b.getAttribute("data-s"); mount();
      };
    });
    view.querySelector("#f-add").onclick = function () {
      CRM.ui.openModal({ title: "Schedule Follow-Up", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveFu(f, null, done); } });
    };
  });

  /* ==================== ACTIVITIES ==================== */
  CRM.ui.route("activities", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Activities</h2><p>Log every call, meeting, email and task.</p></div>' +
      '<button class="btn btn-primary" id="a-add">+ Log Activity</button></div><div id="a-list"></div>';

    var ICONS = { Call: "📞", Meeting: "🤝", Email: "✉", Task: "☑" };
    function formHTML(a) {
      a = a || {};
      var relVal = a.relatedType ? a.relatedType + ":" + a.relatedId : "";
      var relOpts = [];
      CRM.store.scoped("customers").forEach(function (c) { relOpts.push({ v: "customer:" + c.id, t: "👥 " + c.code }); });
      CRM.store.scoped("leads").forEach(function (l) { relOpts.push({ v: "lead:" + l.id, t: "🎯 " + l.code }); });
      CRM.store.scoped("opportunities").forEach(function (o) { relOpts.push({ v: "opportunity:" + o.id, t: "💼 " + o.name.slice(0, 30) }); });
      var canAssign = me.role !== "sales";
      return '<div class="f-grid">' +
        CRM.ui.F.select("type", "Activity Type", { req: true, value: a.type || "Call",
          options: ["Call", "Meeting", "Email", "Task"].map(function (s) { return { v: s, t: ICONS[s] + " " + s }; }) }) +
        CRM.ui.F.date("date", "Date", { req: true, value: a.date || U.todayISO() }) +
        CRM.ui.F.text("subject", "Subject", { req: true, value: a.subject, max: 140, full: true }) +
        CRM.ui.F.select("related", "Related Record", { value: relVal, options: [{ v: "", t: "— None —" }].concat(relOpts) }) +
        CRM.ui.F.select("status", "Status", { value: a.status || "Completed",
          options: ["Planned", "Completed"].map(function (s) { return { v: s, t: s }; }) }) +
        (canAssign ? CRM.ui.F.select("assignedTo", "Assigned To", { value: a.assignedTo || me.id, options: userOptions() }) : "") +
        CRM.ui.F.textarea("description", "Description", { value: a.description, full: true }) +
        "</div>";
    }
    function saveAct(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      var rel = v.related ? v.related.split(":") : [null, null];
      var rec = { type: v.type, subject: v.subject, description: v.description, date: v.date,
        relatedType: rel[0], relatedId: rel[1], assignedTo: v.assignedTo || me.id, status: v.status };
      var errs = CRM.validators.validateActivity(rec);
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      if (existing) {
        CRM.store.update("activities", existing.id, rec);
        logCrud("Activity", "Update", existing, existing.subject);
        CRM.ui.toast("Activity updated.", "ok");
      } else {
        var r2 = Object.assign({ id: U.uid("a"), createdAt: new Date().toISOString() }, rec);
        CRM.store.insert("activities", r2);
        logCrud("Activity", "Create", r2, r2.type + ": " + r2.subject);
        CRM.ui.toast("Activity logged.", "ok");
      }
      table.refresh();
    }

    var table = CRM.ui.dataView(view.querySelector("#a-list"), {
      getRows: function () { return CRM.store.scoped("activities").slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }); },
      searchKeys: ["subject", "description", "type"],
      searchPlaceholder: "Search activities…",
      columns: [
        { key: "type", label: "Type", render: function (r) { return ICONS[r.type] + " " + r.type; } },
        { key: "subject", label: "Subject", render: function (r) { return "<b>" + U.esc(r.subject) + "</b>"; } },
        { key: "related", label: "Related", sort: false, render: function (r) {
          return r.relatedType ? U.esc(relatedLabel(r.relatedType, r.relatedId)) : "—"; } },
        { key: "date", label: "Date", render: function (r) { return U.fmtDate(r.date); } },
        { key: "status", label: "Status", render: function (r) { return CRM.ui.statusPill(r.status); } },
        { key: "assignedTo", label: "Assigned", render: ownerCell }
      ],
      actions: function (r) { return CRM.ui.actionBtns(CRM.auth.canEditRecord(r), CRM.auth.canDeleteRecord(r)); },
      onAction: function (act, id) {
        var r = CRM.store.get("activities", id);
        if (act === "view") {
          CRM.ui.detailModal(ICONS[r.type] + " " + r.subject, [
            ["Type", r.type], ["Date", U.fmtDate(r.date)], ["Status", CRM.ui.statusPill(r.status)],
            ["Related", r.relatedType ? U.esc(relatedLabel(r.relatedType, r.relatedId)) : "—"],
            ["Assigned", ownerCell(r)], ["Description", U.esc(r.description || "—")]
          ]);
        } else if (act === "edit") {
          CRM.ui.openModal({ title: "Edit Activity", bodyHTML: formHTML(r),
            onOk: function (f, done) { return saveAct(f, r, done); } });
        } else if (act === "del") {
          CRM.ui.confirmDlg("Delete activity?", "Delete “" + r.subject + "”?").then(function (yes) {
            if (!yes) return;
            CRM.store.remove("activities", id); logCrud("Activity", "Delete", r);
            CRM.ui.toast("Activity deleted.", "ok"); table.refresh();
          });
        }
      }
    });
    view.querySelector("#a-add").onclick = function () {
      CRM.ui.openModal({ title: "Log Activity", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveAct(f, null, done); } });
    };
  });
})();
