/* AcxiomCRM — data layer: localStorage-backed store, seed data, scoped access */
(function () {
  "use strict";
  var U = CRM.utils;
  var DB_KEY = "acxiomcrm_db_v1";

  function d(offsetDays) {
    var t = new Date(); t.setDate(t.getDate() + offsetDays);
    return t.getFullYear() + "-" + ("0" + (t.getMonth() + 1)).slice(-2) + "-" + ("0" + t.getDate()).slice(-2);
  }
  function dt(offsetDays, h, m) {
    var t = new Date(); t.setDate(t.getDate() + offsetDays); t.setHours(h || 10, m || 0, 0, 0);
    return t.toISOString();
  }

  function hashPw(salt, pw) { return U.sha256(salt + "::" + pw); }

  function seed() {
    var u = function (id, name, email, pw, role) {
      var salt = U.randHex(16);
      return { id: id, name: name, email: email, salt: salt, passwordHash: hashPw(salt, pw),
        role: role, isActive: true, failedAttempts: 0, lockoutUntil: null, createdAt: new Date().toISOString() };
    };
    var users = [
      u("u_admin", "Aarav Sharma", "admin@acxiomcrm.com", "Admin@123", "admin"),
      u("u_mgr", "Priya Nair", "manager@acxiomcrm.com", "Manager@123", "manager"),
      u("u_s1", "Rahul Verma", "rahul@acxiomcrm.com", "Sales@123", "sales"),
      u("u_s2", "Sneha Patel", "sneha@acxiomcrm.com", "Sales@123", "sales")
    ];

    var C = function (id, code, name, email, phone, company, city, state, status, ownerId, off) {
      return { id: id, code: code, name: name, email: email, phone: phone, company: company,
        address: "Plot 12, Industrial Estate", city: city, state: state, status: status,
        ownerId: ownerId, notes: "", createdAt: dt(off, 10, 15), createdBy: "u_admin", modifiedAt: dt(off, 10, 15) };
    };
    var customers = [
      C("c1", "CUST-0001", "Vikram Singh", "vikram@meridianfabrics.in", "9820012345", "Meridian Fabrics Pvt Ltd", "Bhubaneswar", "Odisha", "Active", "u_s1", -120),
      C("c2", "CUST-0002", "Ananya Das", "ananya@kalingasteel.in", "9830023456", "Kalinga Steel Traders", "Cuttack", "Odisha", "Active", "u_s1", -100),
      C("c3", "CUST-0003", "Rohit Kumar", "rohit@odishaagro.in", "9840034567", "Odisha Agro Foods", "Sambalpur", "Odisha", "Active", "u_s2", -90),
      C("c4", "CUST-0004", "Kavya Reddy", "kavya@coastalmarine.in", "9850045678", "Coastal Marine Services", "Paradip", "Odisha", "Prospect", "u_s2", -75),
      C("c5", "CUST-0005", "Manoj Tiwari", "manoj@utkalpolymers.in", "9860056789", "Utkal Polymers", "Rourkela", "Odisha", "Active", "u_s1", -60),
      C("c6", "CUST-0006", "Divya Nair", "divya@bhubanit.in", "9870067890", "Bhubaneswar IT Solutions", "Bhubaneswar", "Odisha", "Active", "u_s2", -45),
      C("c7", "CUST-0007", "Arjun Mohanty", "arjun@easternmining.in", "9880078901", "Eastern Mining Corp", "Keonjhar", "Odisha", "Inactive", "u_s1", -30),
      C("c8", "CUST-0008", "Sneha Iyer", "sneha@purihandicrafts.in", "9890089012", "Puri Handicrafts", "Puri", "Odisha", "Prospect", "u_s2", -20),
      C("c9", "CUST-0009", "Karan Joshi", "karan@cuttackpharma.in", "9900090123", "Cuttack Pharma Distributors", "Cuttack", "Odisha", "Active", "u_s1", -10),
      C("c10", "CUST-0010", "Pooja Mishra", "pooja@rourkelaauto.in", "9910101234", "Rourkela Auto Parts", "Rourkela", "Odisha", "Active", "u_s2", -5)
    ];

    var L = function (id, code, name, email, phone, company, source, status, priority, val, owner, off) {
      return { id: id, code: code, name: name, email: email, phone: phone, company: company,
        source: source, status: status, priority: priority, expectedValue: val, assignedTo: owner,
        notes: "", createdAt: dt(off, 11, 5) };
    };
    var leads = [
      L("l1", "LEAD-0001", "Suresh Chandra", "suresh@novatextiles.in", "9920112345", "Nova Textiles", "Website", "New", "High", 250000, "u_s1", -12),
      L("l2", "LEAD-0002", "Meera Krishnan", "meera@lighthousehotels.in", "9930123456", "Light House Hotels", "Referral", "Contacted", "Medium", 180000, "u_s2", -10),
      L("l3", "LEAD-0003", "Amitabh Bose", "amitabh@berhampursilk.in", "9940134567", "Berhampur Silk House", "Cold Call", "Qualified", "High", 420000, "u_s1", -9),
      L("l4", "LEAD-0004", "Lakshmi Rao", "lakshmi@sunrisefoods.in", "9950145678", "Sunrise Foods", "Website", "Contacted", "Low", 95000, "u_s2", -8),
      L("l5", "LEAD-0005", "Deepak Yadav", "deepak@citybuilders.in", "9960156789", "City Builders", "Trade Show", "New", "Medium", 310000, "u_s1", -6),
      L("l6", "LEAD-0006", "Nisha Gupta", "nisha@greenchem.in", "9970167890", "Green Chem Labs", "Referral", "Qualified", "High", 275000, "u_s2", -5),
      L("l7", "LEAD-0007", "Rajesh Khanna", "rajesh@orissatransport.in", "9980178901", "Orissa Transport Co", "Cold Call", "Lost", "Low", 120000, "u_s1", -15),
      L("l8", "LEAD-0008", "Fatima Sheikh", "fatima@handloomhouse.in", "9990189012", "Handloom House", "Website", "Contacted", "Medium", 150000, "u_s2", -4),
      L("l9", "LEAD-0009", "Gopal Swain", "gopal@chilikalake.in", "9810190123", "Chilika Lake Resorts", "Trade Show", "New", "High", 500000, "u_s1", -3),
      L("l10", "LEAD-0010", "Anita Desai", "anita@silverline.in", "9820201234", "Silverline Jewels", "Referral", "Unqualified", "Low", 80000, "u_s2", -7),
      L("l11", "LEAD-0011", "Prakash Jha", "prakash@maithilifoods.in", "9830212345", "Maithili Foods", "Website", "Converted", "Medium", 200000, "u_s1", -25),
      L("l12", "LEAD-0012", "Sunita Patra", "sunita@konarktravels.in", "9840223456", "Konark Travels", "Cold Call", "Contacted", "Medium", 165000, "u_s2", -2)
    ];

    var O = function (id, name, cust, owner, stage, amt, prob, closeOff, off) {
      var st = (stage === "Won" || stage === "Lost") ? "Closed" : "Open";
      return { id: id, name: name, customerId: cust, ownerId: owner, stage: stage,
        amount: amt, probability: prob, expectedCloseDate: d(closeOff), source: "Referral",
        notes: "", status: st, createdAt: dt(off, 9, 30) };
    };
    var opportunities = [
      O("o1", "Meridian Fabrics — ERP Rollout", "c1", "u_s1", "Negotiation", 850000, 70, 25, -40),
      O("o2", "Kalinga Steel — CRM Licenses", "c2", "u_s1", "Proposal", 420000, 50, 40, -30),
      O("o3", "Odisha Agro — Support Contract", "c3", "u_s2", "Qualification", 150000, 30, 55, -20),
      O("o4", "Utkal Polymers — Service Deal", "c5", "u_s1", "Won", 600000, 100, -5, -50),
      O("o5", "Coastal Marine — Pilot Project", "c4", "u_s2", "Proposal", 275000, 45, 30, -15),
      O("o6", "Bhubaneswar IT — AMC Renewal", "c6", "u_s2", "Negotiation", 320000, 65, 18, -12),
      O("o7", "Eastern Mining — Equipment CRM", "c7", "u_s1", "Lost", 900000, 0, -10, -60),
      O("o8", "Cuttack Pharma — Distribution App", "c9", "u_s1", "Qualification", 510000, 25, 60, -8)
    ];

    var F = function (id, rt, rid, dateOff, subject, type, status, who, notes) {
      return { id: id, relatedType: rt, relatedId: rid, date: d(dateOff), subject: subject,
        type: type, status: status, assignedTo: who, notes: notes || "", createdAt: dt(-3, 14, 0) };
    };
    var followups = [
      F("f1", "lead", "l1", 1, "Demo call — Nova Textiles", "Call", "Planned", "u_s1"),
      F("f2", "lead", "l3", 0, "Send proposal — Berhampur Silk", "Email", "Planned", "u_s1"),
      F("f3", "customer", "c2", -2, "Quarterly review — Kalinga Steel", "Meeting", "Completed", "u_s1", "Discussed renewal."),
      F("f4", "opportunity", "o1", 2, "Negotiation follow-up", "Call", "Planned", "u_s1"),
      F("f5", "lead", "l6", -1, "Share pricing — Green Chem", "Email", "Missed", "u_s2"),
      F("f6", "customer", "c6", 3, "AMC discussion", "Meeting", "Planned", "u_s2"),
      F("f7", "opportunity", "o5", 5, "Pilot scope review", "Call", "Planned", "u_s2"),
      F("f8", "lead", "l9", 1, "Site visit — Chilika Resorts", "Meeting", "Planned", "u_s1"),
      F("f9", "customer", "c9", -4, "Onboarding call", "Call", "Completed", "u_s1", "Completed setup."),
      F("f10", "lead", "l2", 0, "Reschedule demo", "Call", "Cancelled", "u_s2", "Client asked to call next week.")
    ];

    var A = function (id, type, subject, dateOff, rt, rid, who, status) {
      return { id: id, type: type, subject: subject, description: "", date: d(dateOff),
        relatedType: rt, relatedId: rid, assignedTo: who, status: status || "Completed", createdAt: dt(-2, 12, 0) };
    };
    var activities = [
      A("a1", "Call", "Intro call — Nova Textiles", -11, "lead", "l1", "u_s1"),
      A("a2", "Email", "Proposal sent — Berhampur Silk", -6, "lead", "l3", "u_s1"),
      A("a3", "Meeting", "Quarterly business review", -2, "customer", "c2", "u_s1"),
      A("a4", "Call", "Pricing discussion — Green Chem", -3, "lead", "l6", "u_s2"),
      A("a5", "Task", "Prepare pilot SOW", -1, "opportunity", "o5", "u_s2", "Planned"),
      A("a6", "Meeting", "AMC renewal discussion", 3, "customer", "c6", "u_s2", "Planned"),
      A("a7", "Email", "Welcome kit — Cuttack Pharma", -9, "customer", "c9", "u_s1"),
      A("a8", "Call", "Lost-deal debrief — Eastern Mining", -9, "opportunity", "o7", "u_s1")
    ];

    return {
      v: 1,
      users: users,
      customers: customers,
      leads: leads,
      opportunities: opportunities,
      followups: followups,
      activities: activities,
      audit: [],
      seq: { customer: 11, lead: 13, opportunity: 9, followup: 11, activity: 9, user: 5 }
    };
  }

  function load() {
    try {
      var raw = localStorage.getItem(DB_KEY);
      if (raw) { var db = JSON.parse(raw); if (db && db.v === 1) return db; }
    } catch (e) { /* corrupted -> reseed */ }
    var db = seed();
    save(db);
    return db;
  }
  function save(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); }
  function reset() { localStorage.removeItem(DB_KEY); return load(); }

  var db = load();

  // ---------- scoped access ----------
  function me() { return CRM.auth.currentUser(); }
  function inScope(rec) {
    var u = me();
    if (!u) return false;
    if (u.role === "admin" || u.role === "manager") return true;
    return rec.ownerId === u.id || rec.assignedTo === u.id;
  }

  var api = {
    raw: function () { return db; },
    persist: function () { save(db); },
    reset: reset,
    all: function (col) { return db[col].slice(); },
    get: function (col, id) {
      for (var i = 0; i < db[col].length; i++) if (db[col][i].id === id) return db[col][i];
      return null;
    },
    scoped: function (col) {
      return db[col].filter(inScope);
    },
    nextCode: function (kind, prefix) {
      var n = db.seq[kind]++; save(db);
      return prefix + "-" + String(n).padStart(4, "0");
    },
    insert: function (col, rec) { db[col].push(rec); save(db); return rec; },
    update: function (col, id, patch) {
      var r = api.get(col, id); if (!r) return null;
      for (var k in patch) r[k] = patch[k];
      save(db); return r;
    },
    remove: function (col, id) {
      var i; for (i = 0; i < db[col].length; i++) if (db[col][i].id === id) break;
      if (i >= db[col].length) return false;
      db[col].splice(i, 1); save(db); return true;
    },
    findUserByEmail: function (email) {
      email = String(email).toLowerCase();
      for (var i = 0; i < db.users.length; i++)
        if (db.users[i].email.toLowerCase() === email) return db.users[i];
      return null;
    },
    userName: function (id) {
      var u = api.get("users", id); return u ? u.name : "—";
    }
  };

  CRM.store = api;
  CRM._hashPw = hashPw;
})();
