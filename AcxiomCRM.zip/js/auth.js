/* AcxiomCRM — authentication, sessions, lockout, password policy, permissions */
(function () {
  "use strict";
  var U = CRM.utils;
  // Session lives in memory only (not localStorage), so every fresh page
  // load starts at the login screen. CRM data itself still persists.
  var currentSession = null;
  var SESSION_HOURS = 8;
  var MAX_ATTEMPTS = 5;
  var LOCKOUT_MIN = 5;

  var POLICY = {
    minLength: 8,
    requireLetter: true,
    requireDigit: true,
    message: "Password must be at least 8 characters with at least one letter and one number."
  };

  function checkPasswordPolicy(pw) {
    var errs = [];
    if (!pw || pw.length < POLICY.minLength) errs.push("Password must be at least " + POLICY.minLength + " characters.");
    if (POLICY.requireLetter && !/[a-zA-Z]/.test(pw || "")) errs.push("Password must include at least one letter.");
    if (POLICY.requireDigit && !/[0-9]/.test(pw || "")) errs.push("Password must include at least one number.");
    return errs;
  }

  function getSession() {
    if (currentSession && currentSession.expires > Date.now()) return currentSession;
    currentSession = null;
    return null;
  }

  function currentUser() {
    var s = getSession();
    if (!s) return null;
    var u = CRM.store.get("users", s.userId);
    if (!u || !u.isActive) { logout(true); return null; }
    return u;
  }

  function login(email, password) {
    var user = CRM.store.findUserByEmail(email);
    var now = Date.now();
    if (user && user.lockoutUntil && user.lockoutUntil > now) {
      var mins = Math.ceil((user.lockoutUntil - now) / 60000);
      CRM.audit.log({ module: "Auth", action: "Login blocked (locked)", recordId: user.id, result: "Denied",
        details: "Account locked, " + mins + " min remaining" });
      return { ok: false, error: "Account is locked. Try again in " + mins + " minute(s)." };
    }
    var good = user && user.isActive && user.passwordHash === CRM._hashPw(user.salt, password || "");
    if (!good) {
      if (user) {
        user.failedAttempts = (user.failedAttempts || 0) + 1;
        if (user.failedAttempts >= MAX_ATTEMPTS) {
          user.lockoutUntil = now + LOCKOUT_MIN * 60000;
          CRM.audit.log({ module: "Auth", action: "Account locked", recordId: user.id, result: "Denied",
            details: MAX_ATTEMPTS + " failed attempts" });
        }
        CRM.store.persist();
      }
      CRM.audit.log({ module: "Auth", action: "Failed login", recordId: user ? user.id : null, result: "Denied",
        details: "Invalid credentials for " + email });
      var left = user ? Math.max(0, MAX_ATTEMPTS - user.failedAttempts) : 0;
      return { ok: false, error: "Invalid email or password." + (user && left > 0 ? " (" + left + " attempt(s) left)" : "") };
    }
    user.failedAttempts = 0; user.lockoutUntil = null;
    CRM.store.persist();
    var token = U.randHex(24);
    currentSession = { userId: user.id, token: token, expires: now + SESSION_HOURS * 3600000 };
    CRM.audit.log({ module: "Auth", action: "Login", recordId: user.id, result: "Success", details: user.email });
    return { ok: true, user: user, token: token };
  }

  function logout(silent) {
    var u = currentSession ? CRM.store.get("users", currentSession.userId) : null;
    currentSession = null;
    if (!silent && u) CRM.audit.log({ module: "Auth", action: "Logout", recordId: u.id, result: "Success", details: u.email });
  }

  function register(name, email, password) {
    var errs = {};
    if (!name || name.trim().length < 2) errs.name = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "")) errs.email = "Enter a valid email address.";
    var pwErrs = checkPasswordPolicy(password);
    if (pwErrs.length) errs.password = pwErrs[0];
    if (CRM.store.findUserByEmail(email || "")) errs.email = "This email is already registered.";
    if (Object.keys(errs).length) return { ok: false, errors: errs };
    var salt = U.randHex(16);
    var user = {
      id: U.uid("u"), name: name.trim(), email: email.trim(), salt: salt,
      passwordHash: CRM._hashPw(salt, password), role: "sales",
      isActive: true, failedAttempts: 0, lockoutUntil: null, createdAt: new Date().toISOString()
    };
    CRM.store.insert("users", user);
    CRM.audit.log({ module: "User", action: "Register", recordId: user.id, result: "Success", details: user.email + " (sales)" });
    return login(email, password);
  }

  // ---------- permissions ----------
  var ROLE_LABEL = { admin: "Admin", manager: "Manager", sales: "Sales Executive" };

  // module-level access: which roles may open which section
  var MODULE_ACCESS = {
    dashboard: ["admin", "manager", "sales"],
    customers: ["admin", "manager", "sales"],
    leads: ["admin", "manager", "sales"],
    opportunities: ["admin", "manager", "sales"],
    followups: ["admin", "manager", "sales"],
    activities: ["admin", "manager", "sales"],
    users: ["admin"],
    audit: ["admin", "manager"],
    reports: ["admin", "manager", "sales"],
    api: ["admin", "manager", "sales"]
  };

  function canAccess(module) {
    var u = currentUser();
    return !!(u && MODULE_ACCESS[module] && MODULE_ACCESS[module].indexOf(u.role) !== -1);
  }

  // record-level: sales users only touch their own/assigned records
  function canEditRecord(rec) {
    var u = currentUser();
    if (!u) return false;
    if (u.role === "admin" || u.role === "manager") return true;
    return rec.ownerId === u.id || rec.assignedTo === u.id;
  }
  function canDeleteRecord(rec) {
    var u = currentUser();
    if (!u) return false;
    if (u.role === "admin") return true;
    if (u.role === "manager") return true;
    return false; // sales executives cannot delete
  }

  CRM.auth = {
    login: login, logout: logout, register: register,
    currentUser: currentUser, getSession: getSession,
    checkPasswordPolicy: checkPasswordPolicy, POLICY: POLICY,
    canAccess: canAccess, canEditRecord: canEditRecord, canDeleteRecord: canDeleteRecord,
    roleLabel: function (r) { return ROLE_LABEL[r] || r; },
    MAX_ATTEMPTS: MAX_ATTEMPTS, LOCKOUT_MIN: LOCKOUT_MIN
  };
})();
