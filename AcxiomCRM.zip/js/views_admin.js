/* AcxiomCRM — admin views: users, audit log, reports, API explorer */
(function () {
  "use strict";
  var U = CRM.utils;

  /* ==================== USERS & ROLES ==================== */
  CRM.ui.route("users", function (view) {
    var me = CRM.auth.currentUser();
    view.innerHTML = '<div class="page-h"><div><h2>Users & Roles</h2><p>Control who can do what.</p></div>' +
      '<button class="btn btn-primary" id="u-add">+ New User</button></div>' +
      '<div class="card" style="margin-bottom:16px"><div class="panel-h"><h3>Role Permissions</h3></div>' +
      '<div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr><th>Module</th><th>Admin</th><th>Manager</th><th>Sales Executive</th></tr></thead><tbody>' +
      [["Dashboard", "Full", "Team", "Own / Assigned"],
       ["Customers / Leads / Follow-Ups / Opportunities", "Full", "Team", "Own / Assigned"],
       ["User Management", "Full", "—", "—"],
       ["Audit Log", "Full", "View", "—"],
       ["Reports", "All", "Team", "Own / Assigned"],
       ["Delete records", "Yes", "Yes", "No"]].map(function (r) {
        return "<tr><td><b>" + r[0] + "</b></td>" + r.slice(1).map(function (c) {
          return "<td>" + (c === "—" ? '<span class="pill p-gray">No</span>' : c === "Full" || c === "Yes" || c === "All" || c === "View" ? '<span class="pill p-green">' + c + "</span>" : '<span class="pill p-blue">' + c + "</span>") + "</td>";
        }).join("") + "</tr>";
      }).join("") + "</tbody></table></div></div><div id='u-list'></div>";

    function formHTML(u) {
      u = u || {};
      return '<div class="f-grid">' +
        CRM.ui.F.text("name", "Full Name", { req: true, value: u.name, max: 80 }) +
        CRM.ui.F.email("email", "Email", { req: true, value: u.email, max: 120 }) +
        CRM.ui.F.select("role", "Role", { req: true, value: u.role || "sales",
          options: [{ v: "admin", t: "Admin" }, { v: "manager", t: "Manager" }, { v: "sales", t: "Sales Executive" }] }) +
        (u.id ? CRM.ui.F.select("isActive", "Account Status", { value: u.isActive ? "1" : "0",
          options: [{ v: "1", t: "Active" }, { v: "0", t: "Deactivated" }] })
        : CRM.ui.F.password("password", "Password", { req: true, hint: "Min 8 chars, letter + number." })) +
        "</div>";
    }
    function saveUser(form, existing, done) {
      var v = CRM.ui.collectForm(form);
      var errs = CRM.validators.validateUser(Object.assign({}, existing, v), !existing);
      if (Object.keys(errs).length) { CRM.ui.showErrors(form, errs); done(); return false; }
      if (existing) {
        if (existing.id === me.id && v.role !== "admin") {
          CRM.ui.showErrors(form, { role: "You cannot demote your own account." }); done(); return false;
        }
        CRM.store.update("users", existing.id, { name: v.name, email: v.email, role: v.role, isActive: v.isActive === "1" });
        CRM.audit.log({ module: "User", action: existing.role !== v.role ? "Role Change" : "Update",
          recordId: existing.id, result: "Success", details: v.email + " → " + v.role });
        CRM.ui.toast("User updated.", "ok");
      } else {
        var salt = U.randHex(16);
        var rec = { id: U.uid("u"), name: v.name, email: v.email, salt: salt,
          passwordHash: CRM._hashPw(salt, v.password), role: v.role,
          isActive: true, failedAttempts: 0, lockoutUntil: null, createdAt: new Date().toISOString() };
        CRM.store.insert("users", rec);
        CRM.audit.log({ module: "User", action: "Create", recordId: rec.id, result: "Success", details: v.email + " (" + v.role + ")" });
        CRM.ui.toast("User created.", "ok");
      }
      table.refresh();
    }

    var table = CRM.ui.dataView(view.querySelector("#u-list"), {
      getRows: function () { return CRM.store.all("users"); },
      searchKeys: ["name", "email", "role"],
      searchPlaceholder: "Search users…",
      columns: [
        { key: "name", label: "User", render: function (r) {
          return '<div style="display:flex;align-items:center;gap:10px"><div class="avatar" style="width:32px;height:32px;font-size:12px">' +
            CRM.ui.initials(r.name) + "</div><b>" + U.esc(r.name) + "</b></div>"; } },
        { key: "email", label: "Email", render: function (r) { return U.esc(r.email); }, sort: false },
        { key: "role", label: "Role", render: function (r) {
          return CRM.ui.pill(CRM.auth.roleLabel(r.role), r.role === "admin" ? "p-violet" : r.role === "manager" ? "p-blue" : "p-teal"); } },
        { key: "isActive", label: "Status", render: function (r) {
          var locked = r.lockoutUntil && r.lockoutUntil > Date.now();
          return locked ? CRM.ui.pill("Locked", "p-red") : (r.isActive ? CRM.ui.pill("Active", "p-green") : CRM.ui.pill("Deactivated", "p-gray")); } },
        { key: "createdAt", label: "Created", render: function (r) { return U.fmtDate(r.createdAt); } }
      ],
      actions: function (r) {
        var h = '<button class="icon-btn" data-act="edit" title="Edit">✎</button>';
        if (r.id !== me.id) {
          if (r.lockoutUntil && r.lockoutUntil > Date.now())
            h += '<button class="btn btn-sm" data-act="unlock" style="margin-left:6px">Unlock</button>';
          h += '<button class="btn btn-sm" data-act="resetpw" style="margin-left:6px">Reset PW</button>';
        }
        return h;
      },
      onAction: function (act, id) {
        var r = CRM.store.get("users", id);
        if (act === "edit") {
          CRM.ui.openModal({ title: "Edit User", bodyHTML: formHTML(r),
            onOk: function (f, done) { return saveUser(f, r, done); } });
        } else if (act === "unlock") {
          CRM.store.update("users", id, { lockoutUntil: null, failedAttempts: 0 });
          CRM.audit.log({ module: "User", action: "Unlock", recordId: id, result: "Success", details: r.email });
          CRM.ui.toast("Account unlocked.", "ok"); table.refresh();
        } else if (act === "resetpw") {
          var np = "Temp@" + U.randHex(4);
          var salt = U.randHex(16);
          CRM.store.update("users", id, { salt: salt, passwordHash: CRM._hashPw(salt, np), failedAttempts: 0, lockoutUntil: null });
          CRM.audit.log({ module: "User", action: "Password Reset", recordId: id, result: "Success", details: r.email });
          CRM.ui.openModal({ title: "Temporary Password", okLabel: "Done",
            bodyHTML: "<p>Share this with <b>" + U.esc(r.name) + "</b> securely. They should change it after login.</p>" +
              '<div class="code-box">Temporary password: <span class="s">' + U.esc(np) + "</span></div>",
            onOk: function () {} });
        }
      }
    });
    view.querySelector("#u-add").onclick = function () {
      CRM.ui.openModal({ title: "New User", bodyHTML: formHTML(null),
        onOk: function (f, done) { return saveUser(f, null, done); } });
    };
  });

  /* ==================== AUDIT LOG ==================== */
  CRM.ui.route("audit", function (view) {
    view.innerHTML = '<div class="page-h"><div><h2>Audit Log</h2><p>Append-only trail of security & business events.</p></div>' +
      '<button class="btn" id="a-export">⬇ Export CSV</button></div>' +
      '<div class="toolbar"><div class="seg" id="a-modseg"><button data-m="" class="on">All</button>' +
      ["Auth", "Customer", "Lead", "Opportunity", "FollowUp", "User"].map(function (m) {
        return '<button data-m="' + m + '">' + m + "</button>";
      }).join("") + "</div></div><div id='a-list'></div>";

    var modFilter = "";
    var table;
    function mount() {
      table = CRM.ui.dataView(view.querySelector("#a-list"), {
        getRows: function () {
          var all = CRM.store.all("audit").slice().reverse();
          return modFilter ? all.filter(function (a) { return a.module === modFilter; }) : all;
        },
        searchKeys: ["userName", "action", "details", "module"],
        searchPlaceholder: "Search audit trail…",
        columns: [
          { key: "timestamp", label: "Time", render: function (r) { return U.fmtDateTime(r.timestamp); } },
          { key: "userName", label: "User", render: function (r) { return U.esc(r.userName); } },
          { key: "module", label: "Module", render: function (r) { return CRM.ui.pill(r.module, "p-gray"); } },
          { key: "action", label: "Action", render: function (r) { return U.esc(r.action); } },
          { key: "recordId", label: "Record", sort: false, render: function (r) {
            return r.recordId ? '<span style="font-family:monospace;font-size:12px">' + U.esc(String(r.recordId).slice(0, 18)) + "</span>" : "—"; } },
          { key: "result", label: "Result", render: function (r) {
            return CRM.ui.pill(r.result, r.result === "Success" ? "p-green" : "p-red"); } },
          { key: "details", label: "Details", sort: false, render: function (r) { return U.esc(r.details || "—"); } }
        ],
        hideSearch: false
      });
    }
    mount();
    view.querySelectorAll("#a-modseg button").forEach(function (b) {
      b.onclick = function () {
        view.querySelectorAll("#a-modseg button").forEach(function (x) { x.classList.remove("on"); });
        b.classList.add("on"); modFilter = b.getAttribute("data-m"); mount();
      };
    });
    view.querySelector("#a-export").onclick = function () {
      var rows = [["Time", "User", "Module", "Action", "Record", "Result", "Details"]];
      CRM.store.all("audit").forEach(function (a) {
        rows.push([a.timestamp, a.userName, a.module, a.action, a.recordId || "", a.result, a.details || ""]);
      });
      U.download("audit-log.csv", U.toCSV(rows), "text/csv");
      CRM.ui.toast("Audit log exported.", "ok");
    };
  });

  /* ==================== REPORTS ==================== */
  CRM.ui.route("reports", function (view) {
    var TABS = [
      { id: "customers", t: "Customers" }, { id: "leads", t: "Leads" },
      { id: "followups", t: "Follow-Ups" }, { id: "opportunities", t: "Opportunities" },
      { id: "pipeline", t: "Pipeline" }, { id: "conversion", t: "Conversion" },
      { id: "activity", t: "User Activity" }
    ];
    if (CRM.auth.currentUser().role === "sales") TABS.splice(6, 1); // sales: no user activity report
    view.innerHTML = '<div class="page-h"><div><h2>Reports</h2><p>Filter, inspect and export.</p></div>' +
      '<button class="btn btn-primary" id="r-export">⬇ Export CSV</button></div>' +
      '<div class="tabs" id="r-tabs">' + TABS.map(function (t, i) {
        return '<button data-t="' + t.id + '"' + (i === 0 ? ' class="on"' : "") + ">" + t.t + "</button>";
      }).join("") + "</div><div id='r-body'></div>";

    var cur = "customers", lastRows = [], lastHead = [];
    function setTab(id) {
      cur = id;
      view.querySelectorAll("#r-tabs button").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-t") === id); });
      render();
    }
    function render() {
      var body = view.querySelector("#r-body");
      var rows = [], head = [];
      if (cur === "customers") {
        head = ["Code", "Name", "Company", "Email", "Phone", "Status", "Owner", "Created"];
        rows = CRM.store.scoped("customers").map(function (c) {
          return [c.code, c.name, c.company, c.email, c.phone, c.status, CRM.store.userName(c.ownerId), U.fmtDate(c.createdAt)]; });
      } else if (cur === "leads") {
        head = ["Code", "Name", "Company", "Source", "Status", "Priority", "Exp. Value", "Assigned", "Created"];
        rows = CRM.store.scoped("leads").map(function (l) {
          return [l.code, l.name, l.company, l.source, l.status, l.priority, l.expectedValue, CRM.store.userName(l.assignedTo), U.fmtDate(l.createdAt)]; });
      } else if (cur === "followups") {
        head = ["Date", "Subject", "Type", "Status", "Related", "Assigned"];
        rows = CRM.store.scoped("followups").map(function (f) {
          var rel = CRM.store.get(f.relatedType + "s", f.relatedId);
          return [f.date, f.subject, f.type, f.status, rel ? (rel.code || rel.name) : "—", CRM.store.userName(f.assignedTo)]; });
      } else if (cur === "opportunities") {
        head = ["Opportunity", "Customer", "Stage", "Amount", "Probability", "Weighted", "Close Date", "Owner"];
        rows = CRM.store.scoped("opportunities").map(function (o) {
          var c = CRM.store.get("customers", o.customerId);
          return [o.name, c ? c.company : "—", o.stage, o.amount, o.probability + "%",
            Math.round(o.amount * o.probability / 100), o.expectedCloseDate, CRM.store.userName(o.ownerId)]; });
      } else if (cur === "pipeline") {
        head = ["Stage", "Count", "Amount", "Weighted"];
        rows = CRM.validators.OPP_STAGES.map(function (st) {
          var items = CRM.store.scoped("opportunities").filter(function (o) { return o.stage === st; });
          var amt = items.reduce(function (s, o) { return s + o.amount; }, 0);
          var w = items.reduce(function (s, o) { return s + o.amount * o.probability / 100; }, 0);
          return [st, items.length, amt, Math.round(w)]; });
      } else if (cur === "conversion") {
        head = ["Metric", "Value"];
        var leads = CRM.store.scoped("leads");
        var conv = leads.filter(function (l) { return l.status === "Converted"; }).length;
        var opps = CRM.store.scoped("opportunities");
        rows = [
          ["Total leads", leads.length], ["Converted leads", conv],
          ["Lead conversion rate", leads.length ? Math.round(conv / leads.length * 100) + "%" : "—"],
          ["Opportunities won", opps.filter(function (o) { return o.stage === "Won"; }).length],
          ["Opportunities lost", opps.filter(function (o) { return o.stage === "Lost"; }).length],
          ["Win rate", opps.length ? Math.round(opps.filter(function (o) { return o.stage === "Won"; }).length / opps.length * 100) + "%" : "—"]
        ];
      } else if (cur === "activity") {
        head = ["User", "Role", "Actions Logged"];
        var counts = {};
        CRM.store.all("audit").forEach(function (a) { counts[a.userName] = (counts[a.userName] || 0) + 1; });
        rows = Object.keys(counts).map(function (n) {
          var u = CRM.store.all("users").find(function (x) { return x.name === n; });
          return [n, u ? CRM.auth.roleLabel(u.role) : "—", counts[n]]; })
          .sort(function (a, b) { return b[2] - a[2]; });
      }
      lastRows = rows; lastHead = head;
      body.innerHTML = '<div class="tbl-wrap"><table class="tbl"><thead><tr>' +
        head.map(function (h) { return "<th>" + U.esc(h) + "</th>"; }).join("") +
        "</tr></thead><tbody>" + (rows.length ? rows.map(function (r) {
          return "<tr>" + r.map(function (c) { return "<td>" + U.esc(c) + "</td>"; }).join("") + "</tr>";
        }).join("") : '<tr class="empty-row"><td colspan="' + head.length + '">No data.</td></tr>') +
        "</tbody></table></div><div class='pager'><span>" + rows.length + " row(s)</span></div>";
    }
    view.querySelectorAll("#r-tabs button").forEach(function (b) {
      b.onclick = function () { setTab(b.getAttribute("data-t")); };
    });
    view.querySelector("#r-export").onclick = function () {
      U.download("report-" + cur + ".csv", U.toCSV([lastHead].concat(lastRows)), "text/csv");
      CRM.ui.toast("Report exported.", "ok");
    };
    render();
  });

  /* ==================== API EXPLORER ==================== */
  CRM.ui.route("api", function (view) {
    var token = (CRM.auth.getSession() || {}).token || "";
    view.innerHTML = '<div class="page-h"><div><h2>API Explorer</h2><p>Exercise the documented REST contract against live data.</p></div></div>' +
      '<div class="card" style="margin-bottom:16px"><div class="panel-h"><h3>Your bearer token</h3>' +
      '<button class="btn btn-sm" id="api-copy">Copy</button></div>' +
      '<div class="code-box">Authorization: Bearer <span class="s">' + U.esc(token) + "</span></div>" +
      '<p class="hint">Every protected endpoint below requires this header. Remove it to see a <b>401</b>.</p></div>' +
      '<div class="card"><div class="panel-h"><h3>Try an endpoint</h3></div>' +
      '<div class="f-grid">' +
      '<div class="f-group" data-f="m"><label>Method</label><select class="inp" id="api-method">' +
      ["GET", "POST", "PUT", "DELETE"].map(function (m) { return "<option>" + m + "</option>"; }).join("") + "</select></div>" +
      '<div class="f-group" data-f="p"><label>Endpoint</label><select class="inp" id="api-path">' +
      CRM.api.DOCS.map(function (d, i) { return '<option value="' + i + '">' + d.method + " " + d.path + "</option>"; }).join("") +
      '</select><div class="hint" id="api-desc"></div></div>' +
      '<div class="f-group f-full" data-f="b"><label>Request body (JSON, for POST/PUT)</label>' +
      '<textarea class="inp" id="api-body" rows="4" placeholder=\'{ "name": "Acme Corp", ... }\'>{\n  "name": "Demo Customer",\n  "email": "demo@acme.in",\n  "phone": "9876543210",\n  "company": "Acme Corp"\n}</textarea></div>' +
      '<div class="f-group" data-f="t"><label>Send token?</label><select class="inp" id="api-token"><option value="1">Yes — authorized</option><option value="0">No — expect 401</option></select></div>' +
      "</div>" +
      '<div style="margin-top:14px"><button class="btn btn-primary" id="api-send">▶ Send Request</button></div>' +
      '<div class="panel-h" style="margin-top:18px"><h3>Response</h3><span id="api-status"></span></div>' +
      '<div class="code-box" id="api-resp" style="min-height:120px">// press Send Request</div></div>' +
      '<div class="card" style="margin-top:16px"><div class="panel-h"><h3>Endpoint reference</h3></div>' +
      '<div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr><th>Method</th><th>Endpoint</th><th>Purpose</th><th>Access</th></tr></thead><tbody>' +
      CRM.api.DOCS.map(function (d) {
        return "<tr><td><b>" + d.method + "</b></td><td style='font-family:monospace'>" + d.path + "</td><td>" + d.desc + "</td><td>" + d.access + "</td></tr>";
      }).join("") + "</tbody></table></div></div>";

    function syncDoc() {
      var d = CRM.api.DOCS[+view.querySelector("#api-path").value];
      view.querySelector("#api-method").value = d.method;
      view.querySelector("#api-desc").textContent = d.desc + " — " + d.access;
    }
    view.querySelector("#api-path").onchange = syncDoc; syncDoc();
    view.querySelector("#api-copy").onclick = function () {
      if (navigator.clipboard) navigator.clipboard.writeText("Bearer " + token);
      CRM.ui.toast("Token copied.", "ok");
    };
    view.querySelector("#api-send").onclick = function () {
      var method = view.querySelector("#api-method").value;
      var doc = CRM.api.DOCS[+view.querySelector("#api-path").value];
      var path = doc.path.replace("{id}", promptId(doc.path));
      var body = null;
      if (method === "POST" || method === "PUT") {
        try { body = JSON.parse(view.querySelector("#api-body").value || "{}"); }
        catch (e) { CRM.ui.toast("Request body is not valid JSON.", "err"); return; }
      }
      var headers = view.querySelector("#api-token").value === "1" ? { Authorization: "Bearer " + token } : {};
      var t0 = performance.now();
      var res = CRM.api.handle(method, path, body, headers);
      var ms = Math.round(performance.now() - t0);
      var st = view.querySelector("#api-status");
      st.innerHTML = '<span class="pill ' + (res.status < 300 ? "p-green" : res.status < 500 ? "p-amber" : "p-red") + '">HTTP ' + res.status + "</span> · " + ms + " ms";
      view.querySelector("#api-resp").textContent = JSON.stringify(res.body, null, 2);
      CRM.audit.log({ module: "API", action: method + " " + path, recordId: null,
        result: res.status < 300 ? "Success" : "Denied", details: "HTTP " + res.status });
    };
    function promptId(path) {
      if (path.indexOf("{id}") === -1) return path;
      var col = path.indexOf("customers") !== -1 ? "customers" : path.indexOf("leads") !== -1 ? "leads" : "opportunities";
      var list = CRM.store.scoped(col);
      if (!list.length) return path.replace("{id}", "missing");
      return path.replace("{id}", list[0].id);
    }
  });
})();
