/* AcxiomCRM — dashboard view */
(function () {
  "use strict";
  var U = CRM.utils;

  var charts = [];
  function destroyCharts() { charts.forEach(function (c) { try { c.destroy(); } catch (e) {} }); charts = []; }

  function countUp(el, target, money) {
    var start = 0, dur = 900, t0 = performance.now();
    function tick(t) {
      var p = Math.min(1, (t - t0) / dur);
      var e = 1 - Math.pow(1 - p, 3);
      var v = Math.round(start + (target - start) * e);
      el.textContent = money ? U.fmtMoney(v) : v.toLocaleString("en-IN");
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  function kpi(icon, label, value, money, bg, fg) {
    return '<div class="card hoverable kpi"><div class="k-ico" style="background:' + bg + ";color:" + fg + '">' + icon + "</div>" +
      '<div><div class="k-val" data-count="' + value + '" data-money="' + (money ? 1 : 0) + '">0</div>' +
      '<div class="k-lbl">' + label + "</div></div></div>";
  }

  CRM.ui.route("dashboard", function (view) {
    destroyCharts();
    var me = CRM.auth.currentUser();
    var customers = CRM.store.scoped("customers");
    var leads = CRM.store.scoped("leads");
    var opps = CRM.store.scoped("opportunities");
    var fus = CRM.store.scoped("followups").filter(function (f) { return f.assignedTo === me.id || me.role !== "sales"; });

    var openLeads = leads.filter(function (l) { return ["New", "Contacted", "Qualified"].indexOf(l.status) !== -1; }).length;
    var openOpps = opps.filter(function (o) { return o.stage !== "Won" && o.stage !== "Lost"; });
    var won = opps.filter(function (o) { return o.stage === "Won"; }).length;
    var lost = opps.filter(function (o) { return o.stage === "Lost"; }).length;
    var pipeline = openOpps.reduce(function (s, o) { return s + o.amount; }, 0);
    var today = U.todayISO();
    var overdue = fus.filter(function (f) { return f.status === "Planned" && f.date < today; }).length;
    var dueToday = fus.filter(function (f) { return f.status === "Planned" && f.date === today; }).length;

    view.innerHTML =
      '<div class="page-h"><div><h2>Namaste, ' + U.esc(me.name.split(" ")[0]) + ' 👋</h2>' +
      "<p>Here's what's happening in your sales world today.</p></div>" +
      '<div class="seg" id="dash-range"><button data-r="today">Today</button><button data-r="week" class="on">This week</button><button data-r="month">Month</button></div></div>' +
      '<div class="grid kpis">' +
      kpi("👥", "Total Customers", customers.length, false, "var(--blue-soft)", "var(--blue)") +
      kpi("🎯", "Open Leads", openLeads, false, "var(--violet-soft)", "var(--violet)") +
      kpi("💼", "Open Opportunities", openOpps.length, false, "var(--amber-soft)", "var(--amber)") +
      kpi("💰", "Pipeline Value", pipeline, true, "var(--green-soft)", "var(--green)") +
      kpi("🏆", "Won", won, false, "var(--teal-soft)", "var(--teal)") +
      kpi("⚠", "Overdue Follow-Ups", overdue, false, "var(--red-soft)", "var(--red)") +
      "</div>" +
      '<div class="grid charts">' +
      '<div class="card"><div class="panel-h"><h3>Leads by Status</h3></div><div class="chart-box"><canvas id="ch-leads"></canvas></div></div>' +
      '<div class="card"><div class="panel-h"><h3>Opportunity Pipeline</h3></div><div class="chart-box"><canvas id="ch-pipe"></canvas></div></div>' +
      "</div>" +
      '<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr));margin-top:16px">' +
      '<div class="card"><div class="panel-h"><h3>Upcoming Follow-Ups</h3><a href="#/followups" class="btn btn-sm">View all</a></div><div id="dash-fu"></div></div>' +
      '<div class="card"><div class="panel-h"><h3>Recent Activity</h3><a href="#/audit" class="btn btn-sm">Audit log</a></div><div id="dash-audit"></div></div>' +
      "</div>";

    view.querySelectorAll("[data-count]").forEach(function (el) {
      countUp(el, +el.getAttribute("data-count"), el.getAttribute("data-money") === "1");
    });

    // --- charts ---
    var leadCounts = {}, leadLabels = CRM.validators.LEAD_STATUSES;
    leadLabels.forEach(function (s) { leadCounts[s] = 0; });
    leads.forEach(function (l) { leadCounts[l.status] = (leadCounts[l.status] || 0) + 1; });
    charts.push(new Chart(view.querySelector("#ch-leads"), {
      type: "doughnut",
      data: { labels: leadLabels, datasets: [{ data: leadLabels.map(function (s) { return leadCounts[s]; }),
        backgroundColor: ["#2563eb", "#0d9488", "#7c3aed", "#94a3b8", "#16a34a", "#dc2626"],
        borderWidth: 3, borderColor: "#fff", hoverOffset: 8 }] },
      options: { maintainAspectRatio: false, cutout: "62%",
        plugins: { legend: { position: "right", labels: { boxWidth: 12, padding: 12 } } },
        animation: { animateRotate: true, duration: 900 } }
    }));

    var stages = CRM.validators.OPP_STAGES;
    var stageSums = stages.map(function (st) {
      return opps.filter(function (o) { return o.stage === st; }).reduce(function (s, o) { return s + o.amount; }, 0);
    });
    charts.push(new Chart(view.querySelector("#ch-pipe"), {
      type: "bar",
      data: { labels: stages, datasets: [{ label: "Amount (₹)",
        data: stageSums, backgroundColor: ["#93b4fd", "#c4b5fd", "#fcd34d", "#6ee7b7", "#fca5a5"],
        borderRadius: 8, barThickness: 34 }] },
      options: { maintainAspectRatio: false,
        plugins: { legend: { display: false },
          tooltip: { callbacks: { label: function (c) { return " " + U.fmtMoney(c.parsed.y); } } } },
        scales: { y: { ticks: { callback: function (v) { return "₹" + (v >= 100000 ? (v / 100000) + "L" : v); } },
          grid: { color: "#eef1f6" } }, x: { grid: { display: false } } },
        animation: { duration: 900, easing: "easeOutQuart" } }
    }));

    // --- upcoming follow-ups ---
    var upcoming = fus.filter(function (f) { return f.status === "Planned" && f.date >= today; })
      .sort(function (a, b) { return a.date < b.date ? -1 : 1; }).slice(0, 5);
    view.querySelector("#dash-fu").innerHTML = upcoming.length ? '<div class="timeline">' + upcoming.map(function (f) {
      return '<div class="t-item"><span class="t-dot"></span><div><b>' + U.esc(f.subject) + "</b></div>" +
        '<div class="t-sub">' + U.fmtDate(f.date) + " · " + U.esc(f.type) + " · " + U.esc(CRM.store.userName(f.assignedTo)) + "</div></div>";
    }).join("") + "</div>" :
      '<p style="color:var(--muted)">All caught up — no planned follow-ups. 🎉</p>';

    // --- recent audit ---
    var recent = CRM.store.all("audit").slice(-6).reverse();
    view.querySelector("#dash-audit").innerHTML = recent.length ? '<div class="timeline">' + recent.map(function (a) {
      return '<div class="t-item"><span class="t-dot"></span><div style="font-size:13px"><b>' + U.esc(a.userName) + "</b> " +
        U.esc(a.action) + ' <span style="color:var(--muted)">' + U.esc(a.module) + "</span></div>" +
        '<div class="t-sub">' + U.fmtDateTime(a.timestamp) + "</div></div>";
    }).join("") + "</div>" : '<p style="color:var(--muted)">No activity yet.</p>';

    // range segmented control (decorative scope filter for follow-ups)
    view.querySelectorAll("#dash-range button").forEach(function (b) {
      b.onclick = function () {
        view.querySelectorAll("#dash-range button").forEach(function (x) { x.classList.remove("on"); });
        b.classList.add("on");
        CRM.ui.toast("Range: " + b.textContent + " — KPIs refresh on next visit.", "info");
      };
    });
  });
})();
