/* AcxiomCRM — validation: client-side rules + server-side enforcement + business rules */
(function () {
  "use strict";
  var U = CRM.utils;

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var PHONE_RE = /^[6-9]\d{9}$/; // 10-digit Indian mobile

  function req(v) { return v != null && String(v).trim() !== ""; }

  // Each rule returns an errors object: {field: message}
  var V = {
    email: function (v) { return EMAIL_RE.test(String(v || "").trim()) ? null : "Enter a valid email address."; },
    phone: function (v) {
      var s = String(v || "").replace(/[\s\-+]/g, "");
      if (/^91\d{10}$/.test(s)) s = s.slice(2);
      return PHONE_RE.test(s) ? null : "Enter a valid 10-digit mobile number.";
    },
    normPhone: function (v) {
      var s = String(v || "").replace(/[\s\-+]/g, "");
      if (/^91\d{10}$/.test(s)) s = s.slice(2);
      return s;
    }
  };

  function checkCommon(obj, spec, errors) {
    // spec: {field: {required, maxLen, email, phone}}
    Object.keys(spec).forEach(function (f) {
      var r = spec[f], v = obj[f];
      if (r.required && !req(v)) { errors[f] = r.label + " is required."; return; }
      if (!req(v)) return;
      if (r.maxLen && String(v).length > r.maxLen) errors[f] = r.label + " must be under " + r.maxLen + " characters.";
      if (r.email) { var e = V.email(v); if (e) errors[f] = e; }
      if (r.phone) { var p = V.phone(v); if (p) errors[f] = p; }
    });
    return errors;
  }

  var LEAD_STATUSES = ["New", "Contacted", "Qualified", "Unqualified", "Converted", "Lost"];
  var LEAD_TRANSITIONS = {
    "New": ["Contacted", "Qualified", "Unqualified", "Lost"],
    "Contacted": ["Qualified", "Unqualified", "Lost", "Converted"],
    "Qualified": ["Converted", "Lost", "Contacted"],
    "Unqualified": ["Lost"],
    "Converted": [],
    "Lost": []
  };
  var OPP_STAGES = ["Qualification", "Proposal", "Negotiation", "Won", "Lost"];

  function validateCustomer(c, isUpdate) {
    var errors = {};
    checkCommon(c, {
      name: { required: true, maxLen: 80, label: "Customer name" },
      email: { required: true, email: true, maxLen: 120, label: "Email" },
      phone: { required: true, phone: true, label: "Phone" },
      company: { required: true, maxLen: 120, label: "Company" },
      city: { maxLen: 60, label: "City" },
      address: { maxLen: 250, label: "Address" }
    }, errors);
    // uniqueness (server-side business rule)
    var all = CRM.store.all("customers");
    var dupE = all.find(function (x) { return x.email.toLowerCase() === String(c.email || "").toLowerCase() && x.id !== c.id; });
    if (dupE) errors.email = "This email is already used by " + dupE.code + ".";
    var dupP = all.find(function (x) { return V.normPhone(x.phone) === V.normPhone(c.phone) && x.id !== c.id; });
    if (dupP) errors.phone = "This phone number is already used by " + dupP.code + ".";
    return errors;
  }

  function validateLead(l) {
    var errors = {};
    checkCommon(l, {
      name: { required: true, maxLen: 80, label: "Lead name" },
      email: { email: true, maxLen: 120, label: "Email" },
      phone: { phone: true, label: "Phone" },
      company: { maxLen: 120, label: "Company" }
    }, errors);
    if (!req(l.status) || LEAD_STATUSES.indexOf(l.status) === -1) errors.status = "Select a valid lead status.";
    if (l.expectedValue != null && l.expectedValue !== "") {
      var n = Number(l.expectedValue);
      if (isNaN(n) || n < 0 || n > 100000000) errors.expectedValue = "Expected value must be between 0 and 10,00,00,000.";
    }
    return errors;
  }

  function validateLeadTransition(from, to) {
    if (from === to) return null;
    var allowed = LEAD_TRANSITIONS[from] || [];
    if (allowed.indexOf(to) === -1)
      return "Status cannot move from " + from + " to " + to + ".";
    return null;
  }

  function validateOpportunity(o) {
    var errors = {};
    checkCommon(o, {
      name: { required: true, maxLen: 120, label: "Opportunity name" },
      customerId: { required: true, label: "Customer" }
    }, errors);
    var amt = Number(o.amount);
    if (o.amount == null || o.amount === "" || isNaN(amt)) errors.amount = "Amount is required.";
    else if (amt <= 0) errors.amount = "Opportunity Amount must be greater than 0.";
    else if (amt > 1000000000) errors.amount = "Amount looks unrealistically large.";
    var prob = Number(o.probability);
    if (o.probability == null || o.probability === "" || isNaN(prob)) errors.probability = "Probability is required.";
    else if (prob < 0 || prob > 100) errors.probability = "Probability must be between 0 and 100.";
    if (OPP_STAGES.indexOf(o.stage) === -1) errors.stage = "Select a valid stage.";
    var active = o.stage !== "Won" && o.stage !== "Lost";
    if (!req(o.expectedCloseDate)) errors.expectedCloseDate = "Expected Close Date is required.";
    else if (active && o.expectedCloseDate < U.todayISO())
      errors.expectedCloseDate = "Expected Close Date cannot be in the past.";
    return errors;
  }

  function validateFollowup(f) {
    var errors = {};
    checkCommon(f, {
      subject: { required: true, maxLen: 140, label: "Subject" },
      date: { required: true, label: "Follow-up date" }
    }, errors);
    if (!f.relatedId) errors.related = "Link the follow-up to a customer, lead or opportunity.";
    var historical = f.status === "Completed" || f.status === "Missed";
    if (req(f.date) && !historical && f.date < U.todayISO())
      errors.date = "Follow-up date cannot be earlier than today.";
    if (["Planned", "Completed", "Missed", "Cancelled"].indexOf(f.status) === -1) errors.status = "Select a valid status.";
    return errors;
  }

  function validateActivity(a) {
    var errors = {};
    checkCommon(a, {
      subject: { required: true, maxLen: 140, label: "Subject" },
      date: { required: true, label: "Activity date" }
    }, errors);
    if (["Call", "Meeting", "Email", "Task"].indexOf(a.type) === -1) errors.type = "Select a valid activity type.";
    return errors;
  }

  function validateUser(u, isNew) {
    var errors = {};
    checkCommon(u, {
      name: { required: true, maxLen: 80, label: "Name" },
      email: { required: true, email: true, maxLen: 120, label: "Email" }
    }, errors);
    if (["admin", "manager", "sales"].indexOf(u.role) === -1) errors.role = "Select a valid role.";
    if (isNew) {
      var pw = CRM.auth.checkPasswordPolicy(u.password);
      if (pw.length) errors.password = pw[0];
      if (CRM.store.findUserByEmail(u.email || "")) errors.email = "This email is already registered.";
    }
    return errors;
  }

  CRM.validators = {
    checkCommon: checkCommon, email: V.email, phone: V.phone, normPhone: V.normPhone,
    validateCustomer: validateCustomer, validateLead: validateLead,
    validateLeadTransition: validateLeadTransition, validateOpportunity: validateOpportunity,
    validateFollowup: validateFollowup, validateActivity: validateActivity,
    validateUser: validateUser,
    LEAD_STATUSES: LEAD_STATUSES, LEAD_TRANSITIONS: LEAD_TRANSITIONS, OPP_STAGES: OPP_STAGES
  };
})();
