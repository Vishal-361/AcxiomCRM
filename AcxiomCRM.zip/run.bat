@echo off
REM AcxiomCRM one-command start (Windows). Requires .NET 8 SDK.
cd /d "%~dp0src\AcxiomCRM"
echo Starting AcxiomCRM...
dotnet run
