#!/usr/bin/env python3
"""Reset a demo user's password in the local AcxiomCRM SQLite dev database.

Uses the same Identity V3 PBKDF2-SHA512 format (100,000 iterations) that
ASP.NET Core Identity writes, so the new password works via both the web
login form and POST /api/auth/login.

Usage:
    python3 reset_demo_password.py sales@acxiomcrm.com Sales@123

Only touches the dev database at ../src/AcxiomCRM/acxiomcrm.db relative to
the AcxiomCRM project folder. It also clears any lockout and failed-attempt
counters for that user. Never run against anything but the local demo DB.
"""
import base64
import hashlib
import hmac
import os
import sqlite3
import struct
import sys

DB_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "src", "AcxiomCRM", "acxiomcrm.db"
)

PRF_SHA512 = 2          # Identity v3: 0=HMACSHA1, 1=HMACSHA256, 2=HMACSHA512
ITERATIONS = 100_000    # Identity v3 default
SALT_LEN = 16
SUBKEY_LEN = 32


def hash_password(password: str) -> str:
    salt = os.urandom(SALT_LEN)
    subkey = hashlib.pbkdf2_hmac("sha512", password.encode("utf-8"), salt, ITERATIONS, SUBKEY_LEN)
    # Identity v3 layout: 0x01 | prf | iterCount | saltLen | salt | subkey
    blob = b"\x01" + struct.pack(">III", PRF_SHA512, ITERATIONS, SALT_LEN) + salt + subkey
    return base64.b64encode(blob).decode("ascii")


def verify_password(stored_hash: str, password: str) -> bool:
    data = base64.b64decode(stored_hash)
    assert data[0] == 0x01, "not an Identity v3 hash"
    prf, iters, saltlen = struct.unpack(">III", data[1:13])
    algo = {0: "sha1", 1: "sha256", 2: "sha512"}[prf]
    salt = data[13:13 + saltlen]
    subkey = data[13 + saltlen:]
    dk = hashlib.pbkdf2_hmac(algo, password.encode("utf-8"), salt, iters, len(subkey))
    return hmac.compare_digest(dk, subkey)


def main() -> None:
    if len(sys.argv) != 3:
        print("Usage: python3 reset_demo_password.py <email> <new_password>")
        sys.exit(2)
    email, new_password = sys.argv[1], sys.argv[2]

    if not os.path.exists(DB_PATH):
        print(f"Database not found: {DB_PATH}")
        print("Run this from the AcxiomCRM project folder (or point DB_PATH at your acxiomcrm.db).")
        sys.exit(1)

    con = sqlite3.connect(DB_PATH)
    row = con.execute(
        "SELECT Id, NormalizedEmail FROM AspNetUsers WHERE NormalizedEmail = ?",
        (email.strip().upper(),),
    ).fetchone()
    if row is None:
        print(f"No user found with email: {email}")
        sys.exit(1)

    new_hash = hash_password(new_password)
    assert verify_password(new_hash, new_password), "self-check failed"

    con.execute(
        "UPDATE AspNetUsers SET PasswordHash = ?, SecurityStamp = hex(randomblob(16)), "
        "AccessFailedCount = 0, LockoutEnd = NULL WHERE Id = ?",
        (new_hash, row[0]),
    )
    con.commit()

    # Round-trip verification straight from the DB.
    stored = con.execute(
        "SELECT PasswordHash, AccessFailedCount, LockoutEnd FROM AspNetUsers WHERE Id = ?",
        (row[0],),
    ).fetchone()
    con.close()
    assert stored and verify_password(stored[0], new_password)

    print(f"OK: password for {email} has been reset (lockout cleared). "
          "Try logging in again — web form or POST /api/auth/login.")


if __name__ == "__main__":
    main()
