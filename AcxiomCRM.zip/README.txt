AcxiomCRM — Sales Relationship Management
==========================================

A complete, working CRM web application. No installation, no server, no
database setup needed — everything runs in your browser.

HOW TO RUN
----------
1. Extract this zip.
2. Double-click index.html (or open it in Chrome / Edge / Firefox).
3. Sign in with a demo account below.

DEMO ACCOUNTS (passwords are hashed — never stored as plain text)
----------
  Admin            admin@acxiomcrm.com      / Admin@123
  Manager          manager@acxiomcrm.com    / Manager@123
  Sales Executive  rahul@acxiomcrm.com      / Sales@123
  Sales Executive  sneha@acxiomcrm.com      / Sales@123

You can also click any demo account on the login screen to fill it in,
or Register a new Sales Executive account.

WHAT'S INSIDE (maps to the project document)
----------
  Dashboard            Role-based KPIs, lead-status chart, pipeline chart,
                       upcoming follow-ups, recent activity
  Customers            Create / edit / delete / search, email+phone
                       duplicate protection, customer 360° view
  Leads                Status workflow (New → Contacted → Qualified →
                       Converted, with illegal transitions blocked),
                       one-click Convert to Customer (+ Opportunity)
  Opportunities        Kanban pipeline + list view, amount / probability /
                       close-date business rules, weighted pipeline
                       (Amount × Probability / 100)
  Follow-Ups           Schedule / complete / reschedule, overdue detection,
                       date cannot be in the past
  Activities           Log calls, meetings, emails, tasks
  Users & Roles        Admin-only user management, role assignment,
                       unlock accounts, password resets
  Audit Log            Every login, logout, lockout, create, update,
                       delete and role change — filterable + CSV export
  Reports              Customers, leads, follow-ups, opportunities,
                       pipeline, conversion, user activity — CSV export
  API Explorer         Live demo of the REST contract: login, customers,
                       leads, opportunities, pipeline report — with real
                       HTTP-style status codes (200/201/400/401/403/404)

SECURITY (demonstrated in-app)
----------
  • Passwords are salted + SHA-256 hashed (see js/utils.js + js/auth.js).
    Plain text is never stored or displayed.
  • Password policy: min 8 chars, letter + number.
  • Account lockout: 5 failed attempts → 5-minute lock (try it!).
  • Role-based access: Sales sees only assigned records, cannot delete;
    Managers see team data; Admins see everything.
  • Client-side validation on every form + server-style re-validation
    in the service layer (js/validators.js) — tampered requests are
    rejected, e.g. try the API Explorer with Amount = 0.
  • Audit entries for all security events.

TRY THE ACCEPTANCE SCENARIOS
----------
  1. Open index.html without logging in → you land on the login screen.
  2. Log in as rahul@acxiomcrm.com → Dashboard with your KPIs.
  3. Customers → New Customer → enter a bad email → inline error blocks save.
  4. API Explorer → POST /api/customers with "amount":0-style bad data →
     HTTP 400 with field errors (server-side validation).
  5. Opportunities → New → Amount 0 / Probability 101 / past close date →
     each is rejected with a clear message.
  6. Follow-Ups → Schedule with yesterday's date → rejected.
  7. Log out, log in 5 times with a wrong password → account locks.
  8. Admin → Users & Roles → unlock the account / reset password.
  9. Every action above appears in Audit Log.

PROJECT STRUCTURE
----------
  index.html            App shell
  css/style.css         Full hand-written design system (no frameworks)
  assets/chart.umd.min.js  Chart.js 4.4.1 (bundled — works offline)
  js/utils.js           Hashing, formatting, CSV, download helpers
  js/data.js            Data layer + realistic seed data (localStorage)
  js/auth.js            Login, sessions, lockout, password policy, roles
  js/validators.js      Client + server validation, business rules
  js/audit.js           Append-only audit trail
  js/api.js             REST API contract simulation (DTOs, status codes)
  js/app.js             Router, layout, login, shared UI components
  js/views.js           Dashboard + charts
  js/views_crm.js       Customers, leads, opportunities, follow-ups, activities
  js/views_admin.js     Users, audit log, reports, API explorer

DATA & RESET
----------
  Your CRM records (customers, leads, opportunities…) persist in your
  browser (localStorage) so demo entries survive refreshes. Sign-in is
  required on every fresh page load — the app always opens at the
  login screen. To reset to the original seed data, open the
  browser console and run:  localStorage.clear();  then reload.

NOTE FOR EVALUATORS
----------
  This submission is a fully client-side build so it can be evaluated
  by simply opening index.html. In a production deployment the same
  architecture maps to ASP.NET Core: the service layer (js/data.js,
  js/validators.js, js/api.js) becomes Controllers + Services + EF Core,
  localStorage becomes SQL Server, and SHA-256 demo hashing becomes
  ASP.NET Core Identity's PBKDF2 hashing. All business rules, role
  checks and audit points are already isolated in those modules,
  making the mapping one-to-one.
